#ifdef NEVERDEF
/****************************************************************************
 ****************************************************************************
 *                                                                          *
 *   WARNING!                                                               *
 *                                                                          *
 *   I've discovered a bug in the code optimizer.  A definition like:       *
 *      #define TESTBITS (BIT1|BIT2)                                        *
 *   can produce incorrect code output from the optimizer when TESTBITS     *
 *   is used.                                                               *
 *                                                                          *
 *   Instead, use a definition like:                                        *
 *      #define TESTBITS 0x05  /* (BIT1|BIT2) */                            *
 *   Yes, that's not as "ideal", but it will save a WORLD of problems!      *
 *                                                                          *
 ****************************************************************************
 ****************************************************************************/
#endif

/*
 *  PIC emulator user command shell.  Should be PIC processor independent.
 *
 *
 *  Copyright (c) 2001-2004
 *
 *  Released under the GNU GPL.  See http://www.gnu.org/licenses/gpl.txt
 *
 *  This program is part of PICEMU
 *
 *  PICEMU is free software; you can redistribute it and/or modify it under
 *  the terms of the GNU General Public License as published by the Free
 *  Software Foundatation; either version 2 of the License, or any later
 *  version.
 *
 *  PICEMU is distributed in the hope that it will be useful, but WITHOUT
 *  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 *  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 *  for more details.
 *
 *
 *  Revision history
 *
 *  Date      Comments
 *  --------  ---------------------------------------------
 *  9/xx/01   Original code
 *  11/14/01  Code cleanup for 1st BETA release
 *  4/18/02   Split (PSHELL, PSHELL2) for compiler limits
 *  03/01/03  Improved HELP command
 *  11/6/03   More commands and better processing for V1.20
 *  3/15/04   Source code unification for 14-bit core programs.
 */
#define PSHELL   /* tell PICEMU.H it's OK to define window stuff */
void scroll_regs(), scroll_eeprom(), scroll_where(), scroll_disasm();
#include <picemu.h>

BYTE cmdline[STRING_SIZE];
WORD cmdptr;

extern WORD memory[MEMORY_SIZE];
extern BYTE regs[NUM_REGS];
#ifdef EEPROM_SIZE
   extern BYTE eeprom[EEPROM_SIZE];
#endif  /* EEPROM_SIZE */
extern WORD xlate_regs[NUM_REGS];
  /* which reg maps to which, i.e. regs 0x20 - 0x2f map back to 0x00 - 0x0f in the 12C509A */
extern WORD initial_ports[NUM_BYTE_PORTS][8];
extern BYTE input_ports[NUM_BYTE_PORTS_ALLOCATE];
extern BYTE port_masks[NUM_BYTE_PORTS_ALLOCATE];
extern WORD analog_ports[NUM_BYTE_PORTS][8];

extern struct keypins key_pins[MAX_KEYPINS];


#ifdef CORE_14BIT
   extern BYTE show_regs[NUM_REGS];  /* which regs to show in a 'R' command */
#endif  /* CORE_14BIT */


extern WORD ip;          /* instruction pointer */
extern BYTE w;           /* Working register */
extern WORD breakpoint;  /* !0, have breakpoint, else FALSE */
extern WORD chkstack;
extern WORD watchdog;    /* watchdog timer */
extern WORD chkwatchdog;
extern WORD readusestris;
extern WORD sleepmode;   /* TRUE if sleeping, else FALSE */
extern WORD watchdog_reset_count;  /* reset value for watchdog to give 18ms nominal timer */
extern DWORD frequency;    /* CPU frequency */
extern WORD configuration;
double simulated_time;

extern WORD stack[STACK_SIZE];
extern WORD stack_ptr;
extern WORD stack_depth;
/* extern WORD max_stack_depth; */

extern DWORD instructioncount[2];  /* fake a 64-bit int */
extern DWORD breakcount[2];  /* fake a 64-bit int */

extern WORD timingcount;
extern WORD throttle;      /* allow variable execution speed */

extern WORD unasm_ip;      /* default disassembly address */
extern WORD asm_ip;        /* default assembly address */

extern WORD bittable[8];


extern WORD num_reg_breakpoints;
extern struct regbreaks reg_breaks[MAX_REG_BREAKS];
WORD reg_breakpoints_on, num_reg_breaks;

extern WORD num_mem_breakpoints;
extern struct membreaks mem_breaks[MAX_MEM_BREAKS];

DWORD startticks, endticks;
DWORD totalticks;
/* DWORD daycount; */
extern DWORD stopwatch_startticks;

int filein;    /* NOTE: For DeSmet C (aka PCC) a FILE is just an int */
int outputfile = 0;  /* default: no output file */
int inputfile = 0;  /* default: no input file */
DWORD inputfilesize;  /* size of input file */
DWORD lseek();
DWORD atol();

extern DWORD total_ic[2];  /* count of instructions executed */  /* fake a 64-bit int */
extern WORD whereptr;  /* pointer into "where was I?" queue */
extern WORD wherequeue[WHERE_SIZE+1];  /* queue of addresses for where? */
extern DWORD stopwatchcount[2];  /* fake a 64-bit int */
/* extern DWORD stimulus_delay[2]; */  /* fake a 64-bit int */
extern struct stim stimulus[MAX_STIMULUS_SIZE];
extern BYTE stim_pinmasks[NUM_BYTE_PORTS_ALLOCATE];
extern WORD num_stimulus;
/* extern WORD stimulus_index; */  /* which stimulus to apply */
extern WORD periodic_stim;

DWORD stopwatchticks;

#ifdef HAS_UART
   extern WORD commbase;  /* default to SCREEN/KEYBOARD */
   extern WORD irqnum;         /* default to SCREEN/KEYBOARD */
   extern WORD commport;
   extern WORD tx_int_delay;   /* default: no delay */
   extern WORD winnt;
   WORD commbase_table[5] = { 0x0000, 0x03f8, 0x02f8, 0x03e8, 0x02e8 };
   WORD irqnum_table[5]   = {      0,      4,      3,      4,      3 };
#endif  /* HAS_UART */

extern WORD hex_uart_screen;
extern BYTE uart_screen[SCREEN_ROWS * SCREEN_COLS * 2];
extern WORD swap_screens;
extern WORD screen_rowofs;
/* extern WORD screen_colofs; */
extern WORD uart_screen_maxrow;  /* max row to use for UART/SoftUART screen */
extern WORD uart_screen_maxrowofs;  /* max ofs to use for UART/SoftUART screen */

/* TX:  transmission from PIC --> USER */
/*  Note: su_txdata will start at 0, be right shifted before a new bit is
 *        put in the top of the word.  Thus, the received data will look like
 *        <stop bits><parity (if any)><data bits><start bit><0's>
 */
extern WORD su_txenable;    /* if 0, we are doing PIC --> USER bitbanging */
extern WORD su_txbaud;      /* baudrate, 110 to 57600 (max of frequency/16) */
extern WORD su_txbittiming; /* instructions per bit */
extern WORD su_txtiming;    /* if != 0, inst. count until next bit receive */
extern WORD su_txlastbit;   /* previous state of our TX pin, for start of data detection */
extern WORD su_txbitmask;   /* bittable[su_txpin] */

/* RX:  transmission from USER --> PIC */
/*  Note: su_rxdata will start at contain the formatted bit string.  Bits
 *        will be read from the bottom of the word, which will then be
 *        shifted right.  Thus, the data to send will look like:
 *        <0's><stop bits><parity (if any)><data bits><start bit>
 */
extern WORD su_rxenable;    /* if 0, we are doing USER --> PIC bitbanging */
extern WORD su_rxbaud;      /* baudrate, 110 to 57600 (max of frequency/16) */
extern WORD su_rxbittiming; /* instructions per bit */
extern WORD su_rxtiming;    /* if != 0, inst. count until next bit receive */

#ifdef HAS_ADC
   extern WORD adc_table[ADC_TABLE_MAXSIZE];
   extern WORD adc_table_size;
   extern WORD adc_table_index;
#endif  /* HAS_ADC */

WORD show_ports;
WORD tickcount;  /* if non-zero, ticks until breakpoint */
WORD have_tickcount;  /* copy of tickcount, for exit processing in godoit() and execute() */
extern void (*portbitfns[NUM_BYTE_PORTS * 8])();
extern WORD num_watch_regs;  /* how many reg numbers in array */
extern WORD watchregs[NUM_WATCHREGS];

extern WORD oscope_lines;
extern WORD oscope_maxwidth;
extern WORD oscope_in;  /* IN index to oscope_data[] */
extern WORD oscope_out; /* OUT index to oscope_data[] */
extern DWORD oscope_count;
extern DWORD oscope_delay;
extern WORD oscope_logical;
extern WORD oscope_video_addr;    /* for oscope display */
extern WORD oscope_ports[MAX_OSCOPE_LINES];
extern WORD oscope_pins[MAX_OSCOPE_LINES];
extern WORD oscope_pinmasks[MAX_OSCOPE_LINES];
extern BYTE oscope_lasttris[MAX_OSCOPE_LINES];
extern BYTE oscope_lastport[MAX_OSCOPE_LINES];

extern WORD bytesperline;   /* bytes per line (80*2 or 132*2) */

extern WORD last_t0cki;    /* for T0CKI edge detection */
#ifndef CORE_12BIT
   extern BYTE last_porta_in; /* for TIMER 0 edge detection & IOC */
   extern BYTE last_intpin;   /* for interrupt on rising/falling signal on INT pin */
#endif  /* CORE_12BIT */

#ifdef HAS_PORTB
   extern BYTE last_portb;    /* for port change interrupt */
   extern BYTE last_portb_in; /* for INT pin edge detect */
#endif  /* HAS_PORTB */

extern BYTE lasttris[NUM_BYTE_PORTS_ALLOCATE];  /* need this globally for reset_windows() */

extern BYTE tempstr[STRING_SIZE];
extern BYTE instr_str[64];  /* disassembled instruction */
       BYTE fname[STRING_SIZE];
       BYTE fromhexstr[STRING_SIZE];
       BYTE fh2[STRING_SIZE];
static BYTE browse_name[STRING_SIZE];
       DWORD browse_pos;
       BYTE browse_screen[BROWSE_SCREEN_SIZE+16];  /* allow myself some "slop" room */

       BYTE number_str[8] = "number?";
       BYTE address_str[12] = "address?";
       BYTE range_str[16] = "out of range";
       BYTE name_str[8] = "name?";
       BYTE command_str[12] = "command?";
       BYTE value_str[8] = "value?";
       BYTE space_str[4] = " ";
       BYTE nl_str[4] = "\n";
       BYTE on_str[4] = "ON";
       BYTE off_str[4] = "OFF";
       BYTE cannot_write_str[24] = "Cannot write to file\n";
       BYTE picemu_str[8] = "PICEMU";  /* who ownes BIN/PIM files */
       BYTE syntax_str[8] = "syntax?";
       BYTE no_soft_uart[16] = "No soft UART\n";
       BYTE disk_full_str[48] = "Error writing to output file!  Output closed!\n";
static BYTE time_str[8] = "time=";
static BYTE ic_str[4] = "ic=";
       BYTE frequency_too_slow[36] = "frequency too slow for SoftUart";
static BYTE invalid_stim_file[32] = "invalid stimulus file:\n    ";
       BYTE press_any[32] = "Press any key to continue...";
       BYTE press_any_esc[48] = "Press any key to continue, Esc to quit...";
static BYTE keytype_str[8] = "! T><";
#ifdef PINS_8
   static BYTE gpio_str[4] = "GP";
#endif  /* PINS_8 */
       WORD use_sticky_breaks, num_sticky_breaks;
       struct membreaks sticky_breaks[MAX_STICKY_BREAKS];

BYTE macros[NUM_MACRO_KEYS][STRING_SIZE];

BYTE helpfile[STRING_SIZE];

BYTE copyright[] =
"Copyright (c) 2001-2004\n";
BYTE information[] =
"This program is licensed under the GNU GPL.  www.gnu.org/licenses/gpl.txt\n\nUse \"H\" for help.\n";

/*
 *  NOTE: 1.00A differs from 1.00 in some minor bugfixes.
 *        1.20  Analog's now supported, 14-bit core code unification.
 */
#ifdef PICTYPE_12C509A
   BYTE hello[] = "PICEMUlator -- 12C509A Version 1.20.\n";
   BYTE processor[8] = "12C509A";
   BYTE *helpname = "HELP509.DAT";
#endif  /* PICTYPE_12C509A */

#ifdef PICTYPE_16F877
   BYTE hello[] = "PICEMUlator -- 16F877 Version 1.20.\n";
   BYTE processor[8] = "16F877";
   BYTE *helpname = "HELP877.DAT";
#endif  /* PICTYPE_16F877 */

#ifdef PICTYPE_16F84A
   BYTE hello[] = "PICEMUlator -- 16F84A Version 1.20.\n";
   BYTE processor[8] = "16F84A";
   BYTE *helpname = "HELP84A.DAT";
#endif  /* PICTYPE_16F84A */

#ifdef PICTYPE_16F648
   BYTE hello[] = "PICEMUlator -- 16F648A Version 1.20.\n";
   BYTE processor[8] = "16F648";
   BYTE *helpname = "HELP648.DAT";
#endif  /* PICTYPE_16F648 */

#ifdef PICTYPE_12F675
   BYTE hello[] = "PICEMUlator -- 12F675 Version 1.20.\n";
   BYTE processor[8] = "12F675";
   BYTE *helpname = "HELP675.DAT";
#endif  /* PICTYPE_12F675 */

#define CMD_NONE       0
#define CMD_NAME       1
#define CMD_LOAD       2
#define CMD_ENTER      3
#define CMD_FILL       4
#define CMD_BRKPNTS    5
#define CMD_REGBRK     6
#define CMD_REGS       7
#define CMD_UNASM      8
#define CMD_ASM        9
#define CMD_GO        10
#define CMD_PROCEEDE  11
#define CMD_EXECUTE   12
#define CMD_TRACE     13
#define CMD_RESET     14
#define CMD_HELP      15
#define CMD_CALC      16
#define CMD_WHERE     17
#define CMD_QUIT      18
#define CMD_COMMENT   19
#define CMD_OUTPUT    20
#define CMD_CREATE    21
#define CMD_WAKE      22
#define CMD_COMM      23
#define CMD_SCREEN    24
#define CMD_VIEW      25
#define CMD_REGDISP   26
#define CMD_FREQU     27
#define CMD_PORTS     28
#define CMD_KEYS      29
#define CMD_BROWSE    30
#define CMD_DIR       31
#define CMD_EEPROM    32
#define CMD_EEPROMF   33
#define CMD_EEPROME   34
#define CMD_SAVE      35
#define CMD_TRACETRUE 36
#define CMD_CONFIG    37
#define CMD_TRIS      38
#define CMD_OPTION    39
#define CMD_HEX       40
#define CMD_SOFTUART  41
#define CMD_THROTTLE  42
#define CMD_INPUT     43
#define CMD_CHKSTACK  44
#define CMD_WATCHREGS 45
#define CMD_STOPWATCH 46
#define CMD_STIMULUS  47
#define CMD_CHKPOINT  48
#define CMD_ALLREGS   49
#define CMD_ADC       50
#define CMD_RETURN    51
#define CMD_MACRO     52
#define CMD_OSCOPE    53
#define CMD_SYMBOLS   54
#define CMD_I2C       55
#define CMD_WATCHDOG  56
#define CMD_READTRIS  57
#define CMD_SETPORTS  58
#define CMD_PAUSE     59
#define CMD_HEXSCREEN 60
#ifdef USE_ADDRLIST
   #define CMD_ADDRLIST  61
#endif  /* USE_ADDRLIST */
/* #define CMD_NOTFOUND 0xffff */
#ifdef EEPROM_SIZE
   void cmd_eeprome(), cmd_eepromf(), cmd_eeprom();
#endif  /* EEPROM_SIZE */
#ifdef HAS_UART
   void cmd_comm();
#endif  /* HAS_UART */
#ifdef CORE_14BIT
   void cmd_regdisp();
#endif  /* CORE_14BIT */
#ifdef CORE_12BIT
   void cmd_tris(), cmd_option();
#endif  /* CORE_12BIT */
#ifdef HAS_ADC
   void cmd_adc();
#endif  /* HAS_ADC */
void cmd_none(), cmd_name(), cmd_load(), cmd_enter(), cmd_fill();
void cmd_brkpnts(), cmd_regbrk(), cmd_regs(), cmd_unasm(), cmd_asm();
void cmd_go(), cmd_execute(), cmd_trace(), cmd_reset(), cmd_help();
void cmd_calc(), cmd_where(), cmd_output(), cmd_create(), cmd_wake();
void cmd_view(), cmd_frequ(), cmd_ports(), cmd_keys(), cmd_browse();
void cmd_dir(), cmd_save(), cmd_config(), cmd_hex(), cmd_screen();
void cmd_softuart(), cmd_throttle(), cmd_input(), cmd_chkstack();
void cmd_watchregs(), cmd_stopwatch(), cmd_stimulus();
void cmd_macro(), cmd_oscope(), cmd_symbols(), cmd_i2c(), cmd_watchdog();
void cmd_readtris(), cmd_pause();
#ifdef USE_ADDRLIST
   void cmd_addrlist();
#endif  /* USE_ADDRLIST */
/*  Notes:  this structure should be defined in sorted order, based on
 *          greatest to least matchlen.
 *
 *          keep the command names in lower case (for cmd_help())
 */
struct cmd_list
   {
   BYTE *cmdname;
   WORD matchlen;
   WORD cmdvalue;
   void (*cmdfn)();
   WORD chkpt_ok;   /* TRUE or FALSE: can be called via CHECKPOINT cmd */
   } cmdlist[] =
   {
#ifdef EEPROM_SIZE
      { "entereeprom",    6, CMD_EEPROME,   cmd_eeprome,   TRUE  },
#endif  /* EEPROM_SIZE */
      { "checkpoint",     6, CMD_CHKPOINT,  cmd_go,        FALSE },
      { "checkstack",     6, CMD_CHKSTACK,  cmd_chkstack,  FALSE },
      { "tracetrue",      6, CMD_TRACETRUE, cmd_trace,     FALSE },
      { "watchdog",       6, CMD_WATCHDOG,  cmd_watchdog,  FALSE },
#ifdef USE_ADDRLIST
      { "addrlist",       6, CMD_ADDRLIST,  cmd_addrlist,  FALSE },
#endif  /* USE_ADDRLIST */
      { "pause",          5, CMD_PAUSE,     cmd_pause,     FALSE },
      { "readusestris",   5, CMD_READTRIS,  cmd_readtris,  FALSE },
      { "reset",          5, CMD_RESET,     cmd_reset,     TRUE  },
      { "softuart",       5, CMD_SOFTUART,  cmd_softuart,  FALSE },
      { "stopwatch",      5, CMD_STOPWATCH, cmd_stopwatch, TRUE  },
#ifdef EEPROM_SIZE
      { "filleeprom",     5, CMD_EEPROMF,   cmd_eepromf,   TRUE  },
#endif  /* EEPROM_SIZE */
      { "setports",       4, CMD_SETPORTS,  cmd_ports,     TRUE  },
      { "allregs",        4, CMD_ALLREGS,   cmd_regs,      TRUE  },
      { "regbreakpoints", 4, CMD_REGBRK,    cmd_regbrk,    FALSE },
      { "calc",           4, CMD_CALC,      cmd_calc,      TRUE  },
#ifdef HAS_UART
      { "comm",           4, CMD_COMM,      cmd_comm,      FALSE },
#endif  /* HAS_UART */
      { "config",         4, CMD_CONFIG,    cmd_config,    TRUE  },
      { "stimulus",       4, CMD_STIMULUS,  cmd_stimulus,  TRUE  },
#ifdef CORE_14BIT
      { "regdisplay",     4, CMD_REGDISP,   cmd_regdisp,   TRUE  },
      { "showregs",       4, CMD_REGDISP,   cmd_regdisp,   TRUE  },
#endif  /* CORE_14BIT */
#ifdef CORE_12BIT
      { "tris",           4, CMD_TRIS,      cmd_tris,      TRUE  },
      { "option",         4, CMD_OPTION,    cmd_option,    TRUE  },
#endif  /* CORE_12BIT */
      { "hexscreen",      4, CMD_HEXSCREEN, cmd_screen,    FALSE },
      { "screen",         3, CMD_SCREEN,    cmd_screen,    FALSE },
      { "browse",         3, CMD_BROWSE,    cmd_browse,    FALSE },
      { "dir",            3, CMD_DIR,       cmd_dir,       FALSE },
      { "throttle",       3, CMD_THROTTLE,  cmd_throttle,  FALSE },
#ifdef EEPROM_SIZE
      { "feeprom",        3, CMD_EEPROMF,   cmd_eepromf,   TRUE  },
      { "eeeprom",        3, CMD_EEPROME,   cmd_eeprome,   TRUE  },
#endif  /* EEPROM_SIZE */
#ifdef HAS_ADC
      { "adc",            3, CMD_ADC,       cmd_adc,       FALSE },
#endif  /* HAS_ADC */
      { "hex",            3, CMD_HEX,       cmd_hex,       FALSE },
      { "return",         3, CMD_RETURN,    cmd_go,        FALSE },
      { "watchregs",      3, CMD_WATCHREGS, cmd_watchregs, FALSE },
      { "macro",          3, CMD_MACRO,     cmd_macro,     FALSE },
      { "oscope",         3, CMD_OSCOPE,    cmd_oscope,    FALSE },
      { "symbols",        3, CMD_SYMBOLS,   cmd_symbols,   FALSE },
      { "i2c",            3, CMD_I2C,       cmd_i2c,       FALSE },
      { "bregisters",     2, CMD_REGBRK,    cmd_regbrk,    FALSE },
      { "execute",        2, CMD_EXECUTE,   cmd_execute,   FALSE },
      { "wake",           2, CMD_WAKE,      cmd_wake,      TRUE  },
      { "frequency",      2, CMD_FREQU,     cmd_frequ,     FALSE },
      { "ports",          2, CMD_PORTS,     cmd_ports,     FALSE },
#ifdef EEPROM_SIZE
      { "eeprom",         2, CMD_EEPROM,    cmd_eeprom,    TRUE  },
#endif  /* EEPROM_SIZE */
      { "save",           2, CMD_SAVE,      cmd_save,      FALSE },
      { "write",          2, CMD_SAVE,      cmd_save,      FALSE },
      { "ttrace",         2, CMD_TRACETRUE, cmd_trace,     FALSE },
      { "name",           1, CMD_NAME,      cmd_name,      FALSE },
      { "load",           1, CMD_LOAD,      cmd_load,      FALSE },
      { "enter",          1, CMD_ENTER,     cmd_enter,     TRUE  },
      { "fill",           1, CMD_FILL,      cmd_fill,      TRUE  },
      { "breakpoints",    1, CMD_BRKPNTS,   cmd_brkpnts,   FALSE },
      { "registers",      1, CMD_REGS,      cmd_regs,      TRUE  },
      { "unassemble",     1, CMD_UNASM,     cmd_unasm,     TRUE  },
      { "assemble",       1, CMD_ASM,       cmd_asm,       FALSE },
      { "go",             1, CMD_GO,        cmd_go,        FALSE },
      { "proceede",       1, CMD_PROCEEDE,  cmd_go,        FALSE },
      { "trace",          1, CMD_TRACE,     cmd_trace,     FALSE },
      { "help",           1, CMD_HELP,      cmd_help,      FALSE },
      { "where",          1, CMD_WHERE,     cmd_where,     TRUE  },
      { "quit",           1, CMD_QUIT,      cmd_none,      FALSE },
      { ";",              1, CMD_COMMENT,   cmd_none,      FALSE },
      { "#",              1, CMD_COMMENT,   cmd_none,      FALSE },
      { "output",         1, CMD_OUTPUT,    cmd_output,    FALSE },
      { "input",          1, CMD_INPUT,     cmd_input,     FALSE },
      { "create",         1, CMD_CREATE,    cmd_create,    FALSE },
      { "view",           1, CMD_VIEW,      cmd_view,      FALSE },
      { "keys",           1, CMD_KEYS,      cmd_keys,      FALSE },
      { "",               0, 0,             0,             0 }  /* end of list tag */
   };

WORD vgamode;   /* flag: VGA mode (80x50) is available */
WORD vesamode;  /* flag: VESA mode (0x010B -> 132 x 50) is available */
WORD windowmode;  /* FLAG: either VGA or VESA mode */

BYTE *breakstrings[NUM_BREAKTYPES] =
   {
   "",                       /* BRK_NONE */
   "Keypress",               /* BRK_KEYPRESS */
   "Memory",                 /* BRK_MEMORY */
   "Register",               /* BRK_REGISTER */
   "Instruction count",      /* BRK_COUNT */
   "Elapsed time",           /* BRK_TIME */
   "Stack Overflow",         /* BRK_STACKOVF */
   "Stack Underflow",        /* BRK_STACKUNDF */
   "Watchdog expired",       /* BRK_WATCHDOG */
   "Register read value",    /* BRK_REGREADVAL */
   "Register write value"    /* BRK_REGWRITEVAL */
#ifdef USE_ADDRLIST
   ,
   "Wrong memory accessed"   /* BRK_ADDRLIST */
#endif  /* USE_ADDRLIST */
   };

WORD peekw();
WORD symboladdr;  /* segment of symbol table */
WORD numsymbols;  /* number of entries in symbol table */
   /* NOTE: Since I don't have enough RAM space in 64K to save a symbol table,
    *       and a symbol table is something that doesn't need fast or frequent
    *       access, I'm going to put it in "free" memory above PICEMU and
    *       access it manually.
    *
    *       If there isn't enough RAM for the symbol table, symboladdr will
    *       be 0.
    */

WORD parse_command()
   {
   WORD index;

   if (!parse(tempstr))  /* this should never happen, but... */
      return(CMD_NOTFOUND);
   skip_cmd_spaces();
   for (index = 0; cmdlist[index].matchlen; index++)
      if ((strncmpi(tempstr,cmdlist[index].cmdname,cmdlist[index].matchlen) == 0)
            && (strncmpi(tempstr,cmdlist[index].cmdname,MIN(strlen(tempstr),strlen(cmdlist[index].cmdname))) == 0)
            && (strlen(tempstr) <= strlen(cmdlist[index].cmdname)))
         return(index);
   return(CMD_NOTFOUND);  /* unrecognized command */
   }

menu(argc,argv)
   WORD argc;
   BYTE *argv[];
   {
   WORD whichcmd;
   WORD i, j;

   find_helpfile();
   for (i = 1; i < argc; i++)
      {
      if (argv[i][0] == '/')
         {
         if (strcmpi(&argv[i][1],"none") == 0)  /* no VESA or VGA */
            {
            vesamode = FALSE;
            vgamode = FALSE;  /* neither available */
            }
         if (strcmpi(&argv[i][1],"vga") == 0)  /* no VESA, VGA is OK */
            vesamode = FALSE;
         for (j = i; j < argc-1; j++)
            strcpy(argv[j],argv[j+1]);
         argc--;
         i--;  /* remove this cmdline parameter */
         }
      }
   init_windows();   /* setup data windows */
   clrscr(window_data[WINDOW_COMMAND].numrows);
   PUTS(hello);
   PUTS(copyright);
   PUTS(information);
   for (i = 1; i < argc; i++)
      {
      if (argv[i][0] == '-')
         {
         strcpy(cmdline,&argv[i][1]);
         skip_cmd_spaces();
         cmd_input(1);  /* parameter does not matter */
         for (j = i; j < argc-1; j++)
            strcpy(argv[j],argv[j+1]);
         argc--;
         i--;  /* remove this cmdline parameter */
         }
      }
   if (argc > 1)
      {
      strcpy(fname,argv[1]);
      cmdline[0] = '\0';  /* no commandline for this */
      }
   cmd_reset(CMD_NOTFOUND);
   if (fname[0])  /* if name give on command line */
      cmd_load(CMD_NOTFOUND);  /* parameter does not matter */
   do
      {
      /* update_command(); */
      update_windows();
      getstr(">",cmdline);
      whichcmd = CMD_COMMENT;  /* null command */
      cmdptr = 0;  /* init cmdline ptr */
      skip_cmd_spaces();
      if (cmdline[cmdptr])
         {
         if ((whichcmd = parse_command()) != CMD_NOTFOUND)
            (*cmdlist[whichcmd].cmdfn)(whichcmd);
         else
            cmdline_error(command_str);
         }
      } while (cmdlist[whichcmd].cmdvalue != CMD_QUIT);
   }

void cmd_none(whichcmd)  /* need something to put a pointer to */
   WORD whichcmd;
   {
   }

void cmd_name(whichcmd)  /* name of file to load */
   WORD whichcmd;
   {
   if (cmdline[cmdptr])
      strcpy(fname,&cmdline[cmdptr]);
   else
      cmdline_error(name_str);
   }

void cmd_load(whichcmd)  /* load fname (can specify fname, too) */
   WORD whichcmd;
   {
   cmd_reset(CMD_NOTFOUND);
   if (cmdline[cmdptr])
      strcpy(fname,&cmdline[cmdptr]);
   if (!fname[0])  /* if no name given */
      {
      cmdline_error(name_str);
      return;
      }
   if ((filein = open(fname,0)) == -1)
      {
      PUTS("    ");
      PUTS(fname);
      PUTS(" not found!\n");
      return;
      }
   if (read(filein,tempstr,1) != 1)
            /*  NOTE: reading 1 char is a special case for loading a
             *        HEX file.  A hex file can be very small, and
             *        this guarantees that the load command won't error
             *        out because the hex file is smaller than picfile_hdr.
             */
      {
      PUTS("   read error for file ");
      PUTS(fname);
      PUTS(nl_str);
      close(filein);
      return;
      }
   load_file();
   close(filein);
   }

WORD build_intelhex_line(lineout,len,addr,recordtype,data,fout,name)
   BYTE *lineout;
   WORD len;  /* length in WORDS */
   WORD addr;  /* address of this record */
   WORD recordtype;
   BYTE *data;  /* BYTE ptr to WORD data */
   int fout;  /* output file */
   BYTE *name;  /* name of output file */
   {
   WORD index;
   WORD chksum;

   sprintf(lineout,":%02x%04x%02x",len+len,addr+addr,recordtype);
   chksum = addr + addr;  /* temp value */
   chksum = (chksum & 0xff) + (chksum >> 8) + len + len + recordtype;
   for (index = 0; index < len+len; index++)
      {
      sprintf(&lineout[strlen(lineout)],"%02x",data[index]);
      chksum += data[index];
      }
   sprintf(&lineout[strlen(lineout)],"%02x\r\n",(0x100-chksum)&0xff);
   if (write(fout,lineout,strlen(lineout)) != strlen(lineout))
      {
      close(fout);
      unlink(name);  /* don't keep bad files around */
      PUTS(cannot_write_str);
      return(FALSE);
      }
   return(TRUE);
   }

void cmd_hex(whichcmd)  /* create hex file */
   WORD whichcmd;
   {
   int fout;  /* temporary file handle */
              /* NOTE: For DeSmet C (aka PCC) a FILE is just an int */
   WORD addr;
   BYTE lineout[STRING_SIZE];

   if (!parse(tempstr))
      {
      cmdline_error(name_str);
      return;
      }
   if ((fout = open(tempstr,0)) != -1)
      {
      close(fout);
      PUTS(tempstr);
      getstr(" already exists. Overwrite it (Y/N)? ",cmdline);
      cmdptr = 0;  /* init cmdline ptr */
      skip_cmd_spaces();
      if (toupper(cmdline[cmdptr]) != 'Y')
         return;
      }
   if ((fout = creat(tempstr)) == -1)
      {
      PUTS("unable to create ");
      PUTS(tempstr);
      PUTS(nl_str);
      return;
      }
   addr = 0;  /* word to send for extended linear address record */
   if (!build_intelhex_line(lineout,1,0,4,&addr,fout,tempstr))
      return;
   for (addr = 0; addr < MEMORY_SIZE; addr += 8)
      {
      if (!build_intelhex_line(lineout,8,addr,0,&memory[addr],fout,tempstr))
         return;
      }
#ifdef EEPROM_SIZE
   for (addr = 0; addr < EEPROM_SIZE; addr += 8)
      {
      if (!build_intelhex_line(lineout,8,addr+EEPROM_LOC,0,&eeprom[addr],fout,tempstr))
         return;
      }
#endif  /* EEPROM_SIZE */
   if (!build_intelhex_line(lineout,1,CONFIG_LOC,0,&configuration,fout,tempstr))
      return;
   addr = 0;  /* for "end of file" line */
   if (!build_intelhex_line(lineout,0,0,1,&addr,fout,tempstr))
      return;
   if (close(fout) == -1)  /* if bad write of buffered output */
      {
      unlink(tempstr);  /* don't keep bad files around */
      PUTS(cannot_write_str);
      }
   }

void cmd_enter(whichcmd)   /* enter data into memory */
   WORD whichcmd;
   {
   do_fill_enter(TRUE);  /* do a ENTER */
   }

void cmd_fill(whichcmd)   /* fill memory with data */
   WORD whichcmd;
   {
   do_fill_enter(FALSE);  /* do a FILL */
   }

void on_or_off(val)
   WORD *val;
   {
   WORD temp;

   temp = cmdptr;  /* remember where we started */
   if (parse(tempstr))
      {
      skip_cmd_spaces();
      if (strcmpi(tempstr,on_str) == 0)
         *val = TRUE;
      else
         if (strcmpi(tempstr,off_str) == 0)
            *val = FALSE;
         else
            cmdptr = temp;  /* put parameter back for later parsing */
      }
   }

void cmd_brkpnts(whichcmd)   /* set breakpoints */
   WORD whichcmd;
   {
   WORD temp, temp1, temp2, temp3;

   on_or_off(&use_sticky_breaks);
   if (cmdline[cmdptr])  /* if setting breakpoints */
      {
      /*
       * If we're here, we're getting sticky breakpoints
       */
      for (temp = 0; temp < MAX_STICKY_BREAKS; temp++)
         {
         if ((temp1 = get_break_range(&temp2,&temp3,MEMORY_SIZE-1)) == 0)
            {
            sticky_breaks[temp].low = temp2;
            sticky_breaks[temp].high = temp3;
            }
         else
            break;
         }
      if ((temp1 != 1) && (temp))  /* if not bad number and some entries */
         {
         num_sticky_breaks = temp;  /* number valid breaks */
         use_sticky_breaks = TRUE;
         }
      else
         {
         num_sticky_breaks = 0;
         use_sticky_breaks = FALSE;
         }
      }
   if (num_sticky_breaks)  /* if any around! */
      {
      sprintf(tempstr,"Sticky breakpoints %s\n",use_sticky_breaks ? on_str : off_str);
      PUTS(tempstr);
      for (temp1 = 0; temp1 < num_sticky_breaks; temp1++)
         {
         if (sticky_breaks[temp1].low != sticky_breaks[temp1].high)
            sprintf(tempstr,"%04x -> %04x  ",
                      sticky_breaks[temp1].low,sticky_breaks[temp1].high);
         else
            sprintf(tempstr,"%04x          ",
                      sticky_breaks[temp1].low);
         PUTS(tempstr);
         if ((temp1 == 4) && (num_sticky_breaks > 5))
            PUTS(nl_str);
         }
      PUTS(nl_str);
      }
   else
      PUTS("no sticky breakpoints\n");
   }

void cmd_regbrk(whichcmd)   /* set register breakpoints */
   WORD whichcmd;
   {
   WORD valid, have_mask, temp, len;
   BYTE *p;
   DWORD val1,val2,val3,val4;

   on_or_off(&reg_breakpoints_on);
   if (cmdline[cmdptr])  /* setting reg breakpoints */
      {
      for (num_reg_breaks = 0; num_reg_breaks < MAX_REG_BREAKS; num_reg_breaks++)
         {
         reg_breaks[num_reg_breaks].type = REGBREAK_READ | REGBREAK_WRITE;  /* default values */
         reg_breaks[num_reg_breaks].have_value = FALSE;
         reg_breaks[num_reg_breaks].value = 0;
         reg_breaks[num_reg_breaks].mask = 0xff;
         valid = TRUE;  /* if EOL, we're valid */
         if (!parse(fromhexstr))
            break;
         valid = FALSE;  /* from here on, we have to earn out "valid" */
         p = fromhexstr;  /* need a pointer for now */
         if (toupper(fromhexstr[0]) == 'R')
            {
            reg_breaks[num_reg_breaks].type = REGBREAK_READ;
            p++;
            }
         if (toupper(fromhexstr[0]) == 'W')
            {
            reg_breaks[num_reg_breaks].type = REGBREAK_WRITE;
            p++;
            }
         if (!fromhex(p,&val1))
            break;
         if (val1 >= NUM_REGS)
            break;
         val2 =
         reg_breaks[num_reg_breaks].low =
         reg_breaks[num_reg_breaks].high = val1;
         if (cmdline[cmdptr] == ',')
            {
            if (!parse(fromhexstr))
               break;  /* comma and no more is not a valid format */
            if (!fromhex(fromhexstr,&val2))
               break;
            if ((val2 >= NUM_REGS) || (val2 < val1))
               break;
            reg_breaks[num_reg_breaks].high = val2;
            }
         have_mask = FALSE;
         if (cmdline[cmdptr] == '&')  /* value mask? */
            {
            cmdptr++;
            if (!parse(fromhexstr))
               break;
            if (!fromhex(fromhexstr,&val3))
               break;
            if (val3 > 0xff)
               break;
            reg_breaks[num_reg_breaks].mask = val3;
            have_mask = TRUE;
            }
         if (cmdline[cmdptr] == '=')  /* target value? */
            {
            if (!parse(fromhexstr))
               break;
            if (!fromhex(fromhexstr,&val4))
               break;
            if (val4 > 0xff)
               break;
            reg_breaks[num_reg_breaks].have_value = TRUE;
            reg_breaks[num_reg_breaks].value = val4;
            }
         else
            if (have_mask)
               break;  /* can't have a mask without a value! */
         valid = TRUE;
         }
      if ((valid) && (num_reg_breaks))  /* if not bad number and some entries */
         reg_breakpoints_on = TRUE;
      else
         {
         cmdline_error(syntax_str);
         num_reg_breaks = 0;
         reg_breakpoints_on = FALSE;
         }
      }
   if (num_reg_breaks)
      {
      sprintf(tempstr,"Reg breakpoints %s\n",reg_breakpoints_on ? on_str : off_str);
      PUTS(tempstr);
      for (temp = 0; temp < num_reg_breaks; temp++)
         {
         if (reg_breaks[temp].type == (REGBREAK_READ | REGBREAK_WRITE))
            PUTS("RW ");
         else
            if (reg_breaks[temp].type == REGBREAK_READ)
               PUTS("R  ");
            else
               PUTS("W  ");
         if (reg_breaks[temp].low != reg_breaks[temp].high)
            sprintf(tempstr,"%03x -> %03x",
                      reg_breaks[temp].low,reg_breaks[temp].high);
         else
            sprintf(tempstr,"%03x",
                      reg_breaks[temp].low);
         PUTS(tempstr);
         len = 3 + strlen(tempstr);
         if (reg_breaks[temp].mask != 0xff)
            {
            sprintf(tempstr," & %02x",reg_breaks[temp].mask);
            PUTS(tempstr);
            len += 5;
            }
         if (reg_breaks[temp].have_value)
            {
            sprintf(tempstr," = %02x",reg_breaks[temp].value);
            PUTS(tempstr);
            len += 5;
            }
         for ( ; len < 26; len++)
            PUTS(space_str);
         if (((temp % 3) == 2) && (num_reg_breaks > temp))
            PUTS(nl_str);
         }
      PUTS(nl_str);
      }
   else
      PUTS("no reg breakpoints\n");
   }

void cmd_regs(whichcmd)  /* show registers */
   WORD whichcmd;
   {
   WORD temp, temp2, temp3;

   if (!cmdline[cmdptr])
      {
      show_processor_status(cmdlist[whichcmd].cmdvalue == CMD_ALLREGS ? FALSE : TRUE);
      return;
      }
   temp = cmdptr;  /* save current index into cmdline */
   parse(tempstr);  /* save copy of next parameter */
   if (strcmpi(tempstr,"w") == 0)
      temp = 1;  /* flag: W register is source/dest */
   else
      if (strcmpi(tempstr,"ip") == 0)
         temp = 2;  /* flag: IP register is source/dest */
      else
         {
         cmdptr = temp;  /* resetore cmdline index */
         temp = 0;  /* flag: normal register */
         }
   if ((!temp) && ((!get_word(&temp2)) || (temp2 >= NUM_REGS)))
      {
      cmdline_error("reg?");
      return;
      }
   skip_cmd_spaces();
   if (!cmdline[cmdptr])  /* if no value, show current value */
      {
      if (temp)  /* W / IP flag */
         sprintf(tempstr,"%02x\n", (temp == 1) ? w : ip);
      else
         sprintf(tempstr,"%02x\n",regs[xlate_regs[temp2]]);
      PUTS(tempstr);
      return;
      }
   if (!get_word(&temp3))
      {
      cmdline_error(value_str);
      return;
      }
   if (temp == 1)  /* if W */
      w = temp3;
   else
      if (temp == 2)  /* if IP */
         {
         if (temp3 >= MEMORY_SIZE)
            cmdline_error(range_str);
         else
            {
            setreg(PCL,temp3);  /* set PCL first, as it sets IP too! */
            ip = temp3;
            }
         }
      else
         setreg(temp2,temp3);  /* use setreg() instead of direct addressing
                                * in case of special hardware processing.
                                */
   }

void cmd_unasm(whichcmd)  /* unassemble */
   WORD whichcmd;
   {
   WORD temp, temp2;

   temp = unasm_ip;  /* default values */
   temp2 = (unasm_ip + 20) & MEMORY_MASK;
   if (get_address_range(&temp,&temp2,20,FALSE,FALSE))  /* parse command line */
      {
      unassemble(temp,temp2);
      unasm_ip = temp2 + 1;  /* default for next pass */
      }
   }

void cmd_asm(whichcmd)  /* assemble */
   WORD whichcmd;
   {
   WORD temp, temp2, i;
   BYTE prompt[8];

   if ((!get_word(&asm_ip))
            || (asm_ip >= MEMORY_SIZE))
      {
      cmdline_error(address_str);
      return;
      }
   do
      {
      update_windows();
      hexword(asm_ip,prompt);  /* use address as prompt */
      prompt[4] = ' ';
      prompt[5] = '\0';  /* and a space for neatness */
      getstr(prompt,cmdline);
      cmdptr = 0;        /* reset cmdline ptr */
      skip_cmd_spaces();
      temp = cmdptr;    /* remember where we started */
      if (cmdline[cmdptr])  /* if not blank line */
         {
         if ((temp2 = assembler()) != ASM_INVALID)
            {
            if (temp2 == ASM_ORG)
               asm_ip = *(WORD *)browse_screen;
            else
               {
               if (temp2 == ASM_DATA)
                  {
                  for (i = 0; i < *(WORD *)browse_screen; i++)
                     {
                     memory[asm_ip] = *(WORD *)&browse_screen[i+i+2];
                     asm_ip = (asm_ip + 1) & MEMORY_MASK;
                     }
                  }
               else
                  {
                  memory[asm_ip] = temp2;
                  asm_ip = (asm_ip + 1) & MEMORY_MASK;
                  }
               }
            }
         }
      } while (cmdline[temp]);  /* until blank line */
   }

void get_sim_time()
   {
   if (simulated_time < 1.0e-6)  /* if in ns range */
      sprintf(&tempstr[strlen(tempstr)],"  sim time=%.2lfns\n",simulated_time*1.0e9);
   else
      if (simulated_time < 1.0e-3)  /* if in us range */
         sprintf(&tempstr[strlen(tempstr)],"  sim time=%.2lfus\n",simulated_time*1.0e6);
      else
         if (simulated_time < 1.0)  /* if in MS range */
            sprintf(&tempstr[strlen(tempstr)],"  sim time=%.2lfms\n",simulated_time*1000.0);
         else
            sprintf(&tempstr[strlen(tempstr)],"  sim time=%.2lfs\n",simulated_time);
   }

      /*
       *  Yah, this is an ugly routine.  But I was having problems with the
       *  actual signed nature of a DWORD, so I had to split this up into
       *  WORDS, which are unsigned.
       */
double ic_to_double(ic)
   WORD *ic;  /* passed as a ptr to DWORD[2], I use it as a ptr WORD[4] */
   {
   return(
             (double)(*ic)
           + (double)(*(ic+1)) * 65536.0
           + (double)(*(ic+2)) * 4294967296.0
           + (double)(*(ic+3)) * 2.81474976711E14
         );
   }

void get_total_str()   /* build "total: ..." string */
   {
   double d_ic;

   strcpy(tempstr,"total: ic=");
   hexqword(total_ic,&tempstr[10]);
   d_ic = ic_to_double(total_ic);
   if (totalticks)
      {
      sprintf(&tempstr[strlen(tempstr)],"  time=%.2lfs  IPS=%.0lf",
               (double)totalticks/18.2,
               d_ic/(double)totalticks*18.2);
      }
   simulated_time = d_ic * 4.0 / (double)frequency;
   get_sim_time();
   }

void get_delta_str()
   {
   double d_ic;

   strcpy(tempstr,"delta: ic=");
   hexqword(instructioncount,&tempstr[10]);
   d_ic = ic_to_double(instructioncount);
   if (startticks != endticks)
      {
      sprintf(&tempstr[strlen(tempstr)],"  time=%.2lfs  IPS=%.0lf",
         ((double)endticks-(double)startticks)/18.2,
         d_ic/((double)endticks-(double)startticks)*18.2);
      }
   simulated_time = d_ic * 4.0 / (double)frequency;
   get_sim_time();
   }

void get_stopw_str()
   {
   double d_ic;


   strcpy(tempstr,"stopw: ic=");
   hexqword(stopwatchcount,&tempstr[10]);
   d_ic = ic_to_double(stopwatchcount);
   if (stopwatchticks)
      {
      sprintf(&tempstr[strlen(tempstr)],"  time=%.2lfs  IPS=%.0lf",
               (double)stopwatchticks/18.2,
               d_ic/(double)stopwatchticks*18.2);
      }
   simulated_time = d_ic * 4.0 / (double)frequency;
   get_sim_time();
   }

void show_break_type()
   {
   PUTS("Breakpoint: ");
   PUTS(breakstrings[breakpoint]);
   PUTS(nl_str);
   }

void show_processor_status(use_showregs)  /* do common "after run" processing */
   WORD use_showregs;
   {
   num_reg_breakpoints = 0;
   get_total_str();
   PUTS(tempstr);
/*
   if ((total_ic[0] != instructioncount[0]) || (total_ic[1] != instructioncount[1]))
      {
*/
      get_delta_str();
      PUTS(tempstr);
/*
      }
*/
   get_stopw_str();
   PUTS(tempstr);
   regdump(use_showregs);
   show_instr(ip);
   }

void cmd_go(whichcmd)  /* Go! */
                       /* Proceede over current statement */
                       /* CHECKPoint */
                       /* RETurn */
   WORD whichcmd;
   {
   WORD temp, temp1, temp2, temp3;
   WORD total_count;
   int i;  /* I want this SIGNED */
   WORD doing_checkpoint;
   WORD num_chks;
   WORD chk_ptrs[32];
   WORD skipone, did_skipone;
   BYTE chkptcmds[STRING_SIZE];  /* save area for checkpoint command string */

   breakcount[0] = 0xffffffff;  /* fake a 64-bit INT */
   breakcount[1] = 0xffffffff;
   doing_checkpoint = FALSE;
   if (cmdlist[whichcmd].cmdvalue == CMD_CHKPOINT)
      {
      if (outputfile == 0)
         {
         PUTS("Output not active, doing regular Go\n");
         }
      else
         {
         doing_checkpoint = TRUE;
         num_chks = 0;
         for (temp = cmdptr; (cmdline[temp]) && (cmdline[temp] != ';'); temp++)
            ;  /* the FOR loop does it all */
         if ((cmdline[temp] == ';') && (cmdline[temp+1]))
            {
            strcpy(chkptcmds,&cmdline[temp+1]);
            cmdline[temp] = '\0';
            }
         else
            {
#ifdef EEPROM_SIZE
            strcpy(chkptcmds,"allr;ee;w;u ip");
#else
            strcpy(chkptcmds,"allr;w;u ip");
#endif  /* EEPROM_SIZE */
            }
         temp = 0;
         do
            {
            if (chkptcmds[temp])
               {
               chk_ptrs[num_chks++] = temp;
               while ((chkptcmds[temp]) && (chkptcmds[temp] != ';'))
                  temp++;
               if (chkptcmds[temp])
                  chkptcmds[temp++] = '\0';
               if (!chkptcmds[temp])
                  break;
               }
            } while (num_chks < 30);
         }
      }
   num_mem_breakpoints = 0;  /* number of breakpoints */
   tickcount = 0;  /* default to no timed run */
   if (cmdlist[whichcmd].cmdvalue == CMD_PROCEEDE)
      {
      mem_breaks[0].low =
      mem_breaks[0].high = (ip + 1) & MEMORY_MASK;
      num_mem_breakpoints = 1;
      }
   if (cmdlist[whichcmd].cmdvalue == CMD_RETURN)
      {
      if (stack_depth == 0)
         {
         cmdline_error("Stack is empty");
         return;
         }
#ifdef CORE_12BIT
      mem_breaks[0].low =
      mem_breaks[0].high = stack[0];
#else
      temp = stack_ptr - 1;
      if (!stack_ptr)
         temp = STACK_SIZE - 1;
      mem_breaks[0].low =
      mem_breaks[0].high = stack[temp];
#endif  /* CORE_12BIT */
      num_mem_breakpoints = 1;
      }
   if (cmdline[cmdptr])  /* if we can have a break addr or tickcount */
      {
      for (temp = num_mem_breakpoints;
                   temp < (MAX_MEM_BREAKS-MAX_STICKY_BREAKS); temp++)
         {
         skip_cmd_spaces();
         if (strncmpi(&cmdline[cmdptr],time_str,strlen(time_str)) == 0)
            {
            cmdptr += strlen(time_str);  /* skip this */
            if ((!get_word(&tickcount)) || (tickcount == 0))
               {
               cmdline_error(number_str);
               return;
               }
            temp--;  /* don't count this in breakpoints */
            continue;  /* try next parameter */
            }
         if (strncmpi(&cmdline[cmdptr],ic_str,strlen(ic_str)) == 0)
            {
            cmdptr += strlen(ic_str);  /* skip this */
            total_count = FALSE;
            if (toupper(cmdline[cmdptr]) == 'T')  /* if a TOTAL count */
               {
               total_count = TRUE;
               cmdptr++;  /* skip the 'T' */
               }
            if (!cmdline[cmdptr])
               {
               cmdline_error(number_str);
               return;
               }
            if (!get_qword(breakcount))
               return;
            if (total_count)  /* if TOTAL IC for breakcount */
               {
               if ((breakcount[1] < total_ic[1])
                       || ((breakcount[1] == total_ic[1]) && (breakcount[0] < total_ic[0])))
                  {
                  PUTS("Bad break count\n");
                  return;
                  }
#asm
   mov  ax,word total_ic_     ;breakcount = breakcount - total_ic
   sub  word breakcount_,ax   ;done in 64-bit arithmetic
   mov  ax,word total_ic_[2]
   sbb  word breakcount_[2],ax
   mov  ax,word total_ic_[4]
   sbb  word breakcount_[4],ax
   mov  ax,word total_ic_[6]
   sbb  word breakcount_[6],ax
#endasm
               }
            temp--;  /* don't count this in breakpoints */
            continue;  /* try next parameter */
            }
         if ((temp1 = get_break_range(&temp2,&temp3,MEMORY_SIZE-1)) == 0)
            {
            mem_breaks[temp].low = temp2;
            mem_breaks[temp].high = temp3;
            }
         else
            break;
         }
      if (temp1 == 1)  /* if a bad number */
         return;  /* don't do G / P */
      num_mem_breakpoints = temp;
      }
   if ((use_sticky_breaks) && (num_sticky_breaks))
      {
      for (temp = 0; temp < num_sticky_breaks; temp++, num_mem_breakpoints++)
         {
         mem_breaks[num_mem_breakpoints].low = sticky_breaks[temp].low;
         mem_breaks[num_mem_breakpoints].high = sticky_breaks[temp].high;
         }
      }
   num_reg_breakpoints = 0;
   if (reg_breakpoints_on)
      num_reg_breakpoints = num_reg_breaks;
   did_skipone =
   skipone = FALSE;
   have_tickcount = tickcount;
   if (doing_checkpoint)
      {
      breakcount[0] = 0xffffffff;  /* fake a 64-bit INT */
      breakcount[1] = 0xffffffff;
      }
   do
      {
      tickcount = have_tickcount;
      breakpoint = BRK_NONE;
      if (skipone)
         {
         breakcount[0] = 1;  /* fake a 64-bit INT */
         breakcount[1] = 0;
         temp = num_mem_breakpoints;
         num_mem_breakpoints = 0;
         execute();
         num_mem_breakpoints = temp;
         breakcount[0] = 0xffffffff;  /* fake a 64-bit INT */
         breakcount[1] = 0xffffffff;
         }
      else
         {
/*         godoit(); */
         execute();
         totalticks += endticks - startticks;
         stopwatchticks += endticks - stopwatch_startticks;
         show_break_type();
         if (did_skipone)
            if (instructioncount[0]++ == 0xffffffff)
               instructioncount[1]++;
         }
      if (vesamode)
         window_data[WINDOW_DISASM].startnum = (ip - 5) & MEMORY_MASK;
      else
         window_data[WINDOW_DISASM].startnum = ip;
      window_data[WINDOW_WHERE].startnum = window_data[WINDOW_WHERE].numrows;
      update_windows();
      if ((doing_checkpoint) && (breakpoint != BRK_KEYPRESS)
#ifdef USE_ADDRLIST
                             && (breakpoint != BRK_ADDRLIST)
#endif  /* USE_ADDRLIST */
         )
         {
         if ((!skipone) || (breakpoint != BRK_COUNT))
            for (temp = 0; temp < num_chks; temp++)
               {
               strcpy(cmdline,&chkptcmds[chk_ptrs[temp]]);
               cmdptr = 0;
               if (((temp1 = parse_command()) != CMD_NOTFOUND)
                       && (cmdlist[temp1].chkpt_ok))
                  (*cmdlist[temp1].cmdfn)(temp1);
               }
         did_skipone = skipone;
         skipone = FALSE;
         if (breakpoint == BRK_MEMORY)
            skipone = TRUE;  /* skip over this breakpoint */
         if (csts())
            if (ci() == ESC)
               break;
         }
      } while ((doing_checkpoint) && (breakpoint != BRK_KEYPRESS)
#ifdef USE_ADDRLIST
                                  && (breakpoint != BRK_ADDRLIST)
#endif  /* USE_ADDRLIST */
              );
   breakpoint = BRK_NONE;
   if (!windowmode)
      show_processor_status(TRUE);  /* do common "after run" processing */
   }

void cmd_execute(whichcmd)  /* Execute! */
   WORD whichcmd;
   {
   WORD total_count;

   num_mem_breakpoints = 0;  /* number of breakpoints */
   tickcount = 0;  /* default to no timed run */
   if ((use_sticky_breaks) && (num_sticky_breaks))
      {
      for (num_mem_breakpoints = 0; num_mem_breakpoints < num_sticky_breaks; num_mem_breakpoints++)
         {
         mem_breaks[num_mem_breakpoints].low = sticky_breaks[num_mem_breakpoints].low;
         mem_breaks[num_mem_breakpoints].high = sticky_breaks[num_mem_breakpoints].high;
         }
      }
   total_count = FALSE;
   if (strncmpi(&cmdline[cmdptr],time_str,strlen(time_str)) == 0)
      {
      cmdptr += strlen(time_str);  /* skip this */
      if ((!get_word(&tickcount)) || (tickcount == 0))
         {
         cmdline_error(number_str);
         return;
         }
      skip_cmd_spaces();
      }
   if (toupper(cmdline[cmdptr]) == 'T')  /* if a TOTAL count */
      {
      total_count = TRUE;
      cmdptr++;  /* skip the 'T' */
      }
   breakcount[0] = 0xffffffff;  /* fake a 64-bit INT */
   breakcount[1] = 0xffffffff;
   if (!get_qword(breakcount))
      return;
   if (total_count)  /* if TOTAL IC for breakcount */
      {
      if ((breakcount[1] < total_ic[1])
              || ((breakcount[1] == total_ic[1]) && (breakcount[0] < total_ic[0])))
         {
         PUTS("Bad break count\n");
         return;
         }
#asm
   mov  ax,word total_ic_     ;breakcount = breakcount - total_ic
   sub  word breakcount_,ax   ;done in 64-bit arithmetic
   mov  ax,word total_ic_[2]
   sbb  word breakcount_[2],ax
   mov  ax,word total_ic_[4]
   sbb  word breakcount_[4],ax
   mov  ax,word total_ic_[6]
   sbb  word breakcount_[6],ax
#endasm
      }
   skip_cmd_spaces();
   if ((cmdline[cmdptr]) && (strncmpi(&cmdline[cmdptr],time_str,strlen(time_str)) == 0))
      {
      cmdptr += strlen(time_str);  /* skip this */
      if ((!get_word(&tickcount)) || (tickcount == 0))
         {
         cmdline_error(number_str);
         return;
         }
      }
   num_reg_breakpoints = 0;
   if (reg_breakpoints_on)
      num_reg_breakpoints = num_reg_breaks;
   have_tickcount = tickcount;
   execute();
   totalticks += endticks - startticks;
   stopwatchticks += endticks - stopwatch_startticks;
   show_break_type();
   breakpoint = BRK_NONE;
   if (!windowmode)
      show_processor_status(TRUE);  /* do common "after run" processing */
   if (vesamode)
      window_data[WINDOW_DISASM].startnum = (ip - 5) & MEMORY_MASK;
   else
      window_data[WINDOW_DISASM].startnum = ip;
   window_data[WINDOW_WHERE].startnum = window_data[WINDOW_WHERE].numrows;
   }

void cmd_trace(whichcmd)  /* Trace (step), optionally N instructions */
                     /* TrueTrace, optionally N instructions including NOPs */
   WORD whichcmd;
   {
   WORD count, trueflag;

   trueflag = FALSE;
   if (cmdlist[whichcmd].cmdvalue == CMD_TRACETRUE)
      trueflag = TRUE;
   count = 1;  /* number to trace */
   if (!get_word(&count))
      return;
   num_mem_breakpoints = 0;  /* number of breakpoints */
   num_reg_breakpoints = 0;
   for (breakpoint = BRK_NONE; (count) && (breakpoint != BRK_COUNT); count--)
      {
      breakcount[0] = 1;  /* fake a 64-bit INT */
      breakcount[1] = 0;
      execute();
      if (breakpoint != BRK_COUNT)
         {
         show_break_type();
         count = 1;  /* don't do multiple traces if at a breakpoint */
         }
      regdump(TRUE);
      show_instr(ip);
      if (count > 1)
         if (csts())
            if (ci() == ESC)
               break;
      if (trueflag)
         while (timingcount > 1)
            {
            timingcount--;
            if (!(--count))
               {
               count = 1;  /* need to exit for() loop, too! */
               break;
               }
            }
      breakpoint = BRK_NONE;
      }
   if (vesamode)
      window_data[WINDOW_DISASM].startnum = (ip - 5) & MEMORY_MASK;
   else
      window_data[WINDOW_DISASM].startnum = ip;
   window_data[WINDOW_WHERE].startnum = window_data[WINDOW_WHERE].numrows;
   }

void cmd_help(whichcmd)  /* hope you're not depending on this... */
   WORD whichcmd;
   {
   WORD index, len, linepos;
   BYTE onechar[2];
   WORD savedcmdptr;
   int  fp;             /* Help file descriptor */
   BYTE tempstr[128];   /* Line read from the help file */
   BYTE helpfound = FALSE;  /* Flag to know if the command was found in the help file */
   BYTE amongnames = TRUE; /* Flag to know if still reading command names */
   BYTE linecount = 0;  /* Printed lines counter for page breaking */

   /* Print help on specified command if available */
   savedcmdptr = cmdptr;
   if ((whichcmd = parse_command()) != CMD_NOTFOUND)
      {
      /* Valid command - print corresponding help */
      if (((fp = open(helpname, 0)) != -1)
            || ((fp = open(helpfile, 0)) != -1))
         {
         /* Look for correct entry and print help */
         while (fgets(tempstr,126,fp))
            {
            if (!strncmp(cmdlist[whichcmd].cmdname, tempstr+1, strlen(cmdlist[whichcmd].cmdname))
                                && (tempstr[0] == '@')) /* Entry found */
               {
               helpfound = TRUE;
               break;
               }
            }
         if (helpfound) /* It should be always true */
            {
            while ((fgets(tempstr,126,fp)) && ((tempstr[0] != '@') || (amongnames)))
               {
               if (tempstr[0] != '@') /* Name list finished */
                  {
                  amongnames = FALSE;
                  PUTS(tempstr);
                  if (++linecount == 24)
                     {
                     PUTS("-- More --");
                     if (getchar() == ESC)
                        break;
                     PUTS(nl_str);
                     linecount = 0;
                     }
                  }
               }
            }
         else
            PUTS("Error in help file.\n"); /* Command was supposed to be in the file but it isn't */
         close(fp);
         }
      else
         PUTS("Error opening help file.\n"); /* HELPxxx.DAT is not here... */
      }
   else
      { /* Print command list */
      onechar[1] = '\0';  /* terminate string */
      linepos = 0;
      for (index = 0; cmdlist[index].matchlen; index++)
         {
         if (linepos + strlen(cmdlist[index].cmdname) > 75)
            {
            PUTS(nl_str);
            linepos = 0;
            }
         for (len = 0; cmdlist[index].cmdname[len]; len++)
            {
            onechar[0] = (len >= cmdlist[index].matchlen) ? cmdlist[index].cmdname[len] : toupper(cmdlist[index].cmdname[len]);
            PUTS(onechar);
            }
         /* There must be at least a space between commands... */
         linepos += len + 1;
         PUTS(space_str);
         /* Align to 13th columns */
         while (linepos % 13)
            {
            PUTS(space_str);
            linepos++;
            }
         }
      PUTS("\nEnter HELP HELP to read the \"Help on Help\".\n");
      }
   PUTS(nl_str);
   }

void cmd_calc(whichcmd)  /* play calculator */
   WORD whichcmd;
   {
   WORD temp;

   if ((cmdline[cmdptr]) && (get_word(&temp)))
      {
      PUTS(hexword(temp,tempstr));
      PUTS(nl_str);
      }
   else
      cmdline_error(number_str);
   }

void cmd_where(whichcmd)  /* how did I get here? */
   WORD whichcmd;
   {
   WORD number, index;

   if (!(total_ic[0] | total_ic[1]))
      {
      PUTS("No instructions have been executed.\n");
      return;
      }
   number = 16;  /* number to backtrace */
   if (!get_word(&number))
      return;
   if ((!total_ic[1]) && (number > total_ic[0]))
      number = total_ic[0]; /* max of number of instrs executed */
   index = (whereptr + (WHERE_SIZE+1 - number)) & WHERE_SIZE;  /* get start */
   for ( ; number; number--)
      {
      if (wherequeue[index] < MAX_MEMORY_SIZE)
         show_instr(wherequeue[index]);
      index = (index + 1) & WHERE_SIZE;
      if (csts())  /* csts() --> TRUE if key waiting, else FALSE */
         if (ci() == ESC)   /* ci() --> get key, wait if necessary */
            number = 1;  /* break loop */
      }
   }

void cmd_output(whichcmd)  /* echo output to file */
   WORD whichcmd;
   {
   if (outputfile)
      {
      close(outputfile);
      outputfile = 0;
      }
   if (cmdline[cmdptr])
      {
      if ((outputfile = open(&cmdline[cmdptr],2)) != -1)
         lseek(outputfile,0L,2);
      else
         if ((outputfile = creat(&cmdline[cmdptr])) == -1)
            {
            cmdline_error(name_str);
            outputfile = 0;
            }
      }
   }

void cmd_input(whichcmd)  /* get input from a file */
   WORD whichcmd;
   {
   if (inputfile)
      {
      close(inputfile);
      inputfile = 0;
      }
   if (cmdline[cmdptr])
      {
      if ((inputfile = open(&cmdline[cmdptr],0)) == -1)
         {
         PUTS(&cmdline[cmdptr]);
         PUTS(" not found!\n");
         inputfile = 0;
         }
      else
         {
         inputfilesize = lseek(inputfile,0L,2);  /* get size of input file */
         lseek(inputfile,0L,0);  /* back to start of file */
         }
      }
   }

void cmd_pause(whichcmd)
   WORD whichcmd;
   {
   if ((inputfile) && (!outputfile))
      {
      PUTS(press_any_esc);
      if (ci() == ESC)
         {
         close(inputfile);
         inputfile = 0;
         }
      PUTS(nl_str);
      }
   }

void cmd_create(whichcmd)  /* create binary file */
   WORD whichcmd;
   {
   int fout;  /* temporary file handle */
              /* NOTE: For DeSmet C (aka PCC) a FILE is just an int */

   if (!parse(tempstr))
      {
      cmdline_error(name_str);
      return;
      }
   if ((fout = open(tempstr,0)) != -1)
      {
      close(fout);
      PUTS(tempstr);
      getstr(" already exists. Overwrite it (Y/N)? ",cmdline);
      cmdptr = 0;  /* init cmdline ptr */
      skip_cmd_spaces();
      if (toupper(cmdline[cmdptr]) != 'Y')
         return;
      }
   if ((fout = creat(tempstr)) == -1)
      {
      PUTS("unable to create ");
      PUTS(tempstr);
      PUTS(nl_str);
      return;
      }
   memfill(&picfile_hdr,sizeof(picfile_hdr),0);  /* erase this */
   strcpy(picfile_hdr.program_id,picemu_str);  /* identify file owner */
   strcpy(picfile_hdr.pictype,processor);   /* set processor type */
   picfile_hdr.filetype = FILETYPE_BIN;  /* binary file */
   picfile_hdr.memsize = MEMORY_SIZE;
   picfile_hdr.version = PICFILE_VERSION;
   if (write(fout,&picfile_hdr,sizeof(picfile_hdr)) != sizeof(picfile_hdr))
      {
      close(fout);
      unlink(tempstr);  /* don't keep bad files around */
      PUTS(cannot_write_str);
      return;
      }
   if (write(fout,memory,MEMORY_SIZE << 1) != (MEMORY_SIZE << 1))
      {
      close(fout);
      unlink(tempstr);  /* don't keep bad files around */
      PUTS(cannot_write_str);
      return;
      }
   if (close(fout) == -1)  /* if bad write of buffered output */
      {
      unlink(tempstr);  /* don't keep bad files around */
      PUTS(cannot_write_str);
      }
   }

void cmd_wake(whichcmd)  /* WAKE UP! */
   WORD whichcmd;
   {
   if (sleepmode)
      {
      PUTS("Processor awakened");
      if (cmdline[cmdptr])
         {
         PUTS(" (with status updates)");
         regs[STATUS] &= ~(STATUS_PD | STATUS_TO);
         watchdog = watchdog_reset_count;
         }
      PUTS(nl_str);
      }
   else
      PUTS("Processor already awake\n");
   sleepmode = FALSE;
   }

reset_oscope_logical()
   {
   WORD i, pinmask, portnum;

   for (i = 0; i < oscope_lines; i++)
      {
      pinmask = oscope_pinmasks[i];
      portnum = oscope_ports[i];
      if (oscope_lasttris[i] = regs[TRISA+portnum] & pinmask)
         oscope_lastport[i] = input_ports[portnum] & pinmask;
      else
         oscope_lastport[i] = regs[PORTA+portnum] & pinmask;
      }
   }

void cmd_reset(whichcmd)  /* reset processor, but not memory/eeprom */
   WORD whichcmd;
   {
   WORD i, temp, temp2;
   WORD save_oscope_lines;
   DWORD hold;

   if (whichcmd != CMD_NOTFOUND)  /* if called as a user command */
      {
      if (parse(fh2))  /* if a parameter */
         {
         if (strcmpi(fh2,"rand") == 0)  /* put in random values */
            {
            for (i = NUM_REGS-1; i; i--)
               setreg(i,rand());
            }
         else
            {
            if ((!fromhex(fh2,&hold)) || (hold > 0xff))
               {
               cmdline_error(number_str);
               return;
               }
            for (i = NUM_REGS-1; i; i--)
               setreg(i,(WORD)hold);
            }
         }  /* if a command line parameter */
      }  /* if (whichcmd != CMD_NOTFOUND) */
   save_oscope_lines = oscope_lines;
   oscope_lines = 0;
   reset(TRUE);  /* TRUE --> reset (soft)uart screen */
   total_ic[0] = 0;  /* fake a 64-bit int */
   total_ic[1] = 0;
   instructioncount[0] = 0;  /* fake a 64-bit int */
   instructioncount[1] = 0;
   stopwatchcount[0] = 0;  /* fake a 64-bit int */
   stopwatchcount[1] = 0;
   startticks = 0;
   endticks = 0;  /* reset time */
   totalticks = 0;  /* reset total time */
   stopwatchticks = 0;
   su_txlastbit = su_txbitmask;  /* default to HIGH */
   su_txtiming = 0;
   su_rxtiming = 0;  /* clear SoftUart */
   if (vesamode)
      window_data[WINDOW_DISASM].startnum = (ip - 5) & MEMORY_MASK;
   else
      window_data[WINDOW_DISASM].startnum = ip;
   window_data[WINDOW_WHERE].startnum = window_data[WINDOW_WHERE].numrows;
#ifdef HAS_ADC
   adc_table_index = 0;
#endif  /* HAS_ADC */
   oscope_in = 0;
   oscope_out = 0;  /* reset ptrs */
   oscope_count = oscope_delay;
   for (i = 0; i < NUM_BYTE_PORTS; i++)
      lasttris[i] ^= 0xff;  /* reset all bits, force display of all ports */
   for (temp = 0; temp < NUM_BYTE_PORTS; temp++)
      {
      input_ports[temp] = 0;
      for (temp2 = 7; temp2 != -1; temp2--)
         {
         input_ports[temp] <<= 1;
         input_ports[temp] |= (initial_ports[temp][temp2] > SCHMITT_TRUE_LEVEL) ? 1 : 0;
         analog_ports[temp][temp2] = initial_ports[temp][temp2];
             /* set initial port values */
             /* NOTE: the initial values of all the TRIS registers are all 1 bits
              *       (all inputs).
              */
         }
      }
#ifdef CORE_12BIT
   last_t0cki = input_ports[0] << 2;  /* setup for next edge detect */
#else
   last_t0cki = input_ports[0];  /* setup for next edge detect */
   last_porta_in = input_ports[0];
   last_intpin = input_ports[0];
#endif  /* CORE_12BIT */
#ifdef HAS_PORTB
   last_portb_in = input_ports[1];
   last_portb = input_ports[1] & 0xf0;  /* reset port change interrupt info */
#endif  /* HAS_PORTB */
   oscope_lines = save_oscope_lines;
   reset_oscope_logical();
   }

#ifdef HAS_UART
void cmd_comm(whichcmd)   /* set COMM port for UART simulation */
   WORD whichcmd;
   {
   WORD portnum;

   if (!cmdline[cmdptr])
      {
      sprintf(tempstr,"COMM port used: %d\n",commport);
      PUTS(tempstr);
      return;
      }
   if (get_word(&portnum))
      {
      if (portnum > 4)
         cmdline_error(range_str);
      else
         {
         if (commport)  /* if not screen */
            {
            reset_comm_interrupt();  /* cleanup previous usage */
            reset_comm_port();
            }
         commport = portnum;
         commbase = commbase_table[commport];
         irqnum = irqnum_table[commport];
         tx_int_delay = 0;
         if (commport)  /* if not screen */
            {
            if (winnt)
               tx_int_delay = WINNT_INT_DELAY;
            take_comm_interrupt();  /* set new usage */
            save_comm_port();
            init_comm_port();
            }
         }  /* if (valid commport) */
      }  /* if (get new commport) */
   }
#endif  /* HAS_UART */

void cmd_chkstack(whichcmd)
   WORD whichcmd;
   {
   on_or_off(&chkstack);
   PUTS("Stack over/under flow check: ");
   if (chkstack)
      PUTS("ON\n");
   else
      PUTS("OFF\n");
   }

void cmd_watchdog(whichcmd)
   WORD whichcmd;
   {
   on_or_off(&chkwatchdog);
   PUTS("Watchdog expired check: ");
   if (chkwatchdog)
      PUTS("ON\n");
   else
      PUTS("OFF\n");
   }

void cmd_readtris(whichcmd)
   WORD whichcmd;
   {
   on_or_off(&readusestris);
   PUTS("Read Uses TRIS: ");
   if (readusestris)
      PUTS("ON\n");
   else
      PUTS("OFF\n");
   }

void cmd_watchregs(whichcmd)
   WORD whichcmd;
   {
   WORD num, temp, j;
   WORD templist[NUM_WATCHREGS];

   if (!cmdline[cmdptr])  /* if list */
      {
      if (!num_watch_regs)
         {
         PUTS("No watch regs\n");
         return;
         }
      for (num = 0; num < num_watch_regs; num++)
         {
         sprintf(tempstr,"%03x: %02x",watchregs[num],regs[xlate_regs[watchregs[num]]]);
         PUTS(tempstr);
         if ((num & 7) == 7)
            PUTS(nl_str);
         else
            PUTS("   ");
         }
      PUTS(nl_str);
      return;
      }
   num = 0;
   if (!windowmode)  /* if displayed in swap screen */
      {
      for (temp = SCREEN_ROWS-3-MAX_OSCOPE_LINES; temp < SCREEN_ROWS-MAX_OSCOPE_LINES; temp++)
         for (j = 0; j < SCREEN_COLS*2; j += 2)
            {
            uart_screen[temp*SCREEN_COLS*2+j] = 0x20;  /* space */
            uart_screen[temp*SCREEN_COLS*2+j+1] = 7;   /* normal attribute */
            }
      }
   if (strcmpi(&cmdline[cmdptr],off_str))  /* if we're not turning it off */
      {
      while ((cmdline[cmdptr]) && (num < NUM_WATCHREGS))
         {
         if ((!get_word(&temp)) || (temp >= NUM_REGS))
            {
            cmdline_error("reg?");
            return;
            }
         templist[num++] = temp;
         skip_cmd_spaces();
         }
      }
   for (num_watch_regs = 0; num_watch_regs < num; num_watch_regs++)
      watchregs[num_watch_regs] = templist[num_watch_regs];
   if ((!windowmode)                 /* if watchregs not already shown */
          && (uart_screen_maxrow >= SCREEN_ROWS-1-(NUM_WATCHREGS/8)-MAX_OSCOPE_LINES))
                                     /* and nothing 'above' us */
      {
      if (num_watch_regs)
         uart_screen_maxrow = SCREEN_ROWS
                                - (NUM_WATCHREGS/8) - MAX_OSCOPE_LINES;
      else
         {
         if (oscope_lines)
            uart_screen_maxrow = SCREEN_ROWS - oscope_lines;
         else
            uart_screen_maxrow = SCREEN_ROWS - 1;
         }
      if (screen_rowofs >= (uart_screen_maxrowofs = SCREEN_COLS * uart_screen_maxrow * 2))
         screen_rowofs = uart_screen_maxrowofs - SCREEN_COLS * 2;
      }
   }

void cmd_stopwatch(whichcmd)
   WORD whichcmd;
   {
   stopwatchcount[0] = 0;  /* fake a 64-bit int */
   stopwatchcount[1] = 0;
   stopwatchticks = 0;
#ifdef HAS_ADC
   adc_table_index = 0;
#endif  /* HAS_ADC */
   }

WORD valid_pin(port,pin,silent)  /* get pin from cmdbuf, see if valid */
   WORD *port, *pin;
   WORD silent;
   {
   DWORD hold;
   WORD valid, len;

   valid = parse(fh2);
#ifdef PINS_8
   if (valid)
      {
      *port = 0;
      if (((len = strlen(fh2)) == 3)
           && (strncmpi(fh2,gpio_str,2) == 0)
           && (fromhex(&fh2[2],&hold))
           && ((*pin = hold) < NUM_PORT_BITS)
           && (port_masks[*port] & (1 << *pin)))
         return(TRUE);
      }
#endif  /* PINS_8 */
   if ((!valid)
            || (
                 (toupper(fh2[0]) == 'R') ? 
                    (!fromhex(&fh2[1],&hold))
                  :
                    (!fromhex(fh2,&hold))
               )
            || (hold & 0xffffff00)
            || ((*port = (((WORD)hold >> 4) - 0x0a)) >= NUM_BYTE_PORTS)
            || ((*pin = ((WORD)hold & 0x0f)) > 7)
            || (!(port_masks[*port] & (1 << *pin))))
      {
      if (!silent)
         cmdline_error(syntax_str);
      return(FALSE);
      }
   return(TRUE);
   }

void cmd_oscope(whichcmd)  /* setup/show OSCOPE display */
/* oscope <delay> {<pin 1> ... <pin n>} */
/* oscope LOGICAL {<pin 1> ... <pin n>} */
/* oscope OFF */
/* oscope */  /* no parameters, show current info until keypress */
   WORD whichcmd;
   {
   WORD i, j, temp, warning;
   WORD pinmask, portnum;
   DWORD val;

   if (!cmdline[cmdptr])  /* no params, show OSCOPE display  */
      {
      if (!oscope_lines)  /* if no oscope setup */
         return;
      screen_swap();
      show_oscope();
      ci();
      screen_swap();
      return;
      }
   if (oscope_lines)  /* if previous OSCOPE in effect */
      {
      if (uart_screen_maxrow == SCREEN_ROWS - oscope_lines)
         uart_screen_maxrow = SCREEN_ROWS - 1;
      for (i = SCREEN_ROWS - oscope_lines; i < SCREEN_ROWS; i++)
         for (j = 0; j < SCREEN_COLS*2; j += 2)
            {
            uart_screen[i*SCREEN_COLS*2+j] = 0x20;  /* space */
            uart_screen[i*SCREEN_COLS*2+j+1] = 7;   /* normal attribute */
            }
      }
   uart_screen_maxrowofs = SCREEN_COLS * uart_screen_maxrow * 2;
   oscope_lines = 0;  /* clear OSCOPE */
   oscope_count = 0;
   oscope_in = 0;
   oscope_out = 0;
   oscope_logical = FALSE;
   if (strcmpi(&cmdline[cmdptr],off_str) == 0)  /* if we're turning it off */
      return;
   warning = FALSE;
   temp = cmdptr;
   skip_cmd_spaces();
   if ((toupper(cmdline[cmdptr]) != 'R') && (valid_pin(&i,&j,TRUE)))
      warning = TRUE;
   cmdptr = temp;
   if ((!parse(fromhexstr)) || (!fromhex(fromhexstr,&val)))
      {
      cmdline_error(syntax_str);
      return;
      }
   for (i = 0; (i < MAX_OSCOPE_LINES) && (cmdline[cmdptr]); i++)
      {
      if (!valid_pin(&oscope_ports[i],&oscope_pins[i],FALSE))
         return;
      oscope_pinmasks[i] = bittable[oscope_pins[i]];  /* mask for this bit */
      }
   if (i)  /* if pins given */
      {
      oscope_lines = i;    /* set number of pins to display */
      oscope_count = val;  /* set count of cycles until update */
      oscope_delay = val;  /* to reset oscope_count */
      if (!val)
         {
         oscope_logical = TRUE;
         reset_oscope_logical();
         }
      if (uart_screen_maxrow == SCREEN_ROWS - 1)
         uart_screen_maxrow = SCREEN_ROWS - oscope_lines;
      oscope_video_addr = (window_data[WINDOW_COMMAND].startrow + window_data[WINDOW_COMMAND].numrows - oscope_lines) * bytesperline
                + (window_data[WINDOW_COMMAND].startcol << 1);
      if (screen_rowofs >= (uart_screen_maxrowofs = SCREEN_COLS * uart_screen_maxrow * 2))
         screen_rowofs = uart_screen_maxrowofs - SCREEN_COLS * 2;
      if (warning)
         PUTS("Warning: did you forget the frequency?\n");
      }
   else
      cmdline_error(syntax_str);
   }

WORD dword_ge(first,second)   /* TRUE if first >= second, else FALSE */
   DWORD first, second;  /* DeSmet doesn't do a native UNSIGNED LONG compare */
       /* BP+4   BP+8 */
   {
#asm
   mov  ax,word [bp+4]
   mov  dx,word [bp+6]   ;get first
   sub  ax,word [bp+8]
   sbb  dx,word [bp+10]  ;first - second
   mov  ax,1             ;default to TRUE
   jae  dword_ge_done    ;if NC, that's all
   dec  ax               ;set FALSE
dword_ge_done:
#endasm
   }

void cmd_stimulus(whichcmd)
   WORD whichcmd;
   {
   WORD stim_ports[NUM_PORT_BITS+1], stim_pins[NUM_PORT_BITS+1];
   BYTE stim_val[NUM_PORT_BITS+1];
   WORD num_ports, num_vals;
   WORD pinval, i;
   DWORD hold;
   WORD cycleflag;  /* if TRUE, counts are ABSOLUTEs instead of DELTAs */

   if (!parse(tempstr))
      {
      cmdline_error(syntax_str);
      return;
      }
   if (strcmpi(tempstr,off_str) == 0)
      {
      num_stimulus = 0;
      return;
      }
   if ((filein = open(tempstr,0)) == -1)
      {
      cmdline_error("cannot find stimulus file");
      return;
      }
   /*  Note:  we're going to use cmdline as the file buffer to re-use the
    *         command parsing logic.
    */
   num_stimulus = 0;
   periodic_stim = FALSE;
   memfill(stimulus,sizeof(stimulus),0);  /* clear stimulus info */
   do
      {
      if (!fgets(cmdline,STRING_SIZE-1,filein))  /* 1st line, get "headers" */
         {
         PUTS("no stimulus in file\n");
         close(filein);
         return;
         }
      cmdptr = 0;
      skip_cmd_spaces();
      } while ((cmdline[cmdptr] == ';')
                  || (cmdline[cmdptr] == '!')
                  || (cmdline[cmdptr] == '\0'));
   cycleflag = TRUE;
   if ((!parse(tempstr))
         || ((strcmpi(tempstr,"cycle"))
                   && (cycleflag = strcmpi(tempstr,"step"))
                   && (!(periodic_stim = !strcmpi(tempstr,"periodic")))
            )
      )
      {
      PUTS(invalid_stim_file);
      PUTS(cmdline);
      PUTS("\nunknown period type\n");
      close(filein);
      return;
      }
   num_ports = 0;
   memfill(stim_pinmasks,sizeof(stim_pinmasks),0);  /* clear pinmasks */
   while (num_ports < NUM_PORT_BITS+1)
      {
      if (valid_pin(&stim_ports[num_ports],&stim_pins[num_ports],TRUE))
         num_ports++;
      else
         {
         if ((fh2[0] == '!') || (fh2[0] == ';') || (!fh2[0]))
            break;
         num_ports = NUM_PORT_BITS+1;  /* flag invalid, exit loop */
         }
      }
   if ((!num_ports) || (num_ports == NUM_PORT_BITS+1))
      {
      PUTS(invalid_stim_file);
      PUTS(cmdline);
      PUTS("\nbad port number\n");
      close(filein);
      return;
      }
   for (i = 0; i < num_ports; i++)
      {
      if (stim_pinmasks[stim_ports[i]] & (1 << stim_pins[i]))
         {
         PUTS("Duplicate pin definition\n    ");
         PUTS(cmdline);
         close(filein);
         return;
         }
      stim_pinmasks[stim_ports[i]] |= 1 << stim_pins[i];
      }
   while ((fgets(cmdline,STRING_SIZE-1,filein)) && (num_stimulus <= MAX_STIMULUS_SIZE))
      {
      cmdptr = 0;  /* init parsing */
      if ((!parse(tempstr))  /* if blank line */
             || (tempstr[0] == '!') || (tempstr[0] == ';'))
         continue;
      if (num_stimulus == MAX_STIMULUS_SIZE)
         {
         PUTS("too many stimuli, truncated\n");
         break;
         }
      sscanf(tempstr,"%lu",&stimulus[num_stimulus].cyclecount);
      if (num_stimulus)  /* if not the first stimulus */
         {
         if ((!cycleflag)  /* if doing STEP */
                || (periodic_stim))
            stimulus[num_stimulus].cyclecount += stimulus[num_stimulus-1].cyclecount;
               /* get absolute cycle count */
         if (dword_ge(stimulus[num_stimulus-1].cyclecount,stimulus[num_stimulus].cyclecount))
            {
            PUTS("cycle count not increasing\n    ");
            PUTS(cmdline);
            num_stimulus = MAX_STIMULUS_SIZE + 1;  /* error flag */
            break;
            }
         }
      num_vals = 0;  /* make sure we have values for all pins on this line */
      while (parse(fh2))
         {
         if ((fh2[0] == '!') || (fh2[0] == ';'))  /* if a comment */
            break;   /* ignore rest of this line */
         if (num_vals == num_ports)  /* if too many values */
            {
            num_vals++;  /* make sure we have an error flag */
            break;
            }
         if (!fromhex(fh2,&hold))
            {
            num_vals = num_ports + 1;  /* setup an error flag */
            break;
            }
         if ((strlen(fh2) == 1) && (fh2[0] == '1'))
            hold = 0xffff;  /* force max analog value */
         stimulus[num_stimulus].pinvals[stim_ports[num_vals]][stim_pins[num_vals]] = (WORD)hold;
         num_vals++;
         }
      if (num_vals != num_ports)  /* if wrong number of values */
         {
         PUTS("Bad pin value(s)\n    ");
         PUTS(cmdline);
         num_stimulus = MAX_STIMULUS_SIZE + 1;  /* flag error */
         break;
         }
      num_stimulus++;  /* count this stimulus line */
      }
   if (num_stimulus == MAX_STIMULUS_SIZE+1)  /* if error */
      num_stimulus = 0;
   close(filein);
   }

#ifdef HAS_ADC
void cmd_adc(whichcmd)  /* load file of ADC values */
   WORD whichcmd;
   {
   if (!parse(tempstr))  /* no filename given */
      {
      cmdline_error(name_str);
      return;
      }
   adc_table_index = 0;
   adc_table_size = 0;
   if (strcmpi(tempstr,off_str) == 0)
      return;
   if ((filein = open(tempstr,0)) == -1)
      {
      cmdline_error("cannot find ADC file");
      return;
      }
   while ((fgets(cmdline,STRING_SIZE-1,filein)) && (adc_table_size < ADC_TABLE_MAXSIZE))
      {
      sscanf(cmdline,"%x",&adc_table[adc_table_size]);
#ifdef ADC_10BITS
      adc_table[adc_table_size++] &= 0x3ff;
#else
      adc_table[adc_table_size++] &= 0xff;
#endif  /* ADC_10BITS */
      }
   close(filein);
   }
#endif  /* HAS_ADC */

void cmd_screen(whichcmd)  /* Swap screens for UART/SOFTUart */
   WORD whichcmd;
   {
   if (cmdlist[whichcmd].cmdvalue == CMD_HEXSCREEN)
      on_or_off(&hex_uart_screen);
   else
      on_or_off(&swap_screens);
   sprintf(tempstr,"Screen swapping %s %s\n",
           swap_screens ? on_str : off_str,
           hex_uart_screen ? "HEX" : "Normal");
   PUTS(tempstr);
   }

void cmd_view(whichcmd)  /* view uart_screen / port_screen */
   WORD whichcmd;
   {
   WORD show_save;

   if (!cmdline[cmdptr])
      {
#ifdef HAS_UART
#else
      if (su_txenable)  /* if softuart not defined */
         {
         PUTS(no_soft_uart);
         return;
         }
#endif  /* HAS_UART */
      show_save = swap_screens;
      swap_screens = TRUE;
      screen_swap();
      ci();
      screen_swap();
      swap_screens = show_save;
      return;
      }
   if (toupper(cmdline[cmdptr]) == 'P')  /* if view ports */
      {
      show_save = show_ports;  /* don't care about show_ports, view */
      show_ports = TRUE;       /* will always show port status */
      screen_swap();
      io_processing();
      ci();
      screen_swap();
      show_ports = show_save;  /* restore show_ports */
      return;
      }
   cmdline_error(syntax_str);
   }

#ifdef CORE_14BIT
void cmd_regdisp(whichcmd)  /* Which regs to display */
   WORD whichcmd;
   {
   WORD temp, temp2;
   BYTE temp_show_regs[NUM_REGS];
   DWORD hold;

   for (temp = 0x20; temp < NUM_REGS; temp++)
      temp_show_regs[temp] = FALSE;  /* start off with NONE */
   for (temp = 0; temp < 0x20; temp++)
      temp_show_regs[temp] = TRUE;  /* show basic control regs */
   while (parse(fh2))
      {
      skip_cmd_spaces();
      if ((!fromhex(fh2,&hold)) || (hold >= NUM_REGS))
         {
         cmdline_error(range_str);
         return;
         }
      temp2 =
      temp = (WORD)hold;
      if (cmdline[cmdptr] == ',')  /* if a range */
         {
         if ((!parse(fh2)) || (!fromhex(fh2,&hold))
                          || (hold >= NUM_REGS)
                          || ((WORD)hold <= temp))
            {
            cmdline_error(range_str);
            return;
            }
         temp2 = (WORD)hold;
         }
      for ( ; temp <= temp2; temp++)
         temp_show_regs[temp] = TRUE;
      }
   for (temp = 0; temp < NUM_REGS; temp++)
      show_regs[temp] = temp_show_regs[temp];
   }
#endif  /* CORE_14BIT */

void cmd_frequ(whichcmd)  /* Frequency */
   WORD whichcmd;
   {
   DWORD ltemp;
   double fr, mult;
   WORD i;

   if (cmdline[cmdptr])
      {
      for (i = 0; (isdigit(cmdline[cmdptr])) || (cmdline[cmdptr] == '.')
                     || (cmdline[cmdptr] == ','); i++, cmdptr++)
         {
         if (cmdline[cmdptr] == ',')  /* if european decimal */
            cmdline[cmdptr] = '.';  /* change to US for sscanf */
         tempstr[i] = cmdline[cmdptr];
         }
      tempstr[i] = '\0';
      skip_cmd_spaces();
      mult = 1;  /* multiplier */
      if (cmdline[cmdptr])
         {
         if (cmdline[cmdptr] == 'k')
            mult = 1000;
         if (cmdline[cmdptr] == 'K')
            mult = 1024;
         if (toupper(cmdline[cmdptr]) == 'M')
            mult = 1000000;
         if (cmdline[cmdptr+1])  /* this had better be 'hz' */
            if (strncmpi(&cmdline[cmdptr+1],"hz"))
               {
               cmdline_error(syntax_str);
               return;
               }
         }
      sscanf(tempstr,"%lf",&fr);
      ltemp = fr * mult;
      if ((ltemp < 32000) || (ltemp > 20000000))
         cmdline_error("get real...");
      else
         {
         if (((!su_txenable) && (su_txbaud > ltemp/16))
                    || ((!su_rxenable) && (su_rxbaud > ltemp/16)))
            {
            cmdline_error(frequency_too_slow);
            return;
            }
         frequency = ltemp;
         ltemp = (frequency * 18L) / 4000L;
         if (ltemp > 65535L)
            watchdog_reset_count = 0;
         else
            watchdog_reset_count = 65535L - ltemp;
         if (!su_txenable)  /* if we have to deal with softuart frequencies */
            su_txbittiming = frequency / 4L / (DWORD)su_txbaud;  /* instrs/sec / (bits/sec) = instrs/bit */
         if (!su_rxenable)  /* if we have to deal with softuart frequencies */
            su_rxbittiming = frequency / 4L / (DWORD)su_rxbaud;
         }
      }
   else
      {
      if (frequency > 1000000)
         sprintf(tempstr,"CPU frequency %ld (%2.3lf MHz)\n",
            frequency,(double)frequency/1000000.0);
      else
         sprintf(tempstr,"CPU frequency %ld (%3.3lf KHz)\n",
            frequency,(double)frequency/1000.0);
      PUTS(tempstr);
      }
   }

void cmd_throttle(whichcmd)  /* show/set "throttle" */
   WORD whichcmd;
   {
   WORD temp;

   if (cmdline[cmdptr])
      {
      if (!get_word(&temp))
         {
         cmdline_error(value_str);
         return;
         }
      throttle = temp;
      }
   else
      {
      sprintf(tempstr,"Throttle value: %04x\n",throttle);
      PUTS(tempstr);
      }
   }

WORD get_portvalue(portnum,initvals,token_start)  /* string is in fh2 */
   WORD *portnum;
   WORD *initvals[NUM_BYTE_PORTS][8];
   WORD token_start;
   {
   DWORD hold;
   WORD i, mask, port, pin;

   skip_cmd_spaces();
#ifndef PINS_8
   if ((strlen(fh2) == 2) && (toupper(fh2[0]) == 'R'))
      {
      fh2[0] = fh2[1];
      fh2[1] = '\0';
      }
   if ((strlen(fh2) == 1) && (cmdline[cmdptr] == '='))
      {
      fh2[0] = toupper(fh2[0]);
      if ((fh2[0] >= 'A') && (fh2[0] < 'A'+NUM_BYTE_PORTS))
         {
         port = fh2[0] - 'A';
         parse(fh2);
         if ((!fromhex(fh2,&hold)) || (hold & ~port_masks[port]))
            return(FALSE);
         for (mask = 1, i = 0; i < 8; i++, mask <<= 1)
            if (hold & mask)
               initvals[port][i] = 0xffff;
            else
               initvals[port][i] = 0;
         *portnum = port + 1;
         return(TRUE);
         }
      return(FALSE);
      }
#endif  /* PINS_8 */
#ifdef PINS_8
   if (cmdline[cmdptr] == '=')
#else
   if ((strlen(fh2) == 3) && (toupper(fh2[0]) == 'R'))
      {
      fh2[0] = fh2[1];
      fh2[1] = fh2[2];
      fh2[3] = '\0';
      }
   if ((strlen(fh2) == 2) && (cmdline[cmdptr] == '='))
#endif  /* PINS_8 */
      {
      cmdptr = token_start;
      if (!valid_pin(&port,&pin,TRUE))
         return(FALSE);
      parse(fh2);
      if ((strlen(fh2) == 1) && (fh2[0] == '1'))
         {
         initvals[port][pin] = 0xffff;
         return(TRUE);
         }
      if (!fromhex(fh2,&hold))
         return(FALSE);
      initvals[port][pin] = hold;
      return(TRUE);
      }
   if ((!fromhex(fh2,&hold)) || (*portnum >= NUM_BYTE_PORTS)
               || (hold & ~port_masks[*portnum]))
      return(FALSE);
   for (mask = 1, i = 0; i < 8; i++, mask <<= 1)
      if (hold & mask)
         initvals[*portnum][i] = 0xffff;
      else
         initvals[*portnum][i] = 0;
   *portnum = *portnum + 1;
   }

void cmd_ports(whichcmd)  /* initial input ports at reset */
   WORD whichcmd;
   {
   WORD temp, temp2, temp3, bitnum;
   WORD maxrow;
   WORD temp_init_ports[NUM_BYTE_PORTS][8];
   WORD portnum;

   if (cmdlist[whichcmd].cmdvalue == CMD_SETPORTS)
      MEMMOVE(analog_ports,temp_init_ports,sizeof(initial_ports));  /* init array */
   else
      {
      MEMMOVE(initial_ports,temp_init_ports,sizeof(initial_ports));  /* init array */
      on_or_off(&show_ports);
      }
   if (cmdline[cmdptr])  /* if set */
      {
      portnum = 0;
      while (TRUE)  /* use BREAK to get out */
         {
         temp = cmdptr;  /* save this value */
         if (!parse(fh2))  /* if nothing left to parse */
            break;
         skip_cmd_spaces();
         if (!get_portvalue(&portnum,temp_init_ports,temp))
            {
            cmdline_error(range_str);
            return;
            }
         }
          /* to get here, we've successfully gotten all the values */
      if (cmdlist[whichcmd].cmdvalue == CMD_SETPORTS)
         {
         for (temp = 0; temp < NUM_BYTE_PORTS; temp++)
            {
            input_ports[temp] = 0;
            for (temp2 = 7; temp2 != -1; temp2--)
               {
               input_ports[temp] <<= 1;
               input_ports[temp] |= (temp_init_ports[temp][temp2] > SCHMITT_TRUE_LEVEL) ? 1 : 0;
               analog_ports[temp][temp2] = temp_init_ports[temp][temp2];
                   /* set initial port values */
                   /* NOTE: the initial values of all the TRIS registers are all 1 bits
                    *       (all inputs).
                    */
               }
            }
         io_processing();  /* update I/O status as necessary */
         }
      else
         MEMMOVE(temp_init_ports,initial_ports,sizeof(initial_ports));  /* set array */
      }
   if (cmdlist[whichcmd].cmdvalue == CMD_SETPORTS)
      {
#ifdef CORE_12BIT
      last_t0cki = input_ports[0] << 2;  /* setup for next edge detect */
#else
      last_t0cki = input_ports[0];  /* setup for next edge detect */
      last_porta_in = input_ports[0];
      last_intpin = input_ports[0];
#endif  /* CORE_12BIT */
#ifdef HAS_PORTB
      last_portb_in = input_ports[1];
      last_portb = input_ports[1] & 0xf0;  /* reset port change interrupt info */
#endif  /* HAS_PORTB */
      return;  /* don't show/toggle mode for SETPORTS command */
      }
#ifdef CORE_12BIT     /* if 12-bit PIC, ports are shown in both VESA and VGA */
   if (!windowmode)
#else
   if (!vesamode)  /* if VESA mode, ports are already shown */
#endif  /* CORE_12BIT */
      {
      maxrow = SCREEN_ROWS - NUM_BYTE_PORTS - NUM_BYTE_PORTS - MAX_OSCOPE_LINES;
                       /* 2nd -NUM_BYTE_PORTS for the analog values beneath the port display */
      if (!windowmode)  /* if watchregs also in main window */
         maxrow -= (NUM_WATCHREGS/8);
      for (temp = maxrow; temp < maxrow + NUM_BYTE_PORTS; temp++)
         for (temp2 = 0; temp2 < SCREEN_COLS*2; temp2 += 2)
            {
            uart_screen[temp*SCREEN_COLS*2+temp2] = 0x20;  /* space */
            uart_screen[temp*SCREEN_COLS*2+temp2+1] = 7;   /* normal attribute */
            }
      }
   PUTS("input port values at reset:\n");
   for (temp = 0, temp2 = 0; temp < NUM_BYTE_PORTS; temp++)
      {
      if (NUM_BYTE_PORTS > 1)
         {
         tempstr[temp2++] = temp + 'A';
         tempstr[temp2++] = ':';
         }
      tempstr[temp2++] = ' ';
      for (temp3 = 8; temp3; temp3--)
         tempstr[temp2++] = (initial_ports[temp][temp3-1] > SCHMITT_TRUE_LEVEL) ? '1' : '0';
      for (bitnum = 0x80, temp3 = 7; bitnum; bitnum >>= 1, temp3--)
         {
         if (port_masks[temp] & bitnum)
            {
#ifdef PINS_8
            sprintf(&tempstr[temp2]," GP%d=%04x",temp3,initial_ports[temp][temp3]);
#else
            sprintf(&tempstr[temp2]," %c%d=%04x",temp+'A',temp3,initial_ports[temp][temp3]);
#endif  /* PINS_8 */
            temp2 = strlen(tempstr);
            }
         }
      if (temp != NUM_BYTE_PORTS-1)  /* if not last port */
         {
         strcpy(&tempstr[temp2],nl_str);
         PUTS(tempstr);
         temp2 = 0;
         }
      }
   tempstr[temp2++] = '\n';  /* be neat */
   tempstr[temp2] = '\0';  /* terminate string */
   PUTS(tempstr);
   sprintf(tempstr,"show port I/O status %s\n",
        show_ports ? on_str : off_str);
   PUTS(tempstr);
#ifdef CORE_12BIT     /* if 12-bit PIC, ports are shown in both VESA and VGA */
   if (!windowmode)
#else
   if (!vesamode)  /* if VESA mode, ports are already shown */
#endif  /* CORE_12BIT */
      {
      if (show_ports)
         {
         uart_screen_maxrow = maxrow;
         }
      else
         {
         if (num_watch_regs)
            {
            if (!windowmode)  /* if watchregs also in main window */
               uart_screen_maxrow = SCREEN_ROWS - MAX_OSCOPE_LINES - (NUM_WATCHREGS/8);
            else
               uart_screen_maxrow = SCREEN_ROWS - oscope_lines;
            }
         else
            {
            if (oscope_lines)
               uart_screen_maxrow = SCREEN_ROWS - oscope_lines;
            else
               uart_screen_maxrow = SCREEN_ROWS - 1;
            }
         }
      maxrow = SCREEN_ROWS - NUM_BYTE_PORTS - NUM_BYTE_PORTS - MAX_OSCOPE_LINES;
                       /* 2nd -NUM_BYTE_PORTS for the analog values beneath the port display */
      if (!windowmode)  /* if watchregs also in main window */
         maxrow -= (NUM_WATCHREGS/8);
      if (screen_rowofs >= (uart_screen_maxrowofs = SCREEN_COLS * uart_screen_maxrow * 2))
         screen_rowofs = uart_screen_maxrowofs - SCREEN_COLS * 2;
      }
   if (show_ports)
      {
      for (temp = 0; temp < NUM_BYTE_PORTS; temp++)
         lasttris[temp] ^= 0xff;  /* reset all bits, force display of all ports */
      }
   }

void cmd_keys(whichcmd)  /* key/port mappings */
                    /* Fxx={ !T<>}{A..E}{0..7}, bits within ports must be legal */
   WORD whichcmd;
   {
   WORD temp, temp2, temp3, temp4, flag;
   DWORD hold;

   if (!cmdline[cmdptr])  /* if nothing, give key mappings */
      {
      for (flag = FALSE, temp = 0; temp < NUM_KEYPINS; temp++)
         if ((temp2 = key_pins[temp].keytype) != KEYMODE_UNUSED)
            {
            flag = TRUE;  /* flag: we do have some definitions */
#ifdef PINS_8
            sprintf(tempstr,"F%d = %cGP%d\n",
                temp+1,
                keytype_str[temp2],
/*                key_pins[temp].portnum, */
                key_pins[temp].portbit);
#else
            sprintf(tempstr,"F%d = %c%c%d\n",
                temp+1,
                keytype_str[temp2],
                key_pins[temp].portnum,
                key_pins[temp].portbit);
#endif  /* PINS_8 */
            PUTS(tempstr);
            }
      if (!flag)  /* if no key mappings */
         PUTS("No key mappings\n");
      return;
      }
   while (cmdline[cmdptr])
      {
      if ((toupper(cmdline[cmdptr++]) != 'F')
           || (!parse(fh2))
           || (!fromhex(fh2,&hold))
           || (!hold)
           || ((hold > 9) && (hold != 0x10)))
         {
         cmdline_error(syntax_str);
         return;
         }
      temp = (hold > 9) ? 9 : hold - 1;
      if (temp > NUM_KEYPINS)
         {
         cmdline_error(syntax_str);
         return;
         }
      skip_cmd_spaces();
      if (!cmdline[cmdptr])  /* if removing key definition */
         {
         key_pins[temp].keytype = KEYMODE_UNUSED;
         return;
         }
      if (cmdline[cmdptr++] != '=')
         {
         cmdline_error(syntax_str);
         return;
         }
      skip_cmd_spaces();
      temp2 = KEYMODE_FOLLOW;
      if (cmdline[cmdptr] == '!')
         {
         temp2 = KEYMODE_INVERT;
         cmdptr++;
         }
      else
         if (toupper(cmdline[cmdptr]) == 'T')
            {
            temp2 = KEYMODE_TOGGLE;
            cmdptr++;
            }
         else
            if (cmdline[cmdptr] == '>')
               {
               temp2 = KEYMODE_INCREASE;
               cmdptr++;
               }
            else
               if (cmdline[cmdptr] == '<')
                  {
                  temp2 = KEYMODE_DECREASE;
                  cmdptr++;
                  }
      if (!valid_pin(&temp3,&temp4,FALSE))
         return;
      key_pins[temp].keytype = temp2;
      key_pins[temp].keyaction = portbitfns[temp3*8 + temp4];
      key_pins[temp].portnum = 'A' + temp3;
      key_pins[temp].portbit = temp4;
      skip_cmd_spaces();  /* prep for next pass */
      }  /* while (cmdline[cmdptr]) */
   }

void cmd_macro(whichcmd)  /* define macro keys */
                          /* Fxx command string */
   WORD whichcmd;
   {
   WORD temp, flag;
   DWORD hold;

   if (!cmdline[cmdptr])  /* if nothing, show macros */
      {
      for (flag = FALSE, temp = 0; temp < NUM_MACRO_KEYS; temp++)
         if (macros[temp][0])
            {
            flag = TRUE;  /* flag: we do have some definitions */
            sprintf(tempstr,"F%d: %s\n",
                temp+1+FIRST_MACRO_KEY-F1,macros[temp]);
            if (tempstr[strlen(tempstr)-2] == '\n')
               strcpy(&tempstr[strlen(tempstr)-2],"\\n\n");
            PUTS(tempstr);
            }
      if (!flag)  /* if no macros */
         PUTS("No macros\n");
      return;
      }
   if ((toupper(cmdline[cmdptr++]) != 'F')
        || (!parse(fh2))
        || (!fromhex(fh2,&hold))
        || (!hold)
        || ((hold > 9) && (hold != 0x10)))
      {
      cmdline_error(syntax_str);
      return;
      }
   temp = (hold > 9) ? 9 : hold - 1;
   if ((temp < FIRST_MACRO_KEY-F1) || (temp > LAST_MACRO_KEY-F1))
      {
      cmdline_error(syntax_str);
      return;
      }
   skip_cmd_spaces();
   temp -= FIRST_MACRO_KEY - F1;
   strcpy(macros[temp],&cmdline[cmdptr]);
   if (((flag = strlen(&cmdline[cmdptr])) > 1)
            && (strcmpi(&cmdline[cmdptr+flag-2],"\\n") == 0))
      strcpy(&macros[temp][flag-2],nl_str);
   }

void cmd_browse(whichcmd)  /* browse file */
   WORD whichcmd;
   {
   if (parse(tempstr))
      {
      strcpy(browse_name,tempstr);
      browse_pos = 0;  /* reset file position */
      }
   if ((!browse_name[0]) || ((filein = open(browse_name,0)) == -1))
      {
      cmdline_error(name_str);
      return;
      }
   browse_file();
   }

find_helpfile()
   {
   WORD i;
#asm
   push ds
   push ds
   pop  es
   mov  ah,62h
   int  21h
   mov  ds,bx
   mov  ds,word [2ch]
   xor  si,si
   cld
find_helpfile_loop:
   cmp  word [si],0
   jz   end_of_env
   inc  si
   cmp  si,8000h          ;32k?
   jz   end_find_helpfile ;yes, quit!
   jmp  find_helpfile_loop
end_of_env:
   add  si,4
   mov  di,offset helpfile_
   xor  cx,cx
copy_path_loop:
   lodsb
   stosb
   or   al,al
   jz   end_find_helpfile
   inc  cx
   cmp  cx,110
   jne  copy_path_loop
   xor  ax,ax
   stosb
end_find_helpfile:
   pop  ds
#endasm
   for (i = strlen(helpfile); i; i--)
      if ((helpfile[i] == '\\') || (helpfile[i] == ':'))
         {
         helpfile[i+1] = '\0';
         break;
         }
   strcat(helpfile,helpname);
   }
