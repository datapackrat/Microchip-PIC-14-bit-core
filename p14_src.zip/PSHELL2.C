#ifdef NEVERDEF
/****************************************************************************
 ****************************************************************************
 *                                                                          *
 *   WARNING!                                                               *
 *                                                                          *
 *   I've discovered a bug in the code optimizer.  A definition like:       *
 *      #define TESTBITS (BIT1|BIT2)                                        *
 *   can produce incorrect code output from the optimizer when TESTBITS     *
 *   is used.                                                               *
 *                                                                          *
 *   Instead, use a definition like:                                        *
 *      #define TESTBITS 0x05  /* (BIT1|BIT2) */                            *
 *   Yes, that's not as "ideal", but it will save a WORLD of problems!      *
 *                                                                          *
 ****************************************************************************
 ****************************************************************************/
#endif

/*
 *  PIC emulator user command shell, part 2.  Should be PIC processor independent.
 *  Split command shell to reduce load (98% utilization) on compiler.
 *
 *
 *  Copyright (c) 2001-2004
 *
 *  Released under the GNU GPL.  See http://www.gnu.org/licenses/gpl.txt
 *
 *  This program is part of PICEMU
 *
 *  PICEMU is free software; you can redistribute it and/or modify it under
 *  the terms of the GNU General Public License as published by the Free
 *  Software Foundatation; either version 2 of the License, or any later
 *  version.
 *
 *  PICEMU is distributed in the hope that it will be useful, but WITHOUT
 *  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 *  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 *  for more details.
 *
 *
 *  Revision history
 *
 *  Date      Comments
 *  --------  ---------------------------------------------
 *  9/xx/01   Original code
 *  11/14/01  Code cleanup for 1st BETA release
 *  4/18/02   Split (PSHELL, PSHELL2) for compiler limits
 *  01/04/03  Improved "Command window" editing capabilities
 *  11/6/03   More commands and better processing for V1.20
 *  3/15/04   Source code unification for 14-bit core programs.
 */
#include <picemu.h>

extern WORD memory[MEMORY_SIZE];

#ifdef EEPROM_SIZE
   extern BYTE eeprom[EEPROM_SIZE];
#endif  /* EEPROM_SIZE */

extern WORD initial_ports[NUM_BYTE_PORTS][8];
extern BYTE input_ports[NUM_BYTE_PORTS_ALLOCATE];
extern BYTE port_masks[NUM_BYTE_PORTS_ALLOCATE];

#ifdef CORE_14BIT
   extern BYTE show_regs[NUM_REGS];  /* which regs to show in a 'R' command */
#endif  /* CORE_14BIT */

extern BYTE cmdline[STRING_SIZE];
extern WORD cmdptr;

extern WORD breakpoint;  /* !0, have breakpoint, else FALSE */
extern WORD chkstack;
extern WORD chkwatchdog;
extern WORD watchdog_enabled;  /* configuration & CONF_WDTE */
extern WORD swap_screens;
extern WORD readusestris;

extern BYTE regs[NUM_REGS];
extern WORD ip;          /* instruction pointer */
extern BYTE w;           /* Working register */
extern BYTE tempstr[STRING_SIZE];
extern BYTE instr_str[64];  /* disassembled instruction */
extern WORD stack[STACK_SIZE];
extern WORD stack_ptr;
extern WORD stack_depth;
extern WORD max_stack_depth;
extern WORD show_ports;
extern WORD configuration;

extern BYTE disk_full_str[48];
extern BYTE name_str[8];
extern BYTE cannot_write_str[24];
extern BYTE value_str[8];
extern BYTE nl_str[4];
extern BYTE space_str[4];
extern BYTE off_str[4];
extern BYTE number_str[8];
extern BYTE address_str[12];
extern BYTE range_str[16];
extern BYTE syntax_str[8];
extern BYTE no_soft_uart[16];
extern BYTE frequency_too_slow[36];
extern BYTE press_any[32];
extern BYTE press_any_esc[48];
static BYTE cannot_read_str[24] = "Cannot read from file\n";
static BYTE not_a_codfile[20] = "not a .COD file?\n";
static BYTE codfile_badread[28] = "read error on .COD file.\n";
static BYTE invalid_memory_map[24] = "invalid memory map.\n";

extern BYTE fromhexstr[STRING_SIZE];
extern BYTE fh2[STRING_SIZE];

extern BYTE browse_screen[BROWSE_SCREEN_SIZE+16];  /* allow myself some "slop" room */
extern DWORD browse_pos;
static BYTE browse_header[] = "Find, Again, Esc to quit, cursor keys active: PgUp, PgDn, Home, End, Up, Down\n-----\n";
extern int filein;    /* NOTE: For DeSmet C (aka PCC) a FILE is just an int */


extern DWORD startticks, endticks;
extern DWORD totalticks;
       DWORD daycount;
#define TICKS_PER_DAY 0x1800b0L

extern int outputfile;  /* output going to file */
extern int inputfile;  /* input coming from file */
extern DWORD inputfilesize;  /* size of input file */
DWORD lseek();

extern DWORD total_ic[2];  /* count of instructions executed */  /* fake a 64-bit int */
extern WORD whereptr;  /* pointer into "where was I?" queue */
extern WORD wherequeue[WHERE_SIZE+1];  /* queue of addresses for where? */

extern WORD symboladdr;  /* segment of symbol table */
extern WORD numsymbols;  /* number of entries in symbol table */

extern WORD i2c_seg;     /* segment of I2C storage */

#ifdef USE_ADDRLIST
   extern WORD xlate_regs[NUM_REGS];
   extern WORD addrlist_seg;
   extern WORD addrlist;
   extern WORD have_addrlist;
#endif  /* USE_ADDRLIST */

#ifdef HAS_UART
   extern WORD commport;
#endif  /* HAS_UART */

/* TX:  transmission from PIC --> USER */
/*  Note: su_txdata will start at 0, be right shifted before a new bit is
 *        put in the top of the word.  Thus, the received data will look like
 *        <stop bits><parity (if any)><data bits><start bit><0's>
 */
extern WORD su_txenable;    /* if 0, we are doing PIC --> USER bitbanging */
extern WORD su_txbaud;      /* baudrate, 110 to 57600 (max of frequency/16) */
extern WORD su_txport;      /* PORT used for TX pin */
extern WORD su_txpin;       /* bit in PORT for TX pin */
extern WORD su_txbittiming; /* instructions per bit */
extern WORD su_txcount;     /* count of bits PIC --> USER */
extern WORD su_txtiming;    /* if != 0, inst. count until next bit receive */
extern WORD su_txdatabits;  /* number of data bits we're expecting, 7 or 8 */
extern WORD su_txparity;    /* 'E'ven, 'N'one, or 'O'dd */
extern WORD su_txstopbits;  /* number of stop bits we're expecting, 1 or 2 */
extern WORD su_txtotalbits; /* total bits: 1 (start bit) + databits + stop bits + parity (if any) */
extern WORD su_txstopmask;  /* 0x8000 or 0xc000 for 1 or 2 stop bits (top of receive word) */
extern WORD su_txframemask; /* su_txstopmask | (1 << (16-txtotalbits)), check start bit for 0 as well as stop bits */
extern WORD su_txdatamask;  /* mask for 7/8 bit data: 0x7f or 0xff */
extern WORD su_txdatashift; /* bits to shift data to put it at the bottom of the low byte */
extern WORD su_txdata;      /* data we've received */
extern WORD su_txlastbit;   /* previous state of our TX pin, for start of data detection */
extern WORD su_txbitmask;   /* bittable[su_txpin] */
extern WORD su_txinvert;    /* 0x00 (normal) or 0xff (inverted) logic levels */

/* RX:  transmission from USER --> PIC */
/*  Note: su_rxdata will start at contain the formatted bit string.  Bits
 *        will be read from the bottom of the word, which will then be
 *        shifted right.  Thus, the data to send will look like:
 *        <0's><stop bits><parity (if any)><data bits><start bit>
 */
extern WORD su_rxenable;    /* if 0, we are doing USER --> PIC bitbanging */
extern WORD su_rxbaud;      /* baudrate, 110 to 57600 (max of frequency/16) */
extern WORD su_rxport;      /* PORT used for TX pin */
extern WORD su_rxpin;       /* bit in PORT for TX pin */
extern WORD su_rxbittiming; /* instructions per bit */
extern WORD su_rxcount;     /* count of bits USER --> PIC */
extern WORD su_rxtiming;    /* if != 0, inst. count until next bit receive */
extern WORD su_rxdatabits;  /* number of data bits we're expecting, 7 or 8 */
extern WORD su_rxparity;    /* 'E'ven, 'N'one, or 'O'dd */
extern WORD su_rxstopbits;  /* number of stop bits we're expecting, 1 or 2 */
extern WORD su_rxtotalbits; /* total bits: 1 (start bit) + databits + stop bits + parity (if any) */
extern WORD su_rxstopmask;  /* 0x01 or 0x03 (1 or 2 stop bits) << (start+databits+paritybits) */
extern WORD su_rxdatamask;  /* mask for 7/8 bit data: 0x7f or 0xff */
extern WORD su_rxdata;      /* data we've received */
extern WORD su_rxbitmask;   /* bittable[su_rxpin] */
extern WORD su_rxinvert;    /* 0x00 (normal) or 0xffff (inverted) logic levels */

extern DWORD frequency;    /* CPU frequency */
extern WORD watchdog_reset_count;  /* reset value for watchdog to give 18ms nominal timer */

extern struct keypins key_pins[MAX_KEYPINS];

extern struct windata window_data[NUM_WINDOWS];
extern struct windata vga_data[NUM_WINDOWS];
extern WORD vgamode;   /* flag: VGA mode (80x50) is available */
extern WORD vesamode;  /* flag: VESA mode (0x010B -> 132 x 50) is available */
extern WORD windowmode;  /* FLAG: either VGA or VESA mode */

#ifdef PICTYPE_16F648
   BYTE p648_fosc_trisabits[8] =
      {
      0x00,   /* 000 = LP oscillator: xtal on A6, A7     00.. .... */
      0x00,   /* 001 = XT oscillator: xtal on A6, A7     00.. .... */
      0x00,   /* 010 = HS oscillator: xtal on A6, A7     00.. .... */
      0x40,   /* 011 = EC: I/O on A6, CLKIN on A7        01.. .... */
      0xc0,   /* 100 = INTRC: I/O on A6, A7              11.. .... */
      0x80,   /* 101 = INTRC: CLKOUT on A6, I/O on A7    10.. .... */
      0x40,   /* 110 = ER: I/O on A6, resistor on A7     01.. .... */
      0x00    /* 111 = ER: CLKOUT on A6, resistor on A7  00.. .... */
      };
#endif  /* PICTYPE_16F648 */

#ifdef PICTYPE_12F675
   BYTE p675_fosc_trisabits[8] =
      {
      0x00,   /* 000 = LP oscillator: xtal on A4, A5     ..00 .... */
      0x00,   /* 001 = XT oscillator: xtal on A4, A5     ..00 .... */
      0x00,   /* 010 = HS oscillator: xtal on A4, A5     ..00 .... */
      0x10,   /* 011 = EC: I/O on A4, CLKIN on A5        ..01 .... */
      0x30,   /* 100 = INTOSC: I/O on A4, A5             ..11 .... */
      0x20,   /* 101 = INTOSC: CLKOUT on A4, I/O on A5   ..10 .... */
      0x10,   /* 110 = RC: I/O on A4, RC on A5           ..01 .... */
      0x00    /* 111 = RC: CLKOUT on A4, resistor on A5  ..00 .... */
      };
#endif  /* PICTYPE_12F675 */

#ifdef PICTYPE_12C509A
   WORD p509a_fosc_trisabits[4] =  /* bit mask, pins used by oscillator modes */
                            /* indexed by configuration & 0x03 */
      {
      0x0f,   /* 00 = LP:  GP4, GP5 used by external oscillator */
      0x0f,   /* 01 = XT:  GP4, GP5 used by external oscillator */
      0x3f,   /* 10 = INTRC: all GPIO available */
      0x1f    /* 11 = EXTRC: GP5 used by external RC oscillator */
      };
#endif  /* PICTYPE_12C509A */

#ifdef CORE_12BIT
   extern WORD wakemask;        /* if MCLR enabled WAKEPINS_NO_GP3 else WAKEPINS */
#endif  /* CORE_12BIT */
extern BYTE lasttris[NUM_BYTE_PORTS_ALLOCATE];  /* need this globally for reset_windows() */

extern BYTE macros[NUM_MACRO_KEYS][STRING_SIZE];

extern WORD bittable[8];

extern WORD num_reg_breakpoints;
extern WORD filenum_temp;  /* bank select bits + filenum */
extern BYTE uart_screen[SCREEN_ROWS * SCREEN_COLS * 2];
extern WORD uart_screen_maxrow;  /* max row to use for UART/SoftUART screen */
extern WORD uart_screen_maxrowofs;  /* max ofs to use for UART/SoftUART screen */
extern WORD screen_rowofs;
extern WORD screen_colofs;
extern BYTE regval;
extern WORD oscope_maxwidth;

extern struct picfilehdr picfile_hdr;

extern BYTE processor[8];
extern BYTE picemu_str[8];  /* who ownes BIN/PIM files */

BYTE *window_labels[NUM_WINDOWS] =
   {
   " Command window - - Home End Ins Del Esc F3 <Ctrl-Tab> ",
   "",
   " Registers ",
   " EEPROM ",
   " Watch regs ",
   " Ports ",
   " Where ",
   " Disassembly "
   };
BYTE *insert_labels[2] =
   {
   " [OVR] ",
   " [INS] "
   };
BYTE scroll_prompt[] = "  PgUp PgDn Home End <Ctrl-Tab> ";
WORD bytesperline;   /* bytes per line (80*2 or 132*2) */
WORD cmdwindow_row;  /* keep track of row & col in command window */
WORD cmdwindow_col;
BYTE current_ins_status = 1; /* ==0 => overtype, ==1 => insert (NOTE that insert is ==1, not !=0) */

#define NUMOPS 11
BYTE operatorstr[NUMOPS+1] = "^|&<>-+%/*~";

WORD fromhex_pos, num_paren, num_square;
DWORD fromhex_temp;

static struct processi2c i2c_params[12] =   /* OFF, 0, 1, 2, 4, 8, 16, 32, 64, 128, 256, <unused> */
{
   { 0, 0x00, 0x0000 },  /* OFF */
   { 2, 0x0f, 0x000f },  /* 24xx00:     128 bit     16 byte */  /* yup, page_mask is correct! */
   { 2, 0x0f, 0x007f },  /* 24xx01:    1024 bit    128 byte */
   { 2, 0x0f, 0x00ff },  /* 24xx02:    2048 bit    256 byte */
   { 2, 0x0f, 0x01ff },  /* 24xx04:    4096 bit    512 byte */
   { 2, 0x0f, 0x03ff },  /* 24xx08:    8192 bit   1024 byte */
   { 2, 0x0f, 0x07ff },  /* 24xx16:   16384 bit   2048 byte */
   { 3, 0x1f, 0x0fff },  /* 24xx32:   32768 bit   4096 byte */
   { 3, 0x1f, 0x1fff },  /* 24xx64:   65536 bit   8192 byte */
   { 3, 0x3f, 0x3fff },  /* 24xx128: 131072 bit  16384 byte */
   { 3, 0x3f, 0x7fff }   /* 24xx256: 262144 bit  32768 byte */
};
extern BYTE i2c_mode;
extern WORD i2c_hdr_size;
extern WORD i2c_addr_mask;
extern WORD i2c_address;
extern WORD i2c_page_mask;
extern WORD i2c_page_max;   /* i2c_page_max = i2c_hdr_size; if (i2c_type != 1) i2c_page_max += i2c_page_mask + 1; */
extern WORD i2c_seg;
extern WORD i2c_type;
extern WORD last_sda;
extern WORD last_sda_tris;
extern WORD last_scl;
extern WORD scl_pin;
extern WORD scl_pinmask;
extern WORD scl_port;
extern WORD sda_pin;
extern WORD sda_pinmask;
extern WORD sda_port;

WORD peekw(seg,ofs)  /* peek a WORD address */
   WORD seg,ofs;
   {
#asm
   push   es
   mov    es,word [bp+4]
   mov    bx,word [bp+6]
   mov    ax,word es:[bx]
   pop    es
#endasm
   }

WORD peekb(seg,ofs)  /* peek a BYTE address */
   WORD seg,ofs;
   {
#asm
   push   es
   mov    es,word [bp+4]
   mov    bx,word [bp+6]
   xor    ax,ax
   mov    al,byte es:[bx]
   pop    es
#endasm
   }

void pokeb(seg,ofs,val)  /* poke a BYTE address */
   WORD seg,ofs,val;
   {
#asm
   push   es
   mov    es,word [bp+4]
   mov    bx,word [bp+6]
   mov    ax,word [bp+8]
   mov    byte es:[bx],al
   pop    es
#endasm
   }

void pokew(seg,ofs,val)  /* poke a WORD address */
   WORD seg,ofs,val;
   {
#asm
   push   es
   mov    es,word [bp+4]
   mov    bx,word [bp+6]
   mov    ax,word [bp+8]
   mov    word es:[bx],ax
   pop    es
#endasm
   }

BYTE *hexbyte(val,str)
   WORD val;
   BYTE *str;
   {
   str[0] = ascii_hex((val >> 4) & 0x0f);
   str[1] = ascii_hex(val & 0x0f);
   str[2] = '\0';
   return(str);
   }

BYTE *hexword(val,str)
   WORD val;
   BYTE *str;
   {
   str[0] = ascii_hex((val >> 12) & 0x0f);
   str[1] = ascii_hex((val >> 8) & 0x0f);
   str[2] = ascii_hex((val >> 4) & 0x0f);
   str[3] = ascii_hex(val & 0x0f);
   str[4] = '\0';
   return(str);
   }

BYTE *hexdword(val,str)
   DWORD val;
   BYTE *str;
   {
   str[0] = ascii_hex((val >> 28) & 0x0f);
   str[1] = ascii_hex((val >> 24) & 0x0f);
   str[2] = ascii_hex((val >> 20) & 0x0f);
   str[3] = ascii_hex((val >> 16) & 0x0f);
   str[4] = ascii_hex((val >> 12) & 0x0f);
   str[5] = ascii_hex((val >> 8) & 0x0f);
   str[6] = ascii_hex((val >> 4) & 0x0f);
   str[7] = ascii_hex(val & 0x0f);
   str[8] = '\0';
   return(str);
   }

BYTE *hexqword(val,str)
   DWORD *val;
   BYTE *str;
   {
   if (!val[1])
      return(hexdword(val[0],str));
   hexdword(val[1],str);
   hexdword(val[0],&str[8]);
   return(str);
   }

WORD strcmpi(str1,str2)  /* write what should be a library function */
   BYTE *str1, *str2;
   {
   while ((*str1) && (*str2))
      {
      if (toupper(*str1) != toupper(*str2))
         return(1);
      str1++;
      str2++;
      }
   if (*str1 == *str2)  /* make sure both are at EOS */
      return(0);
   return(1);
   }

WORD strncmpi(s1,s2,n)  /* write what should be a library function */
   BYTE *s1, *s2;
   WORD n;
   {
   while ((n--) && (*s1) && (*s2))
      {
      if (toupper(*s1) != toupper(*s2))
         return(1);  /* not the same */
      s1++;
      s2++;
      }
   if (n == -1)  /* if end of number of bytes */
      return(0);  /* a match! */
   if ((*s1) || (*s2))  /* if not both at EOS */
      return(1);  /* no match */
   return(0);  /* a match */
   }

WORD isregname(name)  /* change name to upper case, return index value if
                         a valid register name, else return -1 */
   BYTE *name;
   {
   if (strcmpi(name,"W") == 0)
      return(1);  /* this is W */
   if (strcmpi(name,"IP") == 0)
      return(2);  /* this is IP */
   return(0);  /* not a register name */
   }

WORD find_symbol(str,val)  /* 0 if found, 1 if not found, 2 if dup */
   BYTE *str;  /* [BP+4] */
   WORD *val;  /* [BP+6] */
   {
   WORD result;  /* return value */  /* [BP-2] */
   WORD pending;  /* symbol # of partial match, see if it's unique */ /* [BP-4] */
   WORD value;   /* value of symbol */ /* [BP-6] */

   if ((!symboladdr) || (!numsymbols))
      return(1);  /* not found */
   result = 1;  /* default: not found */
   pending = MAX_SYMBOLS + 1;  /* not found */
#asm
   jmp find_sym_skipit      ;skip a quickie subroutine
find_sym_ax_lower:
   cmp  al,'A'              ;upper case?
   jnae f_s_lower_1         ;no, skip this
   cmp  al,'Z'              ;still upper?
   ja   f_s_lower_1         ;no, skip this
   or   al,20h              ;force lower
f_s_lower_1:
   cmp  ah,'A'              ;upper case?
   jnae f_s_lower_2         ;no, skip this
   cmp  ah,'Z'              ;still upper?
   ja   f_s_lower_2         ;no, skip this
   or   ah,20h              ;force lower
f_s_lower_2:
   ret
find_sym_skipit:
   push es                  ;save our es
   mov  es,word symboladdr_ ;get symbol table seg
   xor  di,di               ;es:di = ptr to symbols
   cld                      ;up!
   mov  si,word [bp+4]      ;get ptr to string
   mov  ax,word [si]        ;get start of string
   call find_sym_ax_lower   ;force lower case
   mov  bx,ax               ;save these bytes
   mov  cx,word numsymbols_ ;get search count
find_symbol_loop:
   mov  ax,word es:[di]     ;get start of symbol
   call find_sym_ax_lower   ;force lower case
   cmp  ax,bx               ;a match?
   jne  find_symbol_next    ;no, keep looking
   push di                  ;save ptr into symbol table
   push si                  ;save ptr to string
find_symbol_chkstring:
   mov  al,byte [si]        ;get string byte
   mov  ah,byte es:[di]     ;get symbol byte
   or   al,al               ;EOS in string?
   jz   find_sym_match      ;yes, see what to do with it
   or   ah,ah               ;EOS in symbol?
   jz   find_sym_nomatch    ;yes, not the symbol we're looking for
   call find_sym_ax_lower   ;force lower case
   cmp  al,ah               ;a match?
   jne  find_sym_nomatch    ;no, keep looking
   inc  si                  ;update string ptr
   inc  di                  ;update symbol ptr
   jmp  find_symbol_chkstring ;and keep looking
find_sym_match:
   pop  si                  ;cleanup stack
   pop  di                  ;get symbol ptr back
   or   ah,ah               ;EOS in both string & symbol?
   mov  ax,word es:[di+14]  ;get label value
   mov  word [bp-6],ax      ;set symbol value
   mov  word [bp-2],0       ;set RESULT = MATCH
   jne  find_sym_match2     ;no, deal with pending match stuff
   jmp  find_symbol_exit    ;and we're done
find_sym_match2:
   mov  ax,word numsymbols_ ;get number of symbols
   cmp  ax,word [bp-4]      ;is another symbol pending?
   jnae find_sym_match3     ;no, continue
   mov  word [bp-2],2       ;set result = DUP
   jmp  find_symbol_exit    ;and we're done
find_sym_match3:
   sub  ax,cx               ;get this symbol number
   mov  word [bp-4],ax      ;save pending
   jmp  find_symbol_next    ;keep looking
find_sym_nomatch:
   pop  si                  ;get ptr to string back
   pop  di                  ;get ptr to symbol back
find_symbol_next:
   add  di,16               ;SYMTAB_ENTRY_SIZE
   loop find_symbol_loop    ;try next symbol
find_symbol_exit:
   pop  es                  ;restore es
#endasm
   if (result == 0)  /* if found! */
      *val = value;
   return(result);
   }

WORD numval(str,val)  /* change hex value in str to a number */
                      /* return FALSE if invalid hex number, else TRUE */
   BYTE *str;
   DWORD *val;  /* Beware of passing an INT pointer to this routine
                   if the machine does not use low-byte first! */
   {
   WORD i,valid;
   BYTE ch;

   switch(isregname(str))  /* if this is a register name */
      {
      case 1:   /* W */
         *val = w;
         return(TRUE);
         break;
      case 2:  /* IP */
         *val = ip;
         return(TRUE);
         break;
      default:
         *val = 0;  /* clear high word! */
         if ((valid = find_symbol(str,val)) == 0)
            return(TRUE);
         if (valid == 2)
            {
            cmdline_error("symbol not unique");
            return(FALSE);
            }
         break;
      }
   i = 0;
   *val = 0;
   valid = FALSE;
   while (ch = toupper(str[i++]))
      {
      valid = TRUE;
      if (isdigit(ch))
         *val = (*val << 4) + ch - '0';  /* a number */
      else
         if ((ch >= 'A') && (ch <= 'F'))  /* a letter */
            *val = (*val << 4) + ch - 'A' + 10;
         else
            return(FALSE);
      }
   return(valid);
   }

int instring(ch,str)  /* want this to be SIGNED! */
   BYTE ch;
   BYTE *str;
   {
   int i,j;  /* want these to be SIGNED! */

   j = -1;
   i = strlen(str);
   while ((i > -1) && (j < 0))
      if (str[i--] == ch)
         j = i+1;
   return(j);
   }

WORD evalhex(str,val)  /* parse and evaluate an expression */
   BYTE *str;
   DWORD *val;
   {
   WORD loc,valid,whichop,count,flag;
   DWORD lnum,lnum2,temp2;

   valid = TRUE;
   whichop = 0;
   do
      {
      if ((loc = instring(operatorstr[whichop],str)) > -1)
         {
         str[loc] = '\0';
         if ((str[loc+1]) && (evalhex(&str[loc+1],&lnum2)))
            {
            if ((operatorstr[whichop] == '~')
                                || ((loc > 0) && (evalhex(str,&lnum))))
               {
               switch(operatorstr[whichop])
                  {
                  case '^':  /* XOR */
                     *val = lnum ^ lnum2;
                     break;
                  case '|':  /* OR */
                     *val = lnum | lnum2;
                     break;
                  case '&':  /* AND */
                     *val = lnum & lnum2;
                     break;
                  case '<':  /* shift left */
                     temp2 = lnum2 & 0x0fL;
                     *val = lnum;
                     if (temp2)
                        {
                        *val <<= temp2;
                        *val |= (lnum >> (16-temp2));
                        }
                     break;
                  case '>':  /* shift right */
                     temp2 = lnum2 & 0x0fL;
                     *val = lnum;
                     if (temp2)
                        {
                        *val >>= temp2;
                        *val |= (lnum << (16-temp2));
                        }
                     break;
                  case '-':  /* subtract */
                     *val = lnum - lnum2;
                     break;
                  case '+':  /* addition */
                     *val = lnum + lnum2;
                     break;
                  case '%':
                     if (lnum2)
                        {
                        *val = lnum % lnum2;
                        }
                     else
                        valid = FALSE;
                     break;
                  case '/':  /* division */
                     if (lnum2)
                        {
                        *val = lnum / lnum2;
                        }
                     else
                        valid = FALSE;
                     break;
                  case '*':  /* multiplication */
                     *val = lnum * lnum2;
                     break;
                  case '~':  /* NOT */
                     if (loc == 0)
                        *val = ~lnum2;
                     else
                        {
                        flag = 1;
                        for (count = 0; count < NUMOPS; count++)
                           {
                           if (str[loc-1] == operatorstr[count])
                              flag = 0;
                           }
                        if (flag)
                           valid = FALSE;
                        else
                           *val = ~lnum2;
                        }
                     break;
                  }  /* end of switch */
               if (valid)
                  return(valid);
               }  /* end of if */
            else
               valid = FALSE;
            }
         else
            valid = FALSE;
         }
      else
         whichop++;
      } while ((whichop < NUMOPS) && (valid));
   if (valid)
      valid = numval(str,val);
   return(valid);
   }

WORD hexwordvalue(str)  /* for load_hexfile() */
   BYTE *str;
   {
   WORD val;
   BYTE hold;

   hold = str[4];
   str[4] = '\0';
   sscanf(str,"%x",&val);
   str[4] = hold;
   return(val);
   }

/*
 *  Note:  I "borrowed" this routine from some work I did back in 1987.
 *         It's *DAMNED* ugly.  Not to mention poorly written.
 *         But it does work, and I'm too lazy to re-write it right now.
 */
WORD balance(str,type)  /* WARNING:  RECURSIVE SUBROUTINE! */
   BYTE *str;
   WORD type;
   {
   WORD valid, startpos;

   valid = TRUE;
   while ((str[fromhex_pos]) && (valid))
      {
      if (str[fromhex_pos] == '(')
         {
         num_paren++;
         startpos = fromhex_pos++;
         if (valid = balance(str,1))
            {
            strcpy(tempstr,&str[startpos+1]);
            tempstr[fromhex_pos-startpos-2] = '\0';
            if (valid = evalhex(tempstr,&fromhex_temp))
               {
               strcpy(tempstr,&str[fromhex_pos]);
               hexword((WORD)fromhex_temp,&str[startpos]);
               strcat(str,tempstr);
               fromhex_pos = startpos + 4;  /* 4 for length of hexword() string */
               }
            }
         }
      else
         {
         if (str[fromhex_pos] == '[')
            {
            num_square++;
            startpos = fromhex_pos++;
            if (valid = balance(str,2))
               {
               strcpy(tempstr,&str[startpos+1]);
               tempstr[fromhex_pos-startpos-2] = '\0';
               if (valid = evalhex(tempstr,&fromhex_temp))
                  {
                  strcpy(tempstr,&str[fromhex_pos]);
                  fromhex_temp = regs[fromhex_temp % NUM_REGS];
                  hexword((WORD)fromhex_temp,&str[startpos]);
                  strcat(str,tempstr);
                  fromhex_pos = startpos + 4;  /* 4 for length of hexword() string */
                  }
               }
            }
         else
            {
            if (str[fromhex_pos] == ')')
               {
               if ((num_paren == 0) || (type != 1))
                  return(FALSE);
               else
                  {
                  num_paren--;
                  fromhex_pos++;
                  return(TRUE);
                  }
               }
            else
               {
               if (str[fromhex_pos] == ']')
                  {
                  if ((num_square == 0) || (type != 2))
                     return(FALSE);
                  else
                     {
                     num_square--;
                     fromhex_pos++;
                     return(TRUE);
                     }
                  }
               else
                  fromhex_pos++;
               }  /* end of else of if ')' */
            }  /* end of else of if '[' */
         }  /* end of else of if '(' */
      }  /* end of while */
   if ((num_paren) || (num_square))
      valid = FALSE;
   return(valid);
   }

WORD iswhite(ch)
   BYTE ch;
   {
   if ((ch == ' ') || (ch == '\t'))
      return(TRUE);
   return(FALSE);
   }

WORD fromhex(str,val)
   BYTE *str;
   DWORD *val;
   {
   fromhex_pos = 0;
   num_paren = 0;
   num_square = 0;
   if (balance(str,0))
      {
      strcpy(tempstr,str);
      if (evalhex(tempstr,val))
         return(TRUE);
      }
   return(FALSE);
   }

setup()
   {
   WORD i;
   DWORD tempcount;

#ifdef CORE_14BIT
   for (i = 0x00; i < 0x20; i++)
      show_regs[i] = TRUE;
#endif  /* CORE_14BIT */
   for (i = 0; i < MEMORY_SIZE; i++)
      memory[i] = INSTRUCTION_BITMASK;
#ifdef OSCCAL_INSTR
   memory[OSCCAL_INSTR_LOC] = OSCCAL_INSTR;
#endif  /* OSCCAL_INSTR */
#ifdef EEPROM_SIZE
   for (i = 0; i < EEPROM_SIZE; i++)
      eeprom[i] = 0xff;
#endif  /* EEPROM_SIZE */
   for (i = 0; i < MAX_KEYPINS; i++)
      key_pins[i].keytype = KEYMODE_UNUSED;  /* no functions defined! */
   tempcount = (frequency * 18L) / 4000L;
   if (tempcount > 65535L)
      watchdog_reset_count = 0;
   else
      watchdog_reset_count = 65535L - tempcount;
   su_txenable = SOFTUART_DEFAULT;  /* default to NONE */
   su_rxenable = SOFTUART_DEFAULT;  /* default to NONE */
   chkstack = TRUE;
   readusestris = TRUE;
   swap_screens = TRUE;
   chkwatchdog = TRUE;
   watchdog_enabled = configuration & CONFIG_WDTE;  /* flag: watchdog enabled */
#ifdef HAS_UART
   commport = 0;  /* set UART to screen/keyboard */
#endif  /* HAS_UART */
   uart_screen_maxrow = SCREEN_ROWS - 1;  /* use rows 0 .. SCREEN_ROWS - 1 */
   uart_screen_maxrowofs = SCREEN_COLS * uart_screen_maxrow * 2;
   oscope_maxwidth = SCREEN_COLS - 3;  /* -3 for "<port><bitnum> " */
   symboladdr = _showds();  /* get our DS */
   if (_showcs() > symboladdr)
      symboladdr = _showcs();  /* if CS is above DS, use that as high seg */
   symboladdr += 0x1000;       /* plus 64K in paragraphs */
   if (((peekw(0,0x0413) << 6) - symboladdr) < 0x1000)  /* if not 64K free */
      symboladdr = 0;  /* don't use symbols */
   else
      {
      i2c_seg = symboladdr + 0x1000;  /* put I2C 64K above symbols */
      if (((peekw(0,0x0413) << 6) - i2c_seg) < 0x1000)  /* if not 64K free */
         i2c_seg = 0;
#ifdef USE_ADDRLIST
      else
         {
         addrlist_seg = i2c_seg + 0x1000;  /* put ADDRLIST 64K above I2C */
         if (((peekw(0,0x0413) << 6) - addrlist_seg) < 0x0400)  /* if not 16K free */
            addrlist_seg = 0;
         }
#endif  /* USE_ADDRLIST */
      }
#asm
   mov  word vesamode_,0      ;default to no VESA
   mov  word vgamode_,0       ;default to no VGA
   mov  ax,4f00h              ;fn = get SuperVGA info
   push ds                    ;data seg
   pop  es                    ;to es
   mov  di,offset browse_screen_  ;es:di = 512-byte buffer  (browse_screen is big enough, use it)
   push bp                    ;always save bp
   int  10h                   ;call BIOS
   pop  bp                    ;restore bp
   cmp  ax,004fh              ;AH=0 --> success   AL=4Fh --> function supported
   jne  check_vga             ;nope, how about VGA stuff?
   push ds                    ;save our DS
   lds  si,word [di+0eh]      ;get ptr to supported VESA modes
   cld                        ;up!
vesa_check_modes:
   lodsw                      ;get mode
   cmp  ax,010bh              ;132 x 50 text?
   je   vesa_verify           ;yup, check it out
   inc  ax                    ;was this 0ffffh = end of table?
   jne  vesa_check_modes      ;no, try again
   pop  ds                    ;restore ds
   push ds                    ;current data seg
   pop  es                    ;to es
   jmp  check_vga             ;see if we can do VGA
vesa_verify:
   pop  ds
   mov  cx,ax                 ;VESA mode to cx
   mov  ax,4f01h              ;fn = get SuperVGA mode info
                              ;NOTE: ES:DI is still our 512-byte buffer
   push bp                    ;always save bp
   int  10h                   ;call BIOS
   pop  bp                    ;restore bp
   push ds                    ;our DS
   pop  es                    ;to ES
   cmp  ax,004fh              ;successful?
   jne  check_vga             ;no, try VGA
   mov  word vesamode_,010bh  ;set VESA modeflag
check_vga:
   mov  ax,1c00h              ;get save size
   mov  cx,5                  ;save regs and DAC
   push bp                    ;always save bp
   int  10h                   ;call BIOS
   pop  bp                    ;restore bp
   cmp  al,1ch                ;VGA present?
   jne  video_done            ;no, we're done
;
   mov  ax,1202h              ;fn = alternate function select
                              ;     -- select vertical resolution
                              ;al=02 --> 400 scan lines
   mov  bl,30h                ;alternate function select
   int  10h                   ;call BIOS
   cmp  ah,12h                ;AH=12h if function supported
   jne  video_done            ;not supported, we're done
   mov  word vgamode_,ax      ;save non-zero number as VGA installed flag
video_done:
#endasm
   }

cleanup()
   {
#ifdef HAS_UART
   if (commport)  /* if not directed to screen/keyboard */
      {
      reset_comm_interrupt();  /* NOTE: the reason that these are NOT in */
      reset_comm_port();  /* cleanup() is that they are not common to all PIC chips */
      }
#endif  /* HAS_UART */
   if (windowmode)  /* if either VESA or VGA */
      {
#asm
   mov  ax,0003h          ;fn = set mode, 80x25 text
   int  10h               ;call BIOS
#endasm
      }
   if (outputfile)
      close(outputfile);
   if (inputfile)
      close(inputfile);
   }

cmdline_error(str)
   BYTE *str;
   {
   WORD temp;

   for (temp = 0; temp < cmdptr; temp++)
      PUTS(space_str);
   PUTS(str);
   PUTS(nl_str);
   }

WORD parse(str)  /* parse next token from cmdline, return FALSE if nothing */
                 /* left to parse, else TRUE */
   BYTE *str;
   {
   WORD i;
   WORD inquote;  /* allow a double/single quoted string to be parsed as
                   * one token
                   */
   WORD whichquote;  /* double or single quote */

   inquote = FALSE;
   i = 0;
   str[0] = '\0';  /* clear string */
   while ((cmdline[cmdptr])
          && ((cmdline[cmdptr] == ' ')
              || (cmdline[cmdptr] == '\t') || (cmdline[cmdptr] == ',')
              || (cmdline[cmdptr] == CR)
              || (cmdline[cmdptr] == LF)
              || (cmdline[cmdptr] == '=')))
      cmdptr++;
   if (cmdline[cmdptr])
      {
      while ((cmdline[cmdptr])
              && (((cmdline[cmdptr] != ' ')
              &&   (cmdline[cmdptr] != '\t')
              &&   (cmdline[cmdptr] != ',')
              &&   (cmdline[cmdptr] != '=')
              &&   (cmdline[cmdptr] != '&')
              &&   (cmdline[cmdptr] != CR)
              &&   (cmdline[cmdptr] != LF))
              || (inquote)))
         {
         if ((cmdline[cmdptr] == '\"') || (cmdline[cmdptr] == '\''))
            if (inquote)
               {
               if (cmdline[cmdptr] == whichquote)
                  inquote = FALSE;
               }
            else
               {
               inquote = TRUE;
               whichquote = cmdline[cmdptr];
               }
         str[i++] = cmdline[cmdptr++];
         }
      str[i] = '\0';
      }
   if ((!cmdline[cmdptr]) && (i == 0))  /* if only spaces, etc, were left */
      return(FALSE);
   return(TRUE);
   }

WORD get_address_range(start,end,default_delta)
   WORD *start, *end;
   WORD default_delta;
   {
   DWORD hold;
   WORD i;

   if (!parse(fromhexstr))  /* if blank command line */
      return(TRUE);  /* that's OK */
   if (!fromhex(fromhexstr,&hold))
      {
      cmdline_error(address_str);
      return(FALSE);
      }
   if (hold >= MAX_MEMORY_SIZE)
      {
      cmdline_error(range_str);
      return(FALSE);
      }
   *start = hold;
   *end = (hold + default_delta) & MAX_MEMORY_MASK;
   if (!parse(fromhexstr))  /* if no more parameters */
      return(TRUE);  /* that's OK */
   if (toupper(fromhexstr[0]) == 'L')  /* if specifying a length */
      {
      for (i = 1; fromhexstr[i]; i++)
         if (!iswhite(fromhexstr[i]))
            break;
      if ((!fromhexstr[i])  /* if just 'l' */
            || (!fromhex(&fromhexstr[i],&hold))
            || (hold == 0))
         {
         cmdline_error(number_str);
         return(FALSE);
         }
      hold = (hold - 1 + *start) & MAX_MEMORY_MASK;
      }
   else
      if (!fromhex(fromhexstr,&hold))
         {
         cmdline_error(number_str);
         return(FALSE);
         }
   if (hold >= MAX_MEMORY_SIZE)
      {
      cmdline_error(range_str);
      return(FALSE);
      }
   *end = hold;
   return(TRUE);
   }

WORD get_memory_range(start,end,default_delta,start_only,no_defaults)
   WORD *start, *end;
   WORD default_delta;
   WORD start_only;  /* TRUE = need START only, FALSE = need both START and END */
   WORD no_defaults;  /* if TRUE, values must be entered */
   {
   DWORD hold;

   if (!parse(fromhexstr))  /* if blank command line */
      {
      if (no_defaults)
         {
         cmdline_error(address_str);
         return(FALSE);  /* flag nothing entered */
         }
      return(TRUE);  /* else that's OK */
      }
   if (!fromhex(fromhexstr,&hold))
      {
      cmdline_error(address_str);
      return(FALSE);
      }
   if (hold >= NUM_REGS)
      {
      cmdline_error(range_str);
      return(FALSE);
      }
   *start = hold;
   *end = (hold + default_delta) & (NUM_REGS-1);
   if (start_only)
      return(TRUE);
   if (!parse(fromhexstr))  /* if no more parameters */
      {
      if (no_defaults)
         {
         cmdline_error(range_str);  /* need to specify an ending location */
         return(FALSE);
         }
      return(TRUE);  /* that's OK */
      }
   if (!fromhex(fromhexstr,&hold))
      {
      cmdline_error(number_str);
      return(FALSE);
      }
   if (((WORD)hold >= NUM_REGS) || ((WORD)hold == *start))
      {
      cmdline_error(range_str);
      return(FALSE);
      }
   *end = hold;
   return(TRUE);
   }

#ifdef EEPROM_SIZE
WORD get_eeprom_range(start,end,default_delta,start_only,no_defaults)
   WORD *start, *end;
   WORD default_delta;
   WORD start_only;  /* TRUE = need START only, FALSE = need both START and END */
   WORD no_defaults;  /* if TRUE, values must be entered */
   {
   DWORD hold;

   if (!parse(fromhexstr))  /* if blank command line */
      {
      if (no_defaults)
         {
         cmdline_error(address_str);
         return(FALSE);  /* flag nothing entered */
         }
      return(TRUE);  /* else that's OK */
      }
   if (!fromhex(fromhexstr,&hold))
      {
      cmdline_error(address_str);
      return(FALSE);
      }
   if (hold >= EEPROM_SIZE)
      {
      cmdline_error(range_str);
      return(FALSE);
      }
   *start = hold;
   *end = (hold + default_delta) & (EEPROM_SIZE-1);
   if (start_only)
      return(TRUE);
   if (!parse(fromhexstr))  /* if no more parameters */
      {
      if (no_defaults)
         {
         cmdline_error(range_str);  /* need to specify an ending location */
         return(FALSE);
         }
      return(TRUE);  /* that's OK */
      }
   if (!fromhex(fromhexstr,&hold))
      {
      cmdline_error(number_str);
      return(FALSE);
      }
   if (((WORD)hold >= EEPROM_SIZE) || ((WORD)hold == *start))
      {
      cmdline_error(range_str);
      return(FALSE);
      }
   *end = hold;
   return(TRUE);
   }
#endif  /* EEPROM_SIZE */

WORD get_number(val)
   WORD *val;
   {
   WORD i;
   DWORD hold;

   if (!parse(fromhexstr))  /* if blank command line */
      {
      cmdline_error(number_str);
      return(FALSE);  /* that's NOT ok */
      }
   for (i = 0; fromhexstr[i]; i++)
      if (!isdigit(fromhexstr[i]))  /* all digits? */  /* Note:  This will reject negative numbers */
         {
         cmdline_error(number_str);
         return(FALSE);  /* nope, that's bad */
         }
   hold = atol(fromhexstr);
   if (hold > 65535)
      {
      cmdline_error(number_str);
      return(FALSE);  /* that's NOT ok */
      }
   *val = (WORD)hold;
   return(TRUE);
   }

WORD get_word(val)
   WORD *val;
   {
   DWORD hold;

   if (!parse(fromhexstr))  /* if blank command line */
      return(TRUE);  /* that's OK */
   if (!fromhex(fromhexstr,&hold))
      {
      cmdline_error(number_str);
      return(FALSE);
      }
   *val = hold;
   return(TRUE);
   }

WORD get_dword(val)
   DWORD *val;
   {
   DWORD hold;

   if (!parse(fromhexstr))  /* if blank command line */
      return(TRUE);  /* that's OK */
   if (!fromhex(fromhexstr,&hold))
      {
      cmdline_error(number_str);
      return(FALSE);
      }
   *val = hold;
   return(TRUE);
   }

WORD get_qword(val)
   DWORD *val;
   {
   DWORD hold, hold2;
   WORD cmdptr_hold, len;
   BYTE *p;

   cmdptr_hold = cmdptr;  /* in case we have to re-parse */
   if (!parse(fromhexstr))  /* if blank command line */
      return(TRUE);  /* that's OK */
   hold2 = 0;  /* default high word */
   p = fromhexstr;  /* pointer to low DWORD */
   if ((len = strlen(fromhexstr)) > 8)  /* if larger than a DWORD */
      {
      fromhexstr[len-8] = '\0';  /* isolate high DWORD */
      if ((len > 16)  /* if larger than a QWORD */
                     || (!fromhex(fromhexstr,&hold2)))  /* or a bad number */
         {
         cmdline_error(number_str);
         return(FALSE);
         }
      cmdptr = cmdptr_hold;  /* restore our command pointer */
      parse(fromhexstr);  /* get the full string again */
      p = &fromhexstr[len-8];  /* skip the high DWORD */
      }
   if (!fromhex(p,&hold))
      {
      cmdline_error(number_str);
      return(FALSE);
      }
   val[0] = hold;
   val[1] = hold2;
   return(TRUE);
   }

void cmd_softuart(whichcmd)  /* setup SOFTUART */
/* softuart <{!}pin> <txbaud> <7 or 8><ENO><1 or 2> {<{!}pin> <rxbaud> <7 or 8><ENO><1 or 2>} */
/* softuart OFF */
   WORD whichcmd;
   {
   WORD i;

   if (!cmdline[cmdptr])  /* no params, show SOFTUART status */
      {
      if (su_txenable)  /* if SOFTUART not in use */
                      /* Note:  while su_rxenable is optional, su_txenable is not */
         {
         PUTS(no_soft_uart);
         return;
         }
      sprintf(tempstr,"Softuart: TX: pin %x%x %u %d%c%d  RX: ",
         su_txport+0x0a,su_txpin,su_txbaud,su_txdatabits,su_txparity,su_txstopbits);
      PUTS(tempstr);
      if (su_rxenable)  /* if not soft RX port */
         PUTS("None\n");
      else
         {
         sprintf(tempstr,"pin %x%x %u %d%c%d\n",
            su_rxport+0x0a,su_rxpin,su_rxbaud,su_rxdatabits,su_rxparity,su_rxstopbits);
         PUTS(tempstr);
         }
      return;
      }
#ifdef HAS_UART
   if (commport == 0)  /* if screen/keyboard in use */
      {
      PUTS("Hardware UART already using screen/keyboard\n");
      return;
      }
#endif  /* HAS_UART */
   su_txenable = SOFTUART_DEFAULT;  /* clear SOFTUART */
   su_rxenable = SOFTUART_DEFAULT;  /* clear SOFTUART */
   su_txinvert = 0;  /* normal logic levels */
   su_rxinvert = 0;
   if (strcmpi(&cmdline[cmdptr],off_str) == 0)  /* if we're turning it off */
      return;  /* that's all! */
   /* get TX parameters */
   if (cmdline[cmdptr] == '!')
      {
      su_txinvert = 0xff;  /* invert logic levels */
      cmdptr++;
      }
   if (!valid_pin(&su_txport,&su_txpin,FALSE))
      return;
   if (!get_number(&su_txbaud))
      return;
   skip_cmd_spaces();
   if (su_txdatabits = cmdline[cmdptr])
      {
      cmdptr++;
      su_txdatabits -= '0';  /* make this a number */
      }
   skip_cmd_spaces();
   if (su_txparity = toupper(cmdline[cmdptr]))
      cmdptr++;
   skip_cmd_spaces();
   if (su_txstopbits = cmdline[cmdptr])
      {
      cmdptr++;
      su_txstopbits -= '0';  /* make this a number */
      }
   if (((su_txdatabits != 7) && (su_txdatabits != 8))
           || ((su_txparity != 'E') && (su_txparity != 'N') && (su_txparity != 'O'))
           || ((su_txstopbits != 1) && (su_txstopbits != 2))
           || (su_txbaud < 110) || (su_txbaud > 57600))
      {
      cmdline_error(syntax_str);
      return;
      }
   if (su_txbaud > frequency/16)
      {
      cmdline_error(frequency_too_slow);
      return;
      }
   /* Now, for RX */
   skip_cmd_spaces();  /* cleanup parsing */
   su_rxbaud = 0;  /* flag: no RX */
   if (cmdline[cmdptr])  /* if RX parameters given */
      {
      if (cmdline[cmdptr] == '!')  /* invert logic levels */
         {
         su_rxinvert = 0xffff;  /* yup, all 16 bits need to be set */
         cmdptr++;
         }
      if (!valid_pin(&su_rxport,&su_rxpin,FALSE))
         return;
      if (!get_number(&su_rxbaud))
         return;
      if (su_rxbaud == 0)  /* if our flag value! */
         su_rxbaud = 1;  /* just set an illegal baudrate */
      skip_cmd_spaces();
      if (su_rxdatabits = cmdline[cmdptr])
         {
         cmdptr++;
         su_rxdatabits -= '0';  /* make this a number */
         }
      skip_cmd_spaces();
      if (su_rxparity = toupper(cmdline[cmdptr]))
         cmdptr++;
      skip_cmd_spaces();
      if (su_rxstopbits = cmdline[cmdptr])
         {
         cmdptr++;
         su_rxstopbits -= '0';  /* make this a number */
         }
      if (((su_rxdatabits != 7) && (su_rxdatabits != 8))
              || ((su_rxparity != 'E') && (su_rxparity != 'N') && (su_rxparity != 'O'))
              || ((su_rxstopbits != 1) && (su_rxstopbits != 2))
              || (su_rxbaud < 110) || (su_rxbaud > 57600)
              || ((su_txport == su_rxport) && (su_txpin == su_rxpin)))
         {
         cmdline_error(syntax_str);
         return;
         }
      if (su_rxbaud > frequency/16)
         {
         cmdline_error(frequency_too_slow);
         return;
         }
      }  /* if (cmdline[cmdptr]) if RX parameters given */
   su_txbittiming = frequency / 4L / (DWORD)su_txbaud;  /* instrs/sec / (bits/sec) = instrs/bit */
   su_txtotalbits = 1 + su_txdatabits + su_txstopbits + ((su_txparity == 'N') ? 0 : 1);
   su_txstopmask = (su_txstopbits == 1) ? 0x8000 : 0xc000;
   su_txframemask = su_txstopmask | (1 << (16-su_txtotalbits));  /* check start bit for 0 as well as stop bits */
   su_txdatamask = (su_txdatabits == 7) ? 0x007f : 0x00ff;
   su_txdatashift = 8 - (su_txstopbits + ((su_txparity == 'N') ? 0 : 1));
   su_txcount = su_txtotalbits;  /* nothing being transmitted PIC --> USER now */
   su_txbitmask = bittable[su_txpin];  /* mask for this bit */
   su_txlastbit = su_txbitmask;  /* default to HIGH */
   su_txenable = 0;  /* turn on SoftUart TX */

   if (su_rxbaud)  /* if RX given */
      {
      su_rxbittiming = frequency / 4L / (DWORD)su_rxbaud;
      su_rxtotalbits = 1 + su_rxdatabits + su_rxstopbits + ((su_rxparity == 'N') ? 0 : 1);
      i = 1 + su_rxdatabits + ((su_rxparity == 'N') ? 0 : 1);  /* RX mask shift */
      su_rxstopmask = ((su_rxstopbits == 1) ? 0x0001 : 0x0003) << i;
      su_rxdatamask = (su_rxdatabits == 7) ? 0x007f : 0x00ff;
      su_rxcount = su_rxtotalbits;  /* nothing being received PIC <-- USER now */
      su_rxbitmask = bittable[su_rxpin];  /* mask for this bit */
      initial_ports[su_rxport][su_rxpin] = ~su_rxinvert;  /* default RX is "off" */
      input_ports[su_rxport] = (input_ports[su_rxport] & ~su_rxbitmask)
                   | (su_rxbitmask ^ su_rxinvert);  /* default RX is "off" */
      su_rxenable = 0;  /* send softuart to screen/keyboard */
      }
   }

WORD find_first(name,dta)
   BYTE *name, *dta;
   {
   WORD return_val, dta_ofs, dta_seg;

   return_val = 0;
#asm
   mov  ah,2fh              ;fn = get DTA
   int  21h                 ;call DOS
   mov  word [bp-4],bx      ;save old DTA offset
   mov  word [bp-6],es      ;save old DTA segment
   push ds                  ;copy DS
   pop  es                  ;to ES
   mov  dx,word [bp+6]      ;DS:DX = new DTA
   mov  ah,1ah              ;fn = set DTA
   int  21h                 ;call DOS
   mov  dx,word [bp+4]      ;DS:DX = wild card filename
   mov  cx,17h              ;attribute = ALL
   mov  ah,4eh              ;fn = find first
   int  21h                 ;call DOS
   jae  f_f_1               ;JNC f_f_1
   mov  word [bp-2],ax      ;else save error
f_f_1:
   mov  dx,word [bp-4]      ;get old DTA offset
   mov  ds,word [bp-6]      ;get old DTA segment
   mov  ah,1ah              ;fn = set DTA
   int  21h                 ;call DOS
   push es                  ;copy ES
   pop  ds                  ;to DS
#endasm
   return(return_val);
   }

WORD find_next(name,dta)
   BYTE *name, *dta;
   {
   WORD return_val, dta_ofs, dta_seg;

   return_val = 0;
#asm
   mov  ah,2fh              ;fn = get DTA
   int  21h                 ;call DOS
   mov  word [bp-4],bx      ;save old DTA offset
   mov  word [bp-6],es      ;save old DTA segment
   push ds                  ;copy DS
   pop  es                  ;to ES
   mov  dx,word [bp+6]      ;DS:DX = new DTA
   mov  ah,1ah              ;fn = set DTA
   int  21h                 ;call DOS
   mov  ah,4fh              ;fn = find next
   int  21h                 ;call DOS
   jae  f_n_1               ;JNC f_n_1
   mov  word [bp-2],ax      ;else save error
f_n_1:
   mov  dx,word [bp-4]      ;get old DTA offset
   mov  ds,word [bp-6]      ;get old DTA segment
   mov  ah,1ah              ;fn = set DTA
   int  21h                 ;call DOS
   push es                  ;copy ES
   pop  ds                  ;to DS
#endasm
   return(return_val);
   }

WORD changedir(to,save)
   BYTE *to, *save;
   {
   WORD return_val;

   return_val = 0;
#asm
   push ds                  ;copy ds
   pop  es                  ;to es
   mov  si,word [bp+4]      ;si = to
   mov  di,word [bp+6]      ;di = save
   cld                      ;up!
   cmp  byte [si+1],':'     ;drive specified?
   jne  changedir_nodrive   ;no, skip this
   mov  ah,19h              ;fn = get current disk
   int  21h                 ;call DOS
   add  al,'A'              ;change to letter
   stosb                    ;put in dest string
   mov  al,':'              ;a colon, designate drive
   stosb                    ;put in dest string
changedir_nodrive:
   mov  al,5ch              ;backslash, needed in path
   stosb                    ;put in dest string
   xchg di,si               ;need si = dest string
   mov  dl,0                ;default drive
   mov  ah,47h              ;fn = get current dir
   int  21h                 ;call DOS
   xchg si,di               ;di = dest string again
   cmp  byte [si+1],':'     ;once again, a drive?
   jne  changedir_nodrive_2 ;no, skip this
   lodsb                    ;get drive letter
   and  al,1fh              ;get drive number
   dec  al                  ;A=0, B=1, etc
   mov  dl,al               ;set drive for DOS
   mov  ah,0eh              ;fn = set drive
   int  21h                 ;call DOS
   mov  ah,19h              ;fn = get drive
   int  21h                 ;call DOS
   cmp  al,dl               ;drive set OK?
   jne  changedir_bad       ;no, skip this
   lodsb                    ;skip the ':' in the source
changedir_nodrive_2:
   mov  dx,si               ;use DX for DOS
   lodsb                    ;get first byte of pathname
   or   al,al               ;blank?
   je   changedir_good      ;yes, don't call DOS
   mov  ah,3bh              ;fn = set DIR
   int  21h                 ;call DOS
   jae  changedir_good      ;all OK, skip this
changedir_bad:
   inc  word [bp-2]         ;flag error return
changedir_good:
#endasm
   return(return_val);
   }

void cmd_dir(whichcmd)  /* get a directory */
   WORD whichcmd;
   {
   WORD count, linecount;
   BYTE path[STRING_SIZE];
   BYTE oldpath[STRING_SIZE];
   BYTE dta[STRING_SIZE];
   BYTE ch, ch2;  /* ch2 for alignment */

   linecount = 0;  /* page break */
   count = 0;  /* use as a counter */
   strcpy(tempstr,"*.*");
   if (parse(path))
      {
      strcpy(tempstr,path);
      ch = tempstr[strlen(tempstr)-1];  /* save last char */
      if (changedir(path,oldpath) == 0)   /* to, save */
                               /* if valid path */
         {
         if (ch != '\\')  /* if not path seperator */
            strcat(tempstr,"\\");  /* add it */
         strcat(tempstr,"*.*");
         }
      else
         if (ch == '\\')
            strcat(tempstr,"*.*");
      changedir(oldpath,dta);  /* throw away save path */
      }
   if (find_first(tempstr,dta) == 0)
      {
      do
         {
         if (linecount == SCREEN_ROWS-1)
            {
            PUTS(press_any);
            ci();
            PUTS(nl_str);
            linecount = 0;
            }
         PUTS(&dta[30]);  /* show name */
         if (++count % 4 == 0)
            {
            PUTS(nl_str);
            linecount++;
            }
         else
            PUTS(strlen(&dta[30]) > 6 ? "\t" : "\t\t");
         } while ((find_next(tempstr,dta) == 0)
                   && ((!csts()) || (ci() != ESC)));
      }
   else
      PUTS("No files\n");
   if (count % 4)
      PUTS(nl_str);
   }

#ifdef EEPROM_SIZE
void get_eeprom_str(start,end)
   WORD start, end;
   {
   WORD temp, temp2, temp3, index;
   BYTE asciistr[24];

   sprintf(tempstr," %02x: ",start & 0xf0);
   index = 2;
   asciistr[0] = ' ';  /* be neat in formatting */
   asciistr[1] = ' ';
   for (temp = (start & 0xf0); temp <= (end | 0x0f); temp++)
      {
      if ((temp < start) || (temp > end))
         {
         strcat(tempstr,"   ");
         asciistr[index++] = ' ';
         }
      else
         {
         sprintf(&tempstr[strlen(tempstr)],"%02x ",eeprom[temp]);
         if ((eeprom[temp] > ' ') && (eeprom[temp] <= '~'))
            asciistr[index++] = eeprom[temp];
         else
            asciistr[index++] = ' ';
         }
      if ((temp & 0x0f) == 7)
         strcat(tempstr," ");
      }
   asciistr[index++] = '\n';
   asciistr[index] = '\0';  /* terminate string */
   strcat(tempstr,asciistr);
   }

void cmd_eeprom(whichcmd)  /* show EEPROM values */
   WORD whichcmd;
   {
   WORD temp, temp2, temp3;
   WORD start, end;

   start = 0;
   end = EEPROM_SIZE - 1;
   if (cmdline[cmdptr])  /* if start (and maybe end...) */
      {
      if (!get_word(&start))
         return;
      if (start >= EEPROM_SIZE)
         {
         cmdline_error(range_str);
         return;
         }
      end = start;  /* default to single EEPROM location */
      skip_cmd_spaces();
      temp = FALSE;  /* LEN flag */
      if (toupper(cmdline[cmdptr]) == 'L')  /* if end given as a len */
         {
         temp = TRUE;
         cmdptr++;
         skip_cmd_spaces();
         }
      if (cmdline[cmdptr])  /* if end */
         {
         if (!get_word(&end))
            return;
         if (temp)  /* if LEN flag */
            end += start - 1;
         if ((end >= EEPROM_SIZE)
                       || (end <= start))
            {
            cmdline_error(range_str);
            return;
            }
         }
      else
         if (temp)  /* if LEN flag, no len given */
            {
            cmdline_error(range_str);
            return;
            }
      }
   for (temp = (start & 0xf0); temp <= (end | 0x0f); temp += 0x10)
      {
      get_eeprom_str(temp,MIN(end,temp+0x0f));
      PUTS(tempstr);
      }  /* for (temp = start; ...) */
   }

void cmd_eepromf(whichcmd)  /* EEPROM fill */
   WORD whichcmd;
   {
   eeprom_fill_enter(FALSE);  /* do a FILL */
   }

void cmd_eeprome(whichcmd)  /* EEPROM enter */
   WORD whichcmd;
   {
   eeprom_fill_enter(TRUE);  /* do an ENTER */
   }
#endif  /* EEPROM_SIZE */

void skip_cmd_spaces()
   {
   while ((cmdline[cmdptr]) && (iswhite(cmdline[cmdptr])))
      cmdptr++;
   }

WORD get_break_range(start,end,limit)
   WORD *start, *end;
   WORD limit;
/*
   Expected format:  start[,end]     --> end >= start, neither > LIMIT
                     if ,end missing --> end = start, not > LIMIT
                 wrong format, etc, gives err return and message out
   Returns:  0 = all ok
             1 = err
             2 = nothing more on command line
*/
   {
   DWORD hold,hold1,hold2,hold3;

   if (!parse(fromhexstr))
      return(2);  /* empty command line */
   else
      if (!fromhex(fromhexstr,&hold))
         {
         cmdline_error(number_str);
         return(1);  /* bad number */
         }
   if (hold > limit)
      {
      cmdline_error(range_str);
      return(1);  /* bad number */
      }
   hold2 = hold;  /* defalt to end == start */
   if (cmdline[cmdptr] == ',')
      {
      if (!parse(fromhexstr))
         return(2);
      if (!fromhex(fromhexstr,&hold2))
         {
         cmdline_error(number_str);
         return(1);
         }
      if ((hold2 > limit) || (hold2 < hold))
         {
         cmdline_error(range_str);
         return(1);  /* bad number */
         }
      }
   *start = hold;
   *end = hold2;
   return(0);
   }

WORD iseol(ch)
   BYTE ch;
   {
   if ((ch == '\015') || (ch == '\012'))
      return(TRUE);
   return(FALSE);
   }

WORD isfillenterstring(str)
   BYTE *str;
   {
   if ((str[0] == '\"') || (str[0] == '\''))  /* if it starts with a quote */
      {
      if ((str[strlen(str)-1] != str[0]) || (strlen(str) < 3))
             /* if not matching quotes, or empty quotes */
         return(FALSE);
      else
         return(TRUE);
      }
   else  /* no starting quote, no good */
      return(FALSE);
   }

do_fill_enter(do_enter)
   WORD do_enter;  /* TRUE if ENTER, else FILL */
   {
   WORD temp, temp1;
   WORD start, end, len;
   DWORD hold;
   BYTE values[STRING_SIZE];

   if (!get_memory_range(&start,&end,0,do_enter,TRUE))
      return;  /* oops! */
       /* if ENTER, only start is valid.  If FILL, both start and end valid */
   len = 0;  /* index into values[] */
   while (parse(fh2))
      {
      if (isfillenterstring(fh2))  /* if a legal string */
         {
         for (temp = 1; temp < strlen(fh2)-1; temp++)
            values[len++] = fh2[temp];
         }
      else
         {
         if ((!fromhex(fh2,&hold)) || (hold > 0xff))
            {
            cmdline_error(number_str);
            return;
            }
         values[len++] = (BYTE)hold;
         }
      }
   if (!len)  /* if no values given */
      {
      cmdline_error(number_str);
      return;
      }
   if (!do_enter)  /* if FILL */
      end = (end + 1) & (NUM_REGS-1); /* inc end so compare to start will include last byte */
   else
      end = (start + len) & (NUM_REGS-1);  /* if ENTER, get ending address */
   temp1 = num_reg_breakpoints; /* turn these off for now */
   num_reg_breakpoints = 0;
   temp = 0;
   do
      {
      filenum_temp = start;
      start = (start + 1) & (NUM_REGS-1);  /* allow for wrap */
      regval = values[temp++];
      write_regs();
      if (temp == len)
         temp = 0;
      } while (start != end);
   num_reg_breakpoints = temp1;
   }

#ifdef EEPROM_SIZE
eeprom_fill_enter(do_enter)
   WORD do_enter;  /* TRUE if ENTER, else FILL */
   {
   WORD temp;
   WORD start, end, len;
   DWORD hold;
   BYTE values[STRING_SIZE];

   if (!get_eeprom_range(&start,&end,0,do_enter,TRUE))
      return;  /* oops! */
       /* if ENTER, only start is valid.  If FILL, both start and end valid */
   len = 0;  /* index into values[] */
   while (parse(fh2))
      {
      if (isfillenterstring(fh2))  /* if a legal string */
         {
         for (temp = 1; temp < strlen(fh2)-1; temp++)
            values[len++] = fh2[temp];
         }
      else
         {
         if ((!fromhex(fh2,&hold)) || (hold > 0xff))
            {
            cmdline_error(number_str);
            return;
            }
         values[len++] = (BYTE)hold;
         }
      }
   if (!len)  /* if no values given */
      {
      cmdline_error(number_str);
      return;
      }
   if (!do_enter)  /* if FILL */
      end = (end + 1) & (EEPROM_SIZE-1); /* inc end so compare to start will include last byte */
   else
      end = (start + len) & (EEPROM_SIZE-1);  /* if ENTER, get ending address */
   temp = 0;
   do
      {
      eeprom[start] = values[temp++];
      start = (start + 1) & (EEPROM_SIZE-1);  /* allow for wrap */
      if (temp == len)
         temp = 0;
      } while (start != end);
   }
#endif  /* EEPROM_SIZE */

WORD getpage()   /* for BROWSE command */
   {
   WORD numin,i,j,count;

   lseek(filein,browse_pos,0);
   if ((numin = read(filein,browse_screen,BROWSE_SCREEN_SIZE)) == 0)
      return(numin);
   for (i = 0, j = 0, count = 0; i < numin; i++)
      {
      j = (browse_screen[i] == '\t') ? j - j%8 + 8 : j+1;
      if ((browse_screen[i] == '\012') || (j == 80))
         {
         if ((j != 80) || (browse_screen[i+1] != '\012'))
            if (++count == 23)
               break;
         j = 0;
         }
      }
   browse_pos += browse_screen[i] == '\012' ? i+1 : i;
   browse_screen[i] = '\0';
   return(numin);  /* show if EOF or not */
   }

pageup(again)   /* for BROWSE command */
   WORD again;
   {
   WORD numin,i,j,count,num;

   num = browse_pos > (DWORD)BROWSE_SCREEN_SIZE ? BROWSE_SCREEN_SIZE : (WORD)browse_pos;
   lseek(filein,browse_pos-(DWORD)num,0);
   numin = read(filein,browse_screen,num);
   for (i = numin, j = 0, count = 0; i > 0; i--, browse_pos--)
      {
      j = browse_screen[i] == TAB ? j - j%8 + 8 : j+1;
      if ((browse_screen[i] == LF) || (j == 80))
         {
         if ((j != 80) || (browse_screen[i-1] != LF))
            if (++count == 24)
               {
               if (browse_screen[i] == LF)
                  browse_pos++;
               break;
               }
         j = 0;
         }
      }
   if ((again) && (browse_pos))
      pageup(FALSE);  /* at start of this page, back up again */
   }

showpage()   /* for BROWSE command */
   {
   getpage();
   clrscr(window_data[WINDOW_COMMAND].numrows);
   curpos(0,0);
   PUTS(browse_header);
   PUTS(browse_screen);
   }

WORD gchar()  /* for browse(), I can probably replace this with keytest() */
      /* test keyboard and return 256 (to identify BYTE in al as not
       * significant) if no key hit, else char.
       * Note that 0 return means 1st keycode of a function key.
       */
   {
#asm
   mov  ah,1        ;test for key waiting
   int  16h         ;call BIOS
   jz   gchar1      ;if no character, flag it
   mov  ah,0        ;get keyboard character
   int  16h         ;call BIOS
   or   al,al       ;extended key?
   jnz  gchar3      ;no, skip this
   xchg al,ah       ;set al = scancode
gchar3:
   mov  ah,0        ;char = AL
   jmp  gchar2      ;skip flagging
gchar1:
   mov  ah,1       ;flag no character
gchar2:
#endasm
   }

BYTE *strupr(str)  /* for browse() */
   BYTE *str;
   {
   WORD i;

   i = -1;
   while (str[++i])
      str[i] = toupper(str[i]);
   return(str);
   }

WORD findstring(to_find,in_this_string)  /* for BROWSE */
   BYTE *to_find;
   BYTE *in_this_string;
   {
   WORD i,j,k,l;

   j = -1;
   k = strlen(to_find);
   l = strlen(in_this_string);
   if (k <= l)
      for (i = 0; (i <= l-k) && (j == -1); i++)
         if (strncmp(&in_this_string[i],to_find,k) == 0)
            j = i;
   return(j);
   }

browse_file()
   {
   WORD ch, temp;
   DWORD oldpos;

   tempstr[0] = '\0';  /* so Again won't go crazy */
   showpage();
   do
      {
      while ((ch = gchar()) > 255)
         ;   /* get next char */
      ch = toupper(ch);
      switch(ch)
         {
         case 'G':  /* Home */
            browse_pos = 0;
            showpage();
            break;
         case 'O':  /* End */
            browse_pos = lseek(filein,0L,2);
            pageup(FALSE);
            showpage();
            break;
         case 'H':  /* PgUp and Up */
         case 'I':
            pageup(TRUE);
            showpage();
            break;
         case 'P':  /* PgDn and Down */
         case 'Q':
            showpage();
            break;
         case 'F':  /* Find and Again */
         case 'A':
            if (ch == 'F')  /* if Find */
               {
               clrscr(1);
               curpos(0,0);
               getstr("Text? ",tempstr);
               }
            temp = 1;  /* default: supress "text not found" message */
            if (tempstr[0])  /* if something to find */
               {
               if (ch == 'A')  /* if again, start on following page */
                  getpage();
               strupr(tempstr);
               oldpos = browse_pos;  /* remember starting position */
               while (temp = getpage())
                  {
                  strupr(browse_screen);
                  if (findstring(tempstr,browse_screen) != -1)
                     break;
                  }
               if (temp == 0)  /* if not found */
                  browse_pos = oldpos;  /* back to original page */
               else
                  pageup(FALSE);  /* go to start of this page */
               }
            showpage();
            if (!temp)
               {
               curpos(1,6);
               PUTS("text not found!");
               }
            break;
         }  /* switch(ch) */
      } while (ch != ESC);
   pageup(FALSE);  /* set browse_pos to start of this page, re-enter here next time */
   close(filein);
   curpos(24,0);
   PUTS(nl_str);
   }

WORD ishexdigit(ch)  /* for load_hexfile() */
   BYTE ch;
   {
   if ((ch >= '0') && (ch <= '9'))
      return(TRUE);
   if ((toupper(ch) >= 'A') && (toupper(ch) <= 'F'))
      return(TRUE);
   return(FALSE);
   }

WORD check_hex_string(str)  /* for load_hexfile() */
   BYTE *str;
   {
   while ((*str) && (*str != '\015') && (*str != '\012'))
      {
      if (!ishexdigit(*str))
         return(FALSE);
      str++;
      }
   return(TRUE);
   }

WORD hexbytevalue(str)  /* for load_hexfile() */
   BYTE *str;
   {
   WORD val;
   BYTE hold;

   hold = str[2];
   str[2] = '\0';
   sscanf(str,"%x",&val);
   str[2] = hold;
   return(val);
   }

WORD valid_checksum(str)  /* for load_hexfile() */
   BYTE *str;
   {
   WORD checksum;

   checksum = 0;
   while ((*str) && (*str != '\015') && (*str != '\012')
            && (*(str+1)) && (*(str+1) != '\015') && (*(str+1) != '\012'))
      {
      checksum += hexbytevalue(str);
      str += 2;
      }
   if (checksum & 0xff)
      return(FALSE);
   return(TRUE);
   }

WORD valid_hexline(linecount,str)
   WORD linecount;
   BYTE *str;
   {
   WORD is_hex_string, len_bad, chksum_valid;

   len_bad = 0;
   is_hex_string =
   chksum_valid = TRUE;
   if ((strlen(str) < 12) || (str[0] != ':')
          || (str[7] != '0')
          || ((str[8] != '0') && ((str[8] < '1') || (str[8] > '5')))
          || (!(is_hex_string = check_hex_string(&str[1])))
          || ((len_bad = strlen(str) & 1))
          || (!(chksum_valid = valid_checksum(&str[1]))))
      {
      sprintf(tempstr,"Error: corrupt/invalid hex file at line %d%s.\n",
           linecount,
           (is_hex_string ? ((len_bad == 0) ? (chksum_valid ? "" : " (bad checksum)") : " (bad len)") : " (not hex)"));
      PUTS(tempstr);
      return(FALSE);
      }
   if (str[8] == '4')  /* if extended linear address record */
      {
      if (hexwordvalue(&str[9]) != 0)
         {
         PUTS("Error: extended linear address out of range.\n");
         return(FALSE);
         }
      return(TRUE);
      }
   if ((str[8] == '2') || (str[8] == '3'))
            /* if segment address */
      {
      PUTS("Error: segment address records not supported.\n");
      return(FALSE);
      }
   if (str[8] == '5')  /* if linear address */
      {
      PUTS("Error: linear address records not supported.\n");
      return(FALSE);
      }
   return(TRUE);
   }

load_hexfile()
   {
   WORD start, addr, bytecount, i;
   WORD linecount;

   linecount = 0;
   for (addr = 0 ; addr < MEMORY_SIZE; addr++)
      memory[addr] = INSTRUCTION_BITMASK;  /* fill with 0xff bits */
#ifdef OSCCAL_INSTR
   memory[OSCCAL_INSTR_LOC] = OSCCAL_INSTR;
#endif  /* OSCCAL_INSTR */
   numsymbols = 0;  /* erase symbol table */
   while (fgets(tempstr,126,filein))
         /*
          *  WARNING: I'm taking advantage of a DeSmet C "quirk" here.  I've
          *           used open() instead of fopen() on the file, but I'm
          *           calling fgets().  DeSmet does not distinguish between
          *           the types of file handles, and so this works.  This
          *           makes porting harder, however.
          */
      {
      if (!valid_hexline(++linecount,tempstr))
         return;
      bytecount = hexbytevalue(&tempstr[1]);
      start = hexwordvalue(&tempstr[3]);
      if ((bytecount & 1) || (start & 1)) /* if not an even number of BYTES */
         {
         PUTS("Error:  Hex file does not contain WORD data.\n");
         return;
         }
      addr = start >> 1;  /* get WORD address */
      if (addr >= MEMORY_SIZE)
              /* check for ID bits / configuaration / EEPROM, else error */
         {
#ifdef EEPROM_SIZE
         if ((addr >= EEPROM_LOC) && (addr < EEPROM_LOC+EEPROM_SIZE))
                       /* if EEPROM data */
            {
            for (i = 9, addr -= EEPROM_LOC; i < bytecount+bytecount+9; i += 4, addr++)
               {
               if (addr >= EEPROM_SIZE)
                  {
                  PUTS("Error: EEPROM data out of range!\n");
                  return;
                  }
               eeprom[addr] = hexbytevalue(&tempstr[i]);
               }
            }
         else
#endif  /* EEPROM_SIZE */
            if ((addr == CONFIG_LOC) && (bytecount == 2))
               {
               configuration = (hexbytevalue(&tempstr[9])
                          + (hexbytevalue(&tempstr[11]) << 8)) & CONFIG_MASK;
               update_config_params();  /* update I/O pin usage, etc */
               }
            else
               if ((addr < ID_LOC) || (addr > ID_END))
                  {
                  PUTS("Error:  Hex file too big for memory!\n");
                  return;
                  }
         }
      else
         {
         for (i = 9; i < bytecount+bytecount+9; i += 4, addr++)
            {
            if (addr >= MEMORY_SIZE)
               {
               PUTS("Error:  Hex file too big for memory!\n");
               return;
               }
            memory[addr] = (hexbytevalue(&tempstr[i])
                                  + (hexbytevalue(&tempstr[i+2]) << 8))
                              & INSTRUCTION_BITMASK;
            }  /* for (i = 9; ...) */
         }  /* if (start >= ...) else */
      }  /* while (fgets()) */
   }

load_codfile()
   {
   BYTE code_map[MAP_SIZE];  /* get MAP (for .COD file) */
   BYTE sector_map[SECTMAP_SIZE];  /* sector map (for .COD file) */
   WORD temp;
   WORD startaddr, startaddr2, endaddr, size;
   WORD first_mapsector, last_mapsector;
   WORD mapindex;
   WORD first_symsector, last_symsector;
   WORD symtab_ofs, symtab_size;
   DWORD filesector;

   lseek(filein,0L,0);  /* back to beginning of file */
   if (read(filein,sector_map,SECTMAP_SIZE) == 0)
      {
      PUTS(not_a_codfile);
      return;
      }
   first_mapsector = *(WORD *)&sector_map[CODFILE_FIRST_MAPSECTOR];
   last_mapsector = *(WORD *)&sector_map[CODFILE_LAST_MAPSECTOR];
   first_symsector = *(WORD *)&sector_map[CODFILE_SYMTAB_START];
   last_symsector = *(WORD *)&sector_map[CODFILE_SYMTAB_END];
   lseek(filein,(DWORD)CODFILE_SECTOR_SIZE * (DWORD)first_mapsector,0);  /* goto code map table */
   if (read(filein,code_map,MAP_SIZE) != MAP_SIZE)
      {
      PUTS(not_a_codfile);
      return;
      }
   for (temp = 0; temp < MEMORY_SIZE; temp++)
      memory[temp] = INSTRUCTION_BITMASK;
#ifdef OSCCAL_INSTR
   memory[OSCCAL_INSTR_LOC] = OSCCAL_INSTR;
#endif  /* OSCCAL_INSTR */
   numsymbols = 0;  /* erase symbol table */
   mapindex = 0;
   while (first_mapsector <= last_mapsector)
      {
      startaddr = *(WORD *)&code_map[mapindex];
      endaddr = *(WORD *)&code_map[mapindex+2];
              /* NOTE:
               *    I think the following code is more complex than it needs
               *    to be, but I'm going to allow for the possibility that
               *    code sections are neither contiguous nor in order.
               */
      while (startaddr < endaddr)  /* do entire section */
         {
         if ((filesector = (DWORD)(*(WORD *)&sector_map[(startaddr >> 8) & 0xfe])) == 0)
            {
            PUTS("  invalid sector map.");
            PUTS(not_a_codfile);
            return;
            }
         lseek(filein,filesector * (DWORD)CODFILE_SECTOR_SIZE + (startaddr % CODFILE_SECTOR_SIZE),0);
         size = MIN(endaddr-startaddr+1,CODFILE_SECTOR_SIZE - (startaddr % CODFILE_SECTOR_SIZE));
         if ((startaddr2 = startaddr/2) >= MEMORY_SIZE)  /* not legal, special memory location? */
            {
            if ((startaddr2 == CONFIG_LOC) && (size == 2))  /* if CONFIG data */
               {
               if (read(filein,&temp,2) != 2)
                  {
                  PUTS(codfile_badread);
                  return;
                  }
               configuration = temp;
               update_config_params();  /* update I/O pin usage, etc */
               }
            else
               {
#ifdef EEPROM_SIZE
               if ((startaddr2 >= EEPROM_LOC) && ((startaddr2+(size/2)) <= EEPROM_LOC+EEPROM_SIZE))
                               /* if EEPROM (allow EEPROM to come in pieces) */
                  {
                  if (read(filein,browse_screen,size) != size)  /* browse_screen not in use here */
                     {
                     PUTS(codfile_badread);
                     return;
                     }
                  for (temp = 0; temp < size; temp += 2)
                     eeprom[temp/2] = *(WORD *)&browse_screen[temp];
                  }
               else
                  {
#endif  /* EEPROM_SIZE */
               if ((startaddr2 < ID_LOC) || (startaddr2+(size/2) > ID_END+1))
                  {
                  PUTS(invalid_memory_map);
                  return;
                  }
#ifdef EEPROM_SIZE
                  }
#endif  /* EEPROM_SIZE */
               }
            }
         else
            {
            if ((startaddr2 + size/2) > MEMORY_SIZE)
               {
               PUTS(invalid_memory_map);
               return;
               }
            if (read(filein,&memory[startaddr/2],size) != size)
               {
               PUTS(codfile_badread);
               return;
               }
            }
         startaddr += size;
         }  /* while (startaddr != endaddr) */
      mapindex += 4;
      if (mapindex == CODFILE_SECTOR_SIZE)  /* time for next map sector */
         {
         if (++first_mapsector <= last_mapsector)
            {
            lseek(filein,(DWORD)CODFILE_SECTOR_SIZE * (DWORD)first_mapsector,0);  /* goto code map table */
            if (read(filein,code_map,MAP_SIZE) != MAP_SIZE)
               {
               PUTS(not_a_codfile);
               return;
               }
            mapindex = 0;
            }
         }  /* if (mapindex == CODFILE_SECTOR_SIZE) */
      }  /* while (first_mapsector <= last_mapsector) */
   if (!symboladdr)
      return;  /* no room for symbol table */
   while (first_symsector <= last_symsector)
      {
      lseek(filein,(DWORD)CODFILE_SECTOR_SIZE * (DWORD)first_symsector,0);
      if (read(filein,browse_screen,CODFILE_SECTOR_SIZE) != CODFILE_SECTOR_SIZE)
         {
         PUTS(codfile_badread);
         return;
         }
      for (temp = 0; temp < CODFILE_SECTOR_SIZE; temp += SYMTAB_ENTRY_SIZE)
         {
         if (!browse_screen[temp])  /* if end of symbol table */
            return;
         if ((browse_screen[temp+SYMTAB_FLAGBYTE_OFS] >= SYMTAB_FLAGBYTE_FIRSTLABEL)
                 && (browse_screen[temp+SYMTAB_FLAGBYTE_OFS] <= SYMTAB_FLAGBYTE_LASTLABEL))
            {
            symtab_ofs = numsymbols * SYMTAB_ENTRY_SIZE;
            for (symtab_size = 0; symtab_size < browse_screen[temp]; symtab_size++)
               pokeb(symboladdr,symtab_ofs+symtab_size,browse_screen[temp+1+symtab_size]);
            for ( ; symtab_size < SYMTAB_VALUE_OFS; symtab_size++)
               pokeb(symboladdr,symtab_ofs+symtab_size,0);
            pokew(symboladdr,symtab_ofs+symtab_size,*(WORD *)&browse_screen[temp+SYMTAB_VALUE_OFS]);
            if (++numsymbols == MAX_SYMBOLS)
               return;  /* table full, we're done */
            }
         }
      first_symsector++;  /* next symbol sector */
      }
   }

load_picfile()
   {
   WORD i, showsave;
   BYTE tempregs[NUM_REGS];

   if (((picfile_hdr.filetype != FILETYPE_BIN)
              && (picfile_hdr.filetype != FILETYPE_PIM))
              || (picfile_hdr.version != PICFILE_VERSION))
      {
      PUTS("Unknown picfile type\n");
      return;
      }
#ifdef EEPROM_SIZE
   if ((strcmp(picfile_hdr.pictype,processor))
          || (picfile_hdr.memsize != MEMORY_SIZE)
          || ((picfile_hdr.filetype == FILETYPE_PIM)
                      && ((picfile_hdr.numregs != NUM_REGS)
                           || (picfile_hdr.numeeprom != EEPROM_SIZE))))
#else
   if ((strcmp(picfile_hdr.pictype,processor))
          || (picfile_hdr.memsize != MEMORY_SIZE)
          || ((picfile_hdr.filetype == FILETYPE_PIM)
                      && (picfile_hdr.numregs != NUM_REGS)))
#endif  /* EEPROM_SIZE */
      {
      PUTS("Picfile not for this processor.\n");
      return;
      }
   numsymbols = 0;  /* erase symbol table */
   if (read(filein,memory,MEMORY_SIZE << 1) != (MEMORY_SIZE << 1))
      {
      cmd_reset(CMD_NOTFOUND);  /* clear any partial reads */
      PUTS(cannot_read_str);
      return;
      }
   if (picfile_hdr.filetype == FILETYPE_BIN)
      return;  /* that's all for a BIN file */
   if (read(filein,tempregs,NUM_REGS) != NUM_REGS)
      {
      cmd_reset(CMD_NOTFOUND);  /* clear any partial reads */
      PUTS(cannot_read_str);
      return;
      }
#ifdef EEPROM_SIZE
   if (read(filein,eeprom,EEPROM_SIZE) != EEPROM_SIZE)
      {
      cmd_reset(CMD_NOTFOUND);  /* clear any partial reads */
      PUTS(cannot_read_str);
      return;
      }
#endif  /* EEPROM_SIZE */
   if (read(filein,uart_screen,SCREEN_ROWS * SCREEN_COLS * 2) != SCREEN_ROWS * SCREEN_COLS * 2)
      {
      cmd_reset(CMD_NOTFOUND);  /* clear any partial reads */
      PUTS(cannot_read_str);
      return;
      }
   w = picfile_hdr.w_reg;    /* restore regs */
   stack_ptr = picfile_hdr.stackptr;
   stack_depth = picfile_hdr.stackdepth;
   max_stack_depth = picfile_hdr.maxstackd;
   for (i = 0; i < MAX_STACK_SIZE; i++)
      stack[i] = picfile_hdr.stk[i];
   showsave = show_ports;
   show_ports = FALSE;
   for (i = NUM_REGS-1; i; i--)
      setreg(i,tempregs[i]);
          /* NOTE: go from "max" down to 1 so that regs mapped from higher
           *       banks to bank 0 will not over-write the correct bank 0
           *       values.
           */
   show_ports = showsave;
   w = picfile_hdr.w_reg;    /* restore regs */
   ip = picfile_hdr.ip_reg;
#ifdef CORE_12BIT
   regs[TRISA] = picfile_hdr.tris;
   regs[OPTION] = picfile_hdr.option;
#endif  /* CORE_12BIT */
   configuration = picfile_hdr.config;
   update_config_params();  /* update I/O pin usage, etc */
   screen_rowofs = picfile_hdr.scr_row;
   screen_colofs = picfile_hdr.scr_col;
   }

load_file()
   {
   lseek(filein,0L,0);  /* back to beginning of file */
   if (tempstr[0] == ':')  /* if this looks like a HEX file */
      load_hexfile();
   else
      {
      if (read(filein,&picfile_hdr,sizeof(picfile_hdr)) != sizeof(picfile_hdr))
         {
         PUTS(cannot_read_str);
         return;
         }
      if (strcmp(picfile_hdr.program_id,picemu_str) == 0)
         load_picfile();
      else
         load_codfile();  /* that's all that's left */
      }
   }

WORD keytest()
   {
#asm
   mov  ax,1100h   ;fn = check extended keypress
   int  16h        ;call BIOS
   jnz  havekey    ;NZ, scancode/ascii in AX
   mov  ax,0       ;default: no keypress waiting
   jmp  keytestexit ;and done
havekey:
   cmp  al,0       ;ASCII char = 0 (extended keypress?)
   jnz  stnd_ascii ;no, skip this
   mov  al,ah      ;scancode to al
   mov  ah,1       ;set extended keypress flag
   jmp  keytestexit ;and done
stnd_ascii:
   mov  ah,0       ;set scancode to 0
keytestexit:
#endasm
   }

WORD getkey()
   {
#asm
   mov  ax,1000h     ;fn = get extended keypress
   int  16h          ;call BIOS
   cmp  al,0         ;fnkey, etc?
   jz   getkey1_fnkey ;yes, skip this
   cmp  al,0e0h      ;fnkey, etc?
   jz   getkey1_fnkey ;yes, skip this
   mov  ah,0         ;ignore scancode
   jmp  getkey1_end  ;and done
getkey1_fnkey:
   mov  al,ah        ;set scancode = "key"
   mov  ah,1         ;set extended keypress flag
getkey1_end:
#endasm
   }

setcurpos(r,c)
   WORD r, c;
   {
#asm
   mov  dh,byte [bp+4]    ;get row
   mov  dl,byte [bp+6]    ;get col
   mov  bh,0              ;video page
   mov  ah,2              ;fn = set cursor pos
   int  10h               ;call BIOS
#endasm
   }

memfill(mem,len,value)  /* simpler to re-write than look it up */
   BYTE *mem;
   WORD len;
   WORD value;
   {
   while (len--)
      *(mem++) = value;
   }

WORD memcmp(buf1,buf2,len)
   BYTE *buf1, *buf2;
   WORD len;
   {
#asm
   cld                  ;up!
   mov  si,word [bp+4]  ;get buf1
   mov  di,word [bp+6]  ;get buf2
   mov  cx,word [bp+8]  ;get len
   mov  ax,ds
   mov  es,ax           ;make sure ES is correct
   repz cmpsb           ;compare memory
   mov  ax,0            ;default: equal
   je   memcmp_done     ;yup, quit
   inc  ax              ;set not-equal
memcmp_done:
#endasm
   }

cmdwindow_scroll(num)
   WORD num;   /* [BP+4] */
   {
   WORD r, c, numrows, numcols;
     /* r = [BP-2], c = [BP-4], numrows = [BP-6], numcols = [BP-8] */

   r = window_data[WINDOW_COMMAND].startrow;
   c = window_data[WINDOW_COMMAND].startcol;
   numrows = window_data[WINDOW_COMMAND].numrows;
   numcols = window_data[WINDOW_COMMAND].numcols;
#asm
   push es                    ;save regs
   push ds
   cld                        ;up!
   mov  ax,0b800h             ;video seg
   mov  es,ax                 ;to es
   mov  cx,word bytesperline_ ;get bytes per line
   mov  ax,word [bp-2]        ;get row
   mul  cx                    ;* bytes per line = offset
   add  ax,word [bp-4]        ;+ column
   add  ax,word [bp-4]        ;+ 2*column
   mov  di,ax                 ;es:di = ptr into video mem
   mov  bx,word [bp-6]        ;get number of rows on screen
   mov  ax,word [bp+4]        ;number of rows to scroll
   sub  bx,ax                 ;number of rows to move
   jz   cws_clear             ;scroll all, just do clear
   mul  cx                    ;*bytes per line = offset into screen
   add  ax,di                 ;plus start of screen = row to move
   mov  si,ax                 ;si = offset into screen
   push es                    ;video seg
   pop  ds                    ;to ds
   mov  dx,cx                 ;save bytes per line
cws_scroll:
   push di                    ;save ptrs
   mov  ax,si
   mov  cx,word [bp-8]        ;get number of cols
;   shr  cx,1                  ;get words to move
rep movsw                     ;scroll this line
   pop  di                    ;get ptrs
   mov  si,ax
   add  di,dx                 ;update dest ptr
   add  si,dx                 ;update source ptr
   mov  cx,dx                 ;restore bytes per line
   dec  bx                    ;count this row
   jnz  cws_scroll            ;not done, do next row
cws_clear:
   mov  bx,word [bp+4]        ;get number of rows to clear
   mov  ax,0720h              ;space, normal attribute
   mov  dx,cx                 ;save bytes per line
cws_clear_1:
   mov  si,di                 ;save dest ptr
   mov  cx,word [bp-8]        ;get number of cols
;   shr  cx,1                  ;get words to set
rep stosw                     ;clear line
   mov  di,si                 ;get dest ptr
   add  di,dx                 ;update dest ptr
   mov  cx,dx                 ;restore bytes per line
   dec  bx                    ;count this line
   jnz  cws_clear_1           ;not done, do next row
   pop  ds
   pop  es
#endasm
   }

uartwindow_scroll(num)
   WORD num;   /* [BP+4] */
   {
   WORD r, c, numrows, numcols;
     /* r = [BP-2], c = [BP-4], numrows = [BP-6], numcols = [BP-8] */

   r = window_data[WINDOW_COMMAND].startrow;
   c = window_data[WINDOW_COMMAND].startcol;
   numrows = uart_screen_maxrow;
   numcols = window_data[WINDOW_COMMAND].numcols;
#asm
   push es                    ;save regs
   push ds
   cld                        ;up!
   mov  ax,0b800h             ;video seg
   mov  es,ax                 ;to es
   mov  cx,word bytesperline_ ;get bytes per line
   mov  ax,word [bp-2]        ;get row
   mul  cx                    ;* bytes per line = offset
   add  ax,word [bp-4]        ;+ column
   add  ax,word [bp-4]        ;+ 2*column
   mov  di,ax                 ;es:di = ptr into video mem
   mov  bx,word [bp-6]        ;get number of rows on screen
   mov  ax,word [bp+4]        ;number of rows to scroll
   sub  bx,ax                 ;number of rows to move
   jz   uws_clear             ;scroll all, just do clear
   mul  cx                    ;*bytes per line = offset into screen
   add  ax,di                 ;plus start of screen = row to move
   mov  si,ax                 ;si = offset into screen
   push es                    ;video seg
   pop  ds                    ;to ds
   mov  dx,cx                 ;save bytes per line
uws_scroll:
   push di                    ;save ptrs
   mov  ax,si
   mov  cx,word [bp-8]        ;get number of cols
;   shr  cx,1                  ;get words to move
rep movsw                     ;scroll this line
   pop  di                    ;get ptrs
   mov  si,ax
   add  di,dx                 ;update dest ptr
   add  si,dx                 ;update source ptr
   mov  cx,dx                 ;restore bytes per line
   dec  bx                    ;count this row
   jnz  uws_scroll            ;not done, do next row
uws_clear:
   mov  bx,word [bp+4]        ;get number of rows to clear
   mov  ax,0720h              ;space, normal attribute
   mov  dx,cx                 ;save bytes per line
uws_clear_1:
   mov  si,di                 ;save dest ptr
   mov  cx,word [bp-8]        ;get number of cols
;   shr  cx,1                  ;get words to set
rep stosw                     ;clear line
   mov  di,si                 ;get dest ptr
   add  di,dx                 ;update dest ptr
   mov  cx,dx                 ;restore bytes per line
   dec  bx                    ;count this line
   jnz  uws_clear_1           ;not done, do next row
   pop  ds
   pop  es
#endasm
   }

clrscr(maxrow)
   WORD maxrow;  /* [BP+4] */
   {
   WORD r, c, numcols;  /* r = [BP-2], c = [BP-4], numcols = [BP-6] */

   r = window_data[WINDOW_COMMAND].startrow;
   c = window_data[WINDOW_COMMAND].startcol;
   numcols = window_data[WINDOW_COMMAND].numcols;
#asm
   push es                    ;save regs
   cld                        ;up!
   mov  ax,0b800h             ;video seg
   mov  es,ax                 ;to es
   mov  cx,word bytesperline_ ;get bytes per line
   mov  ax,word [bp-2]        ;get row
   mul  cx                    ;* bytes per line = offset
   add  ax,word [bp-4]        ;+ column
   add  ax,word [bp-4]        ;+ 2*column
   mov  di,ax                 ;es:di = ptr into video mem
   mov  bx,word [bp+4]        ;get number of rows to clear
   mov  ax,0720h              ;space, normal attribute
   mov  dx,cx                 ;save bytes per line
clrscr_1:
   mov  si,di                 ;save dest ptr
   mov  cx,word [bp-6]        ;get number of cols
;   shr  cx,1                  ;get words to set
rep stosw                     ;clear line
   mov  di,si                 ;get dest ptr
   add  di,dx                 ;update dest ptr
   mov  cx,dx                 ;restore bytes per line
   dec  bx                    ;count this line
   jnz  clrscr_1              ;not done, do next row
   pop  es
#endasm
   }

cmdwindow_puts(str)
   BYTE *str;
   {
   WORD r, c, len, count;

   r = window_data[WINDOW_COMMAND].startrow;
   c = window_data[WINDOW_COMMAND].startcol;
   len = window_data[WINDOW_COMMAND].numcols;
   while (*str)
      {
      if (*str == CR)
         {
         cmdwindow_row--;
         cmdwindow_col = len - 1;  /* take ++cmdwindow_col below into account */
         }
      else
         if (*str == LF)
            cmdwindow_col = len - 1;  /* take ++cmdwindow_col below into account */
         else
            {
            if (*str == TAB)
               {
               do
                  {
                  window_char(r+cmdwindow_row,c+(cmdwindow_col++),' '|VIDEO_NORMAL);
                  } while (((cmdwindow_col & 7) != 7) && (cmdwindow_col != len-1));
               }
            else
               window_char(r+cmdwindow_row,c+cmdwindow_col,*str|VIDEO_NORMAL);
            }
      if (++cmdwindow_col == len)
         {
         cmdwindow_col = 0;
         cmdwindow_row++;
         }
      if (cmdwindow_row == window_data[WINDOW_COMMAND].numrows)
         {
         cmdwindow_scroll(1);
         cmdwindow_row--;
         }
      str++;
      }
   setcurpos(r+cmdwindow_row,c+cmdwindow_col);
   }

myputs(str)
   BYTE *str;
   {
   if (outputfile)
      {
      if (write(outputfile,str,strlen(str)) != strlen(str))
         {
         cmdwindow_puts(disk_full_str);
         close(outputfile);
         outputfile = 0;
         }
      }
   cmdwindow_puts(str);
   }

myputsfile(str)  /* put to file, but not to screen */
   BYTE *str;
   {
   if (outputfile)
      {
      if (write(outputfile,str,strlen(str)) != strlen(str))
         {
         cmdwindow_puts(disk_full_str);
         close(outputfile);
         outputfile = 0;
         }
      }
   }

curpos(row,col)
   WORD row, col;
   {
   cmdwindow_row = row;
   cmdwindow_col = col;
   setcurpos(window_data[WINDOW_COMMAND].startrow+cmdwindow_row,
                      window_data[WINDOW_COMMAND].startcol+cmdwindow_col);
   }

WORD get_curpos()
   {
   return((cmdwindow_row << 8) + cmdwindow_col);
   }

/* The following function assumes that no scrolling is required to correctly
 * move the cursor
 */
move_cursor_left(times)
   WORD times;
   {
   WORD i;

   for (i = 0;  i < times; i++)
      {
      if (cmdwindow_col == 0)
         {
         cmdwindow_col = window_data[WINDOW_COMMAND].numcols - 1;
         cmdwindow_row--; /* no need to check if we're on the first row - no such long commands can be typed in */
         }
      else
         cmdwindow_col--;
      setcurpos(window_data[WINDOW_COMMAND].startrow+cmdwindow_row,
                window_data[WINDOW_COMMAND].startcol+cmdwindow_col);
      }
   }

/* The following function assumes that no scrolling is required to correctly
 * move the cursor
 */
move_cursor_right(times)
   WORD times;
   {
   WORD i;

   for (i = 0; i < times; i++)
      {
      if (cmdwindow_col < window_data[WINDOW_COMMAND].numcols - 1)
         cmdwindow_col++;
      else
         {
         cmdwindow_row++; /* no need to check if we're on the last row */
         cmdwindow_col = 0;
         }
      setcurpos(window_data[WINDOW_COMMAND].startrow+cmdwindow_row,
                window_data[WINDOW_COMMAND].startcol+cmdwindow_col);
      }
   }

/* MG: The original version of the following function managed real TABs.
 * To implement better cursor handling without having to write unreadable
 * code I decided to emulate TABs with spaces. The major differences are:
 *  - cannot delete the whole TAB: user has to delete spaces one by one
 *  - when INSerting characters before a TAB the line half on the right of
 *    the tab moves continuosly instead of clipping in columns multiple of 8.
 *  - when moving the cursor, it gets also "into" tabs and allows insertions and overtype of single spaces
 * The code, however, is now much more simple than it would be using real TABs.
 * Even the original version of the function is more complicated.
 */
cmdwindow_gets(prompt,str)
   BYTE *prompt,*str;
   {
   static BYTE previous[STRING_SIZE] = ""; /* Previous typed command */
   static BYTE buffer[STRING_SIZE];   /* Chars to print */
   WORD bufptr;
   WORD ch, len, zero_col, i, j;
   WORD count = 0;
   WORD currentwindow;  /* use to "tab" through selectable windows */
   BYTE *start;
   BYTE onechar[2];
   BYTE cursor_string_position = 0;
        /* relative to the beginning of the typed command, not to the GUI */
   BYTE update_previous = TRUE;

   currentwindow = 0;
   len = 0;  /* know where I am for backspace */
   start = str;  /* string beginning (str is incremented while typing) */
   zero_col = cmdwindow_col;
   onechar[1] = '\0';

   do
      {
      if (count == 0) /* Check if there are chars in the buffer */
         ch = getkey(); /* no, read from keyboard */
      else
         { /* yes, read from buffer */
         ch = buffer[bufptr++];
         count--;
         }
      if (ch == TAB) /* Set-up counter of space TABs */
         {
         count = 8 - (cmdwindow_col & 7);
         for (i = 0; i < count; i++)
            buffer[i] = ' ';
         bufptr = 0;
         continue;
         }
      if ((ch == F3) /* Set-up the retype of the last entered command */
               && (len < strlen(previous)))
         {
         count = 0;
         i = len;
         do
            {
            buffer[count++] = previous[i];
            } while (previous[i++] != '\0');
         bufptr = 0;
         count--;
         continue;
         }
      if (ch == F11)
         {
         reset_windows(currentwindow);
         PUTS(prompt);
         *str = '\0';
         PUTS(start);
         cursor_string_position = strlen(start);
         continue;
         }
      if (ch == CTRL_TAB)  /* if switch window */
         {
         draw_bar(WINDOW_COMMAND,VIDEO_NORMAL);
         do
            {
            if (++currentwindow == NUM_WINDOWS)
               currentwindow = 0;
            if (window_data[currentwindow].flags & WINDOW_SCROLLS)
               (*window_data[currentwindow].scrollfn)();
            } while (currentwindow);
         draw_bar(WINDOW_COMMAND,VIDEO_HIGHLIGHT);
         continue;  /* don't put this into our string */
         }
      if (ch == LTARROW)
         {
         if (cursor_string_position)
            {
            move_cursor_left(1);
            cursor_string_position--;
            }
         continue;
         }
      if (ch == RTARROW)
         {
         if (cursor_string_position < len)
            {
            move_cursor_right(1);
            cursor_string_position++;
            }
         continue;
         }
      if (ch == HOME)
         {
         move_cursor_left(cursor_string_position);
         cursor_string_position = 0;
         continue;
         }
      if (ch == END)
         {
         move_cursor_right(len - cursor_string_position);
         cursor_string_position = len;
         continue;
         }
      if (ch == INS)
         {
         current_ins_status = 1 - current_ins_status;
         draw_bar(WINDOW_COMMAND,VIDEO_HIGHLIGHT);
         continue;
         }
      if (ch == DEL) /* Uses the BS code */
         {
         if (cursor_string_position < len)
            {
            ch = BS;
            move_cursor_right(1);
            cursor_string_position++;
            }
         else
            continue;
         }
      if (ch == BS)
         {
            /* setup for bs-ing an "internal" char using the existing function
             * (that deletes the last character)
             */
         if (!cursor_string_position)
            continue; /* there isn't a character to delete */

            /* left shift of the string half on the right side of the cursor
             * (on screen too)
             */
         move_cursor_left(1);
         for (i = cursor_string_position; i < len; i++)
            {
            onechar[0] = start[i];
            PUTS(onechar);
            start[i-1] = start[i];
            }

         /* move the cursor to the last place */
         move_cursor_right(1);

         /* bs of last char (already present) */
         str--;
         len--;
         onechar[0] = ' ';  /* to erase screen */
         if (cmdwindow_col == 0)
            {
            cmdwindow_col = window_data[WINDOW_COMMAND].numcols - 1;
            cmdwindow_row--;
            }
         else
            cmdwindow_col--;
         PUTS(onechar);
         if (cmdwindow_col == 0)
            {
            cmdwindow_col = window_data[WINDOW_COMMAND].numcols - 1;
            cmdwindow_row--;
            }
         else
            cmdwindow_col--;
         setcurpos(window_data[WINDOW_COMMAND].startrow+cmdwindow_row,
                   window_data[WINDOW_COMMAND].startcol+cmdwindow_col);

         /* set the correct cursor position */
         move_cursor_left(len-(--cursor_string_position));
         continue;
         }
      if (ch == ESC) /* deletes the whole line */
         {
         len = 0;
         str = start;
         onechar[0] = '\\';
         PUTS(onechar);
         ch = CR;
         update_previous = FALSE;
         }
      if ((ch >= FIRST_MACRO_KEY) && (ch <= LAST_MACRO_KEY))
         {
         i = ch - FIRST_MACRO_KEY;  /* get index into macros */
         j = 0;  /* index into macro string */
         while ((macros[i][j]) && (macros[i][j] != '\n') && (len < STRING_SIZE-1))
            {
            onechar[0] =
            *(str++) = macros[i][j++];
            PUTS(onechar);
            len++;
            cursor_string_position++;
            }
         if (macros[i][j] == '\n')
            ch = CR;
         else
            continue;
         }
      if (ch & 0x100) /* avoid printing weird chars when unmanaged extended keys are pressed */
         continue;
      if ((ch != CR) && (len < STRING_SIZE-1))
         {
         if (cursor_string_position == len) /* adding a character on the last position */
            {
            *(str++) = ch;
            len++;
            }
         else /* cursor isn't at the end of the line */
            {
            if (current_ins_status) /* inserts a character (creates the required space) */
               {
               /* right shift of the string (on screen too) */
               move_cursor_right(len - cursor_string_position);
               for (i = len; i > cursor_string_position; i--)
                  {
                  start[i] = start[i-1];
                  onechar[0] = start[i];
                  PUTS(onechar);
                  move_cursor_left(2);
                  }
               str++;
               len++;
               } /* cursor and cursor_string_position are already OK */
            start[cursor_string_position] = ch; /* overtype (maybe of the newly inserted character) */
            }
         cursor_string_position++;
         onechar[0] = ch;
         PUTS(onechar);
         }
      } while (ch != CR);
   PUTS(nl_str);
   *str = '\0';

   /* Fills "previous" buffer */
   i = 0;
   if (update_previous)
      {
      do
         {
         previous[i] = start[i];
         } while (start[i++] != '\0');
      }
   }

mygets(prompt,str)
   BYTE *prompt,*str;
   {
   WORD ch;

   while (!(ch = keytest()))
      ;
   if (ch == F12)
      {
      while (keytest())
         getkey();
      str[0] = 't';
      str[1] = '\0';
      PUTS(nl_str);
      }
   else
      if (ch == F11)
         {
         while (keytest())
            getkey();
         reset_windows(0);  /* command window is current */
         str[0] = '\0';  /* clear input string */
         }
      else
         cmdwindow_gets(prompt,str);
   }

getstr(prompt,buf)
   BYTE *prompt, *buf;
   {
   WORD i;  /* don't overflow input buf */
   BYTE ch, ch2;  /* ch2 to keep stack aligned */

   PUTS(prompt);
   if (inputfile)  /* if input coming from file */
      {
      i = 0;
      while (TRUE)  /* use BREAK to get out */
         {
         if (read(inputfile,&ch,1) != 1)  /* if EOF */
            {
            close(inputfile);
            inputfile = 0;  /* we're done with this file */
            break;
            }
         if ((ch == CR) || (ch == LF))  /* if EOL */
            {
            if (read(inputfile,&ch,1) != 1)  /* if EOF on another char */
               {
               close(inputfile);
               inputfile = 0;
               break;
               }
            if ((ch != CR) && (ch != LF))  /* if not 2nd EOL char */
               lseek(inputfile,-1L,1);  /* lseek to CURRENT - 1 */
            if (lseek(inputfile,0L,1) == inputfilesize)  /* if EOF */
               {
               close(inputfile);
               inputfile = 0;
               }
            break;
            }
         if (i < STRING_SIZE-1)
            buf[i++] = ch;
         }
      buf[i] = '\0';  /* terminate string */
      PUTS(buf);
      PUTS(nl_str);
      }
   else
      {
      mygets(prompt,buf);
/*
      myputsfile(buf);
      myputsfile(nl_str);
*/
      }
   }

get_starttime()
   {
#asm
   push ds                     ;save our ds
   xor  ax,ax                  ;get a 0
   mov  ds,ax                  ;address INT/BIOS seg
   mov  ax,word [46ch]         ;get current ticks
get_starttime_wait:
   cmp  ax,word [46ch]         ;wait for start of tick
   je   get_starttime_wait
   mov  word [470h],0          ;clear dayflag
   lds  ax,word [46ch]         ;get current ticks
   mov  dx,ds                  ;save ticks highword
   pop  ds                     ;restore our ds
   mov  word startticks_,ax    ;save ticks lowword
   mov  word startticks_[2],dx ;and highword
#endasm
   }

get_endtime()
   {
#asm
   push ds                     ;save our ds
   xor  ax,ax                  ;get a 0
   mov  ds,ax                  ;address INT/BIOS seg
   mov  cl,byte [470h]         ;get day count
                  ;NOTE: on older BIOSes, this is a flag, not a count, so
                  ;      that days > 1 are lost.
   lds  ax,word [46ch]         ;get current ticks
   mov  dx,ds                  ;save ticks highword
   pop  ds                     ;restore our ds
   mov  word endticks_,ax      ;save ticks lowword
   mov  word endticks_[2],dx   ;and highword
   mov  ch,0                   ;make (BYTE)day count a WORD
   mov  word daycount_,cx      ;save daycount
   mov  word daycount_[2],0    ;as a DWORD
#endasm
   endticks += daycount * TICKS_PER_DAY;
   }

add_symbol(val,str)
   WORD val;
   BYTE *str;
   {
   if ((!symboladdr) || (!numsymbols))
      return;
#asm
   push es                  ;save seg
   mov  es,word symboladdr_ ;get symbol table seg
   mov  cx,word numsymbols_ ;get number of symbols to search
   mov  ax,word [bp+4]      ;get value to search for
   cld                      ;up!
   mov  di,14               ;offset of value in symbol table entry
add_symbol_1:
   scasw                    ;found our entry?
   je   add_symbol_found    ;yes, exit loop
   add  di,14               ;+ SYMTAB_ENTRY_SIZE-2
   loop add_symbol_1        ;try next entry
   jmp  add_symbol_notfound ;not found, we're done
add_symbol_found:
   sub  di,16               ;back to start of symbol
   mov  si,word [bp+6]      ;ds:si = destination
   xchg si,di               ;swap regs
   push ds                  ;swap segs
   push es
   pop  ds
   pop  es
add_symbol_loop:
   lodsb                    ;get symbol byte
   stosb                    ;to target string
   or   al,al               ;at EOS?
   jnz  add_symbol_loop     ;no, do next
;   dec  di                  ;back to EOS
;   mov  ax,3ah              ;':',00h
;   stosw                    ;finish string
   push es                  ;our ds
   pop  ds                  ;back to where it belongs!
add_symbol_notfound:
   pop  es                  ;restore es
#endasm
   }

window_char(r,c,ch)
   WORD r, c, ch;
   {
#asm
   push es                    ;save regs
   push di
   mov  ax,0b800h             ;video seg
   mov  es,ax                 ;to es
   mov  ax,word bytesperline_ ;bytes per line
   mul  word [bp+4]           ;*row = offset
   add  ax,word [bp+6]        ;+ column
   add  ax,word [bp+6]        ;+ 2*column
   xchg ax,di                 ;es:di = ptr into video mem
   mov  ax,word [bp+8]        ;get char/attribute
   stosw                      ;set char, attribute
   pop  di                    ;restore regs
   pop  es
#endasm
   }

window_line(r,c,str,attrib,max)
   WORD r, c, attrib, max;
   BYTE *str;
   {
#asm
   push es                    ;save regs
   push di
   mov  ax,0b800h             ;video seg
   mov  es,ax                 ;to es
   mov  ax,word bytesperline_ ;bytes per line
   mul  word [bp+4]           ;*row = offset
   add  ax,word [bp+6]        ;+ column
   add  ax,word [bp+6]        ;+ 2*column
   xchg ax,di                 ;es:di = ptr into video mem
   mov  si,word [bp+8]        ;ds:si = string to display
   mov  ah,byte [bp+11]       ;get attribute
   mov  cx,word [bp+12]       ;get max length
window_line_1:
   lodsb                      ;get string byte
   or   al,al                 ;at EOS?
   jz   window_line_2         ;yes, clear rest of line
   cmp  al,0ah                ;is this a '\n'?
   jz   window_line_2         ;yes, clear rest of line
   stosw                      ;set char, attribute
   dec  cx                    ;count this char
   jnz  window_line_1         ;not done, do more
   jmp  window_line_3         ;else quit
window_line_2:
   mov  al,20h                ;a space
rep stosw                     ;fill rest of line
window_line_3:
   pop  di                    ;restore regs
   pop  es
#endasm
   }

draw_bar(which,highlight)
   WORD which,highlight;
   {
   WORD i, r, c;

   if ((!(window_data[which].flags & WINDOW_DISPLAYED))
            || (!window_data[which].startrow))
      return;
   r = window_data[which].startrow-1;
   c = window_data[which].startcol + (i = window_data[which].numcols);
   window_char(r,c--,window_data[which].endchar|highlight);
   for (i--; i; i--, c--)
      window_char(r,c,HORIZ_BAR|highlight);
   window_char(r,c,window_data[which].startchar|highlight);
   for (i = 0, c += 2; window_labels[which][i]; i++, c++)
      window_char(r,c,window_labels[which][i]|highlight);
   if (which == WINDOW_COMMAND) /* Draw the INS or OVR label */
      for (i = 0, c += 2; insert_labels[current_ins_status][i]; i++, c++)
         window_char(r,c,insert_labels[current_ins_status][i]|highlight);
   if ((which != WINDOW_COMMAND) && (highlight == VIDEO_HIGHLIGHT))
      for (i = 0; scroll_prompt[i]; i++, c++)
         window_char(r,c,scroll_prompt[i]|highlight);
   }

update_windows()
   {
   update_instruction(VIDEO_NORMAL);
   update_register(VIDEO_NORMAL);
   update_eeprom(VIDEO_NORMAL);
   update_watch(VIDEO_NORMAL);
   update_ports(VIDEO_NORMAL);
   update_where(VIDEO_NORMAL);
   update_disasm(VIDEO_NORMAL);
   }

update_instruction(highlight)
   WORD highlight;  /* not scrollable, never used */
   {
   if (!(window_data[WINDOW_INSTR].flags & WINDOW_DISPLAYED))
      return;
    /* instruction window is always in the same place */
   get_total_str();
   window_line(0,0,tempstr,VIDEO_NORMAL,79);
   get_delta_str();
   window_line(1,0,tempstr,VIDEO_NORMAL,79);
   get_stopw_str();
   window_line(2,0,tempstr,VIDEO_NORMAL,79);
   get_stack_str();
   window_line(3,0,tempstr,VIDEO_NORMAL,79);
   get_status_str();
   window_line(4,0,tempstr,VIDEO_NORMAL,79);
   get_instr_str(ip);
   window_line(5,0,instr_str,VIDEO_NORMAL,79);
   }

update_register(highlight)
   WORD highlight;
   {
   WORD r, i;

   if (!(window_data[WINDOW_REGS].flags & WINDOW_DISPLAYED))
      return;
    /* regs window is always in the same place */
   for (r = window_data[WINDOW_REGS].startrow, i = window_data[WINDOW_REGS].startnum;
                 i <= window_data[WINDOW_REGS].endnum; i += 0x10)
      {
      sprintf(tempstr," %3x: ",i);
      build_regdump_tempstr(i,i+0x0f,FALSE);  /* don't use showregs[] */
      window_line(r++,0,tempstr,highlight,79);
      }
   }

update_eeprom(highlight)
   WORD highlight;
   {
#ifdef EEPROM_SIZE
   WORD r, i;

   if (!(window_data[WINDOW_EEPROM].flags & WINDOW_DISPLAYED))
      return;
    /* regs window is always in the same place */
   for (r = window_data[WINDOW_EEPROM].startrow, i = window_data[WINDOW_EEPROM].startnum;
                 i <= window_data[WINDOW_EEPROM].endnum; i += 0x10)
      {
      get_eeprom_str(i,i+0x0f);
      window_line(r++,0,tempstr,highlight,79);
      }
#endif  /* EEPROM_SIZE */
   }

update_watch(highlight)
   WORD highlight;  /* not scrollable, never used */
   {
   WORD num, r;

   if (!(window_data[WINDOW_WATCH].flags & WINDOW_DISPLAYED))
      return;
   r = window_data[WINDOW_WATCH].startrow;
   for (num = 0; num < 3; num++)
      window_line(r++,window_data[WINDOW_WATCH].startcol,"",
                     VIDEO_NORMAL,window_data[WINDOW_WATCH].numcols);
                        /* clear line */
   update_watch_display();
   }

update_ports(highlight)
   WORD highlight;  /* not scrollable, never used */
   {
   if (!(window_data[WINDOW_PORTS].flags & WINDOW_DISPLAYED))
      return;
   window_line(window_data[WINDOW_PORTS].startrow - 1,
              window_data[WINDOW_PORTS].startcol + 3,
#ifdef PINS_8
              "          5    4    3    2    1    0",
#else
              "7    6    5    4    3    2    1    0",
#endif  /* PINS_8 */
               VIDEO_NORMAL,window_data[WINDOW_PORTS].numcols-9);
   io_processing();
   }

update_where(highlight)
   WORD highlight;
   {
   WORD r, c, len, number, index;

   if (!(window_data[WINDOW_WHERE].flags & WINDOW_DISPLAYED))
      return;
   r = window_data[WINDOW_WHERE].startrow;
   c = window_data[WINDOW_WHERE].startcol + 4;
   len = window_data[WINDOW_WHERE].numcols - 4;
   index = (whereptr + (WHERE_SIZE+1 - window_data[WINDOW_WHERE].startnum)) & WHERE_SIZE;  /* get start */
   for (number = window_data[WINDOW_WHERE].numrows ; number; number--)
      {
      if (wherequeue[index] < MAX_MEMORY_SIZE)
         {
         get_instr_str(wherequeue[index]);
         window_line(r++,c,instr_str,highlight,len);
         }
      else
         window_line(r++,c,"",highlight,len);
      index = (index + 1) & WHERE_SIZE;
      }
   }

update_disasm(highlight)
   WORD highlight;
   {
   WORD r, c, c4, len4, i, number;

   if (!(window_data[WINDOW_DISASM].flags & WINDOW_DISPLAYED))
      return;
   r = window_data[WINDOW_DISASM].startrow;
   c = window_data[WINDOW_DISASM].startcol+1;
   c4 = c + 3;
   len4 = window_data[WINDOW_DISASM].numcols - 4;
   number = window_data[WINDOW_DISASM].numrows;
   i = window_data[WINDOW_DISASM].startnum;
   for ( ; number; number--)
      {
      get_instr_str(i);
      window_line(r,c,(i == (ip & MEMORY_MASK)) ? "-> " : "",highlight,3);
      window_line(r++,c4,instr_str,highlight,len4);
      i = (i + 1) & MEMORY_MASK;
      }
   }

void scroll_regs()
   {
   WORD ch;
   WORD numregs;

   numregs = window_data[WINDOW_REGS].numrows << 4;
   draw_bar(WINDOW_REGS,VIDEO_HIGHLIGHT);
   do
      {
      update_register(VIDEO_HIGHLIGHT);
      if ((ch = getkey()) == F11)  /* get user keypress */
         {
         reset_windows(WINDOW_REGS);
         continue;
         }
      switch (ch)
         {
         case UPARROW:
            if (window_data[WINDOW_REGS].startnum)
               {
               window_data[WINDOW_REGS].startnum -= 0x10;
               window_data[WINDOW_REGS].endnum -= 0x10;
               }
            break;
         case DNARROW:
            if (window_data[WINDOW_REGS].endnum < NUM_REGS-1)
               {
               window_data[WINDOW_REGS].startnum += 0x10;
               window_data[WINDOW_REGS].endnum += 0x10;
               }
            break;
         case PGUP:
            if (window_data[WINDOW_REGS].startnum > numregs)
               window_data[WINDOW_REGS].startnum -= numregs;
            else
               window_data[WINDOW_REGS].startnum = 0;
            window_data[WINDOW_REGS].endnum =
                          window_data[WINDOW_REGS].startnum + numregs - 1;
            break;
         case PGDN:
            window_data[WINDOW_REGS].endnum =
               MIN(NUM_REGS-1,window_data[WINDOW_REGS].endnum+numregs);
            window_data[WINDOW_REGS].startnum =
                          window_data[WINDOW_REGS].endnum - numregs + 1;
            break;
         case HOME:
            window_data[WINDOW_REGS].startnum = 0;
            window_data[WINDOW_REGS].endnum = numregs - 1;
            break;
         case END:
            window_data[WINDOW_REGS].endnum = NUM_REGS - 1;
            window_data[WINDOW_REGS].startnum =
               window_data[WINDOW_REGS].endnum - numregs + 1;
            break;
         }
      } while (ch != CTRL_TAB);
   draw_bar(WINDOW_REGS,VIDEO_NORMAL);
   update_register(VIDEO_NORMAL);
   }

void scroll_eeprom()
   {
#ifdef EEPROM_SIZE
   WORD ch;
   WORD numeeprom;

   numeeprom = window_data[WINDOW_EEPROM].numrows << 4;
   draw_bar(WINDOW_EEPROM,VIDEO_HIGHLIGHT);
   do
      {
      update_eeprom(VIDEO_HIGHLIGHT);
      if ((ch = getkey()) == F11)  /* get user keypress */
         {
         reset_windows(WINDOW_EEPROM);
         continue;
         }
      switch (ch)
         {
         case UPARROW:
            if (window_data[WINDOW_EEPROM].startnum)
               {
               window_data[WINDOW_EEPROM].startnum -= 0x10;
               window_data[WINDOW_EEPROM].endnum -= 0x10;
               }
            break;
         case DNARROW:
            if (window_data[WINDOW_EEPROM].endnum < EEPROM_SIZE-1)
               {
               window_data[WINDOW_EEPROM].startnum += 0x10;
               window_data[WINDOW_EEPROM].endnum += 0x10;
               }
            break;
         case PGUP:
            if (window_data[WINDOW_EEPROM].startnum > numeeprom)
               window_data[WINDOW_EEPROM].startnum -= numeeprom;
            else
               window_data[WINDOW_EEPROM].startnum = 0;
            window_data[WINDOW_EEPROM].endnum =
                        window_data[WINDOW_EEPROM].startnum + numeeprom - 1;
            break;
         case PGDN:
            window_data[WINDOW_EEPROM].endnum =
               MIN(EEPROM_SIZE-1,window_data[WINDOW_EEPROM].endnum+numeeprom);
            window_data[WINDOW_EEPROM].startnum =
                        window_data[WINDOW_EEPROM].endnum - numeeprom + 1;
            break;
         case HOME:
            window_data[WINDOW_EEPROM].startnum = 0;
            window_data[WINDOW_EEPROM].endnum = numeeprom - 1;
            break;
         case END:
            window_data[WINDOW_EEPROM].endnum = EEPROM_SIZE - 1;
            window_data[WINDOW_EEPROM].startnum =
                        window_data[WINDOW_EEPROM].endnum - numeeprom + 1;
            break;
         }
      } while (ch != CTRL_TAB);
   draw_bar(WINDOW_EEPROM,VIDEO_NORMAL);
   update_eeprom(VIDEO_NORMAL);
#endif  /* EEPROM_SIZE */
   }

void scroll_where()
   {
   WORD ch;
   WORD wsize;

   wsize = WHERE_SIZE;
   if ((!total_ic[1]) && (total_ic[0] < WHERE_SIZE))
      wsize = total_ic[0];
   draw_bar(WINDOW_WHERE,VIDEO_HIGHLIGHT);
   do
      {
      update_where(VIDEO_HIGHLIGHT);
      if ((ch = getkey()) == F11)  /* get user keypress */
         {
         reset_windows(WINDOW_WHERE);
         continue;
         }
      switch (ch)
         {
         case UPARROW:
            if (window_data[WINDOW_WHERE].startnum < wsize)
               window_data[WINDOW_WHERE].startnum++;
            break;
         case DNARROW:
            if (window_data[WINDOW_WHERE].startnum > window_data[WINDOW_WHERE].numrows)
               window_data[WINDOW_WHERE].startnum--;
            break;
         case PGUP:
            if ((window_data[WINDOW_WHERE].startnum += window_data[WINDOW_WHERE].numrows)
                           >= wsize)
               window_data[WINDOW_WHERE].startnum = wsize;
            break;
         case PGDN:
            if (window_data[WINDOW_WHERE].startnum > (window_data[WINDOW_WHERE].numrows << 1))
               window_data[WINDOW_WHERE].startnum -= window_data[WINDOW_WHERE].numrows;
            else
               window_data[WINDOW_WHERE].startnum = window_data[WINDOW_WHERE].numrows;
            break;
         case HOME:
            window_data[WINDOW_WHERE].startnum = wsize;
            break;
         case END:
            window_data[WINDOW_WHERE].startnum = window_data[WINDOW_WHERE].numrows;
            break;
         }
      } while (ch != CTRL_TAB);
   draw_bar(WINDOW_WHERE,VIDEO_NORMAL);
   update_where(VIDEO_NORMAL);
   }

void scroll_disasm()
   {
   WORD ch;

   draw_bar(WINDOW_DISASM,VIDEO_HIGHLIGHT);
   do
      {
      update_disasm(VIDEO_HIGHLIGHT);
      if ((ch = getkey()) == F11)  /* get user keypress */
         {
         reset_windows(WINDOW_DISASM);
         continue;
         }
      switch (ch)
         {
         case UPARROW:
            if (window_data[WINDOW_DISASM].startnum-- == 0)
               window_data[WINDOW_DISASM].startnum = MEMORY_MASK;
            if (window_data[WINDOW_DISASM].endnum-- == 0)
               window_data[WINDOW_DISASM].endnum = MEMORY_MASK;
            break;
         case DNARROW:
            if (++window_data[WINDOW_DISASM].startnum == MEMORY_SIZE)
               window_data[WINDOW_DISASM].startnum = 0;
            if (++window_data[WINDOW_DISASM].endnum == MEMORY_SIZE)
               window_data[WINDOW_DISASM].endnum = 0;
            break;
         case PGUP:
            if ((window_data[WINDOW_DISASM].startnum -= window_data[WINDOW_DISASM].numrows) > MEMORY_MASK)
               window_data[WINDOW_DISASM].startnum += MEMORY_SIZE;
            if ((window_data[WINDOW_DISASM].endnum -= window_data[WINDOW_DISASM].numrows) > MEMORY_MASK)
               window_data[WINDOW_DISASM].endnum += MEMORY_SIZE;
            break;
         case PGDN:
            if ((window_data[WINDOW_DISASM].startnum += window_data[WINDOW_DISASM].numrows) > MEMORY_MASK)
               window_data[WINDOW_DISASM].startnum -= MEMORY_SIZE;
            if ((window_data[WINDOW_DISASM].endnum += window_data[WINDOW_DISASM].numrows) > MEMORY_MASK)
               window_data[WINDOW_DISASM].endnum -= MEMORY_SIZE;
            break;
         case HOME:
            window_data[WINDOW_DISASM].startnum = 0;
            window_data[WINDOW_DISASM].endnum = window_data[WINDOW_DISASM].numrows - 1;
            break;
         case END:
            window_data[WINDOW_DISASM].startnum = MEMORY_SIZE - window_data[WINDOW_DISASM].numrows;
            window_data[WINDOW_DISASM].endnum = MEMORY_MASK;
            break;
         }
      } while (ch != CTRL_TAB);
   draw_bar(WINDOW_DISASM,VIDEO_NORMAL);
   update_disasm(VIDEO_NORMAL);
   }

init_windows()
   {
   WORD i;

   bytesperline = 160;
   if (!(vgamode | vesamode))  /* if neither */
      {
      memfill(window_data,sizeof(window_data),0);  /* windows are not available */
      window_data[WINDOW_COMMAND].numrows = 25;  /* we'll need this one */
      window_data[WINDOW_COMMAND].numcols = 80;  /* we'll need this one */
      window_data[WINDOW_WATCH].startrow = SCREEN_ROWS - 3 - MAX_OSCOPE_LINES;  /* after port screen */
      window_data[WINDOW_PORTS].startrow = SCREEN_ROWS - NUM_BYTE_PORTS - NUM_BYTE_PORTS - 3 - MAX_OSCOPE_LINES;
                    /* -3 for rows in WATCH */
                    /* 2nd -NUM_BYTE_PORTS for the analog values beneath the port display */
      window_data[WINDOW_PORTS].startcol = 6;
      vgamode = FALSE;
      vesamode = FALSE;
      return;
      }
   if (vesamode)
      {
#asm
   mov  ax,4f02h     ;fn = set SuperVGA mode
   mov  bx,010bh     ;mode = 132 x 50 text
   int  10h          ;call BIOS
#endasm
      bytesperline = 264;  /* 132 * 2 */
      for (i = 0; i < 50; i++)
         window_char(i,80,VERT_BAR|VIDEO_NORMAL);
      vgamode = FALSE;
      oscope_maxwidth = MAX_SCREEN_WIDTH - 4;  /* -3 for "<port><bitnum> ",
                                                * -1 for trailing space in
                                                * disassembly window
                                                */
      }
   else  /* do VGA mode, 80x50 */
      {
#asm
   mov  ax,1202h    ;fn = alternate function selection, 400 lines/screen
   mov  bl,30h      ;alternate function = select vertical resolution
   int  10h         ;call BIOS
   mov  ax,0003h    ;fn = set video mode, 80x25 text @ 400 lines/screen
   int  10h         ;call BIOS
   mov  ax,1112h    ;TEXT-MODE CHARGEN - LOAD ROM 8x8 DBL-DOT PATTERNS
                    ;NOTE: 400 lines / 8lines/char = 50 rows of text
   mov  bl,0        ;block to load: 0
   int  10h         ;call BIOS
#endasm
      MEMMOVE(vga_data,window_data,sizeof(window_data));
      vesamode = FALSE;
      }
   for (i = 0; i < NUM_WINDOWS; i++)
      draw_bar(i,VIDEO_NORMAL);
   draw_bar(WINDOW_COMMAND,VIDEO_HIGHLIGHT);
   window_data[WINDOW_PORTS].startrow++;  /* we need to fake some stuff out */
/* #ifdef PICTYPE_12C509A */
   window_data[WINDOW_PORTS].startcol += 6;
/* #endif */
   if (vesamode)
      window_data[WINDOW_DISASM].startnum = (ip - 5) & MEMORY_MASK;
   else
      window_data[WINDOW_DISASM].startnum = ip;
   windowmode = vesamode | vgamode;  /* set this to TRUE */
   }

reset_windows(which)
   WORD which;
   {
   WORD i;

   cmdwindow_row = 0;
   cmdwindow_col = 0;
   if (!windowmode)
      {
#asm
   mov  ax,0003h          ;fn = set mode, 80x25 text
   int  10h               ;call BIOS
#endasm
      return;
      }
   if (vesamode)
      {
#asm
   mov  ax,4f02h     ;fn = set SuperVGA mode
   mov  bx,010bh     ;mode = 132 x 50 text
   int  10h          ;call BIOS
#endasm
      for (i = 0; i < 50; i++)
         window_char(i,80,VERT_BAR|VIDEO_NORMAL);
      }
   if (vgamode)
      {
#asm
   mov  ax,1202h    ;fn = alternate function selection, 400 lines/screen
   mov  bl,30h      ;alternate function = select vertical resolution
   int  10h         ;call BIOS
   mov  ax,0003h    ;fn = set video mode, 80x25 text @ 400 lines/screen
   int  10h         ;call BIOS
   mov  ax,1112h    ;TEXT-MODE CHARGEN - LOAD ROM 8x8 DBL-DOT PATTERNS
                    ;NOTE: 400 lines / 8lines/char = 50 rows of text
   mov  bl,0        ;block to load: 0
   int  10h         ;call BIOS
#endasm
      }
   window_data[WINDOW_PORTS].startrow--;  /* we need to fake some stuff out */
   window_data[WINDOW_PORTS].startcol -= 6;
   for (i = 0; i < NUM_WINDOWS; i++)
      draw_bar(i,VIDEO_NORMAL);
   window_data[WINDOW_PORTS].startrow++;  /* we need to fake some stuff out */
   window_data[WINDOW_PORTS].startcol += 6;
   draw_bar(which,VIDEO_HIGHLIGHT);
   for (i = 0; i < NUM_BYTE_PORTS; i++)
      lasttris[i] ^= 0xff;  /* reset all bits, force display of all ports */
   update_windows();
   }

/*
 *  Need to start moving some cmd_xxx() code to pshell2, pshell is getting
 *  too big!
 */
WORD picfile_write(fout,addr,size,name)
   int fout;    /* output file */
   BYTE *addr;  /* address to write from */
   WORD size;   /* # of bytes to write */
   BYTE *name;  /* name to delete on error */
   {
   if (write(fout,addr,size) != size)
      {
      close(fout);
      unlink(name);  /* don't keep bad files around */
      PUTS(cannot_write_str);
      return(FALSE);
      }
   return(TRUE);
   }

void cmd_save(whichcmd)  /* save current state in a PIM file */
   WORD whichcmd;
   {
   int fout;  /* temporary handle */
   WORD temp;

   if (!parse(tempstr))
      {
      cmdline_error(name_str);
      return;
      }
   if ((fout = open(tempstr,0)) != -1)
      {
      close(fout);
      PUTS(tempstr);
      getstr(" already exists. Overwrite it (Y/N)? ",cmdline);
      cmdptr = 0;  /* init cmdline ptr */
      skip_cmd_spaces();
      if (toupper(cmdline[cmdptr]) != 'Y')
         return;
      }
   if ((fout = creat(tempstr)) == -1)
      {
      PUTS("unable to create ");
      PUTS(tempstr);
      PUTS(nl_str);
      return;
      }
   memfill(&picfile_hdr,sizeof(picfile_hdr),0);  /* erase this */
   strcpy(picfile_hdr.program_id,picemu_str);  /* identify file owner */
   strcpy(picfile_hdr.pictype,processor);   /* set processor type */
   picfile_hdr.filetype = FILETYPE_PIM;  /* Pic IMage */
   picfile_hdr.memsize = MEMORY_SIZE;
   picfile_hdr.version = PICFILE_VERSION;
   picfile_hdr.numregs = NUM_REGS;
#ifdef EEPROM_SIZE
   picfile_hdr.numeeprom = EEPROM_SIZE;
#endif  /* EEPROM_SIZE */
   picfile_hdr.w_reg = w;
   picfile_hdr.ip_reg = ip;
   picfile_hdr.stackptr = stack_ptr;
   picfile_hdr.stackdepth = stack_depth;
   picfile_hdr.maxstackd = max_stack_depth;
   for (temp = 0; temp < MAX_STACK_SIZE; temp++)
      picfile_hdr.stk[temp] = stack[temp];
#ifdef CORE_12BIT
   picfile_hdr.tris = regs[TRISA];
   picfile_hdr.option = regs[OPTION];
#endif  /* CORE_12BIT */
   picfile_hdr.config = configuration;
   picfile_hdr.scr_row = screen_rowofs;
   picfile_hdr.scr_col = screen_colofs;
   if (!picfile_write(fout,&picfile_hdr,sizeof(picfile_hdr),tempstr))
      return;
   if (!picfile_write(fout,memory,MEMORY_SIZE << 1,tempstr))
      return;
   if (!picfile_write(fout,regs,NUM_REGS,tempstr))
      return;
#ifdef EEPROM_SIZE
   if (!picfile_write(fout,eeprom,EEPROM_SIZE,tempstr))
      return;
#endif  /* EEPROM_SIZE */
   if (!picfile_write(fout,uart_screen,SCREEN_ROWS * SCREEN_COLS * 2,tempstr))
      return;
   if (close(fout) == -1)  /* if bad write of buffered output */
      {
      unlink(tempstr);  /* don't keep bad files around */
      PUTS(cannot_write_str);
      }
   }

update_config_params()
   {
   WORD save_show_ports;

#ifdef PICTYPE_16F648
   port_masks[0] = (port_masks[0] & 0x3f)
         | p648_fosc_trisabits[((configuration & CONFIG_FOSC2) >> CONFIG_FOSC2_SHIFT) + (configuration & CONFIG_FOSC_MASK)];
             /* account for I/O pin useage of oscillator configuration */
   if (configuration & CONFIG_LVP)
      port_masks[1] &= NOT_BIT4;  /* LVP set, B4 is PGM not I/O */
   else
      port_masks[1] |= BIT4;  /* LVP not set, B4 is I/O */
#endif  /* PICTYPE_16F648 */
#ifdef PICTYPE_12F675
   port_masks[0] = (port_masks[0] & 0x0f)
         | p675_fosc_trisabits[configuration & CONFIG_FOSC_MASK];
             /* account for I/O pin useage of oscillator configuration */
#endif  /* PICTYPE_12F675 */
#ifdef PICTYPE_12C509A
   port_masks[0] = p509a_fosc_trisabits[configuration & 0x03];
   if (configuration & CONFIG_MCLRE)  /* flag: MCLR enabled */
      wakemask = WAKEPINS_NO_GP3;  /* turn off GP3 to wake on pin change */
   else
      wakemask = WAKEPINS;  /* GP3 included in wake on pin change */
#endif  /* PICTYPE_12C509A */
   watchdog_enabled = configuration & CONFIG_WDTE;  /* flag: watchdog enabled */
   save_show_ports = show_ports;
   show_ports = FALSE;
   io_processing();
   show_ports = save_show_ports;
   }

void cmd_config(whichcmd)
   WORD whichcmd;
   {
   WORD temp;

   if (!cmdline[cmdptr])
      {
      sprintf(tempstr,"Configuration word:  %04x\n",configuration);
      PUTS(tempstr);
      return;
      }
   if (!get_word(&temp))
      {
      cmdline_error(value_str);
      return;
      }
   configuration = temp & CONFIG_MASK;
   update_config_params();  /* update I/O pin usage, etc */
   }

#ifdef CORE_12BIT
void cmd_tris(whichcmd)
   WORD whichcmd;
   {
   WORD temp;

   if (!cmdline[cmdptr])
      {
      sprintf(tempstr,"TRIS:  %02x\n",regs[TRISA]);
      PUTS(tempstr);
      return;
      }
   if ((!get_word(&temp)) || (temp > 0x3f))
      {
      cmdline_error(value_str);
      return;
      }
   regs[TRISA] = temp;
   }

void cmd_option(whichcmd)
   WORD whichcmd;
   {
   WORD temp;

   if (!cmdline[cmdptr])
      {
      sprintf(tempstr,"Option reg:  %02x\n",regs[OPTION]);
      PUTS(tempstr);
      return;
      }
   if (!get_word(&temp))
      {
      cmdline_error(value_str);
      return;
      }
   regs[OPTION] = temp;
   }
#endif  /* CORE_12BIT */

void cmd_symbols(whichcmd)
   WORD whichcmd;
   {
   WORD i, j, ch;
   WORD linecount, numlines;

   if (!numsymbols)
      {
      PUTS("no symbols\n");
      return;
      }
   linecount = 0;
   numlines = 0;
   for (i = 0; i < numsymbols; i++)
      {
      for (j = 0; j < SYMBOL_SIZE; j++)
         {
         ch = peekw(symboladdr,i*SYMTAB_ENTRY_SIZE+j)&0xff;
         tempstr[j] = isprint(ch) ? ch : ' ';
         }
      sprintf(&tempstr[SYMBOL_SIZE],"%04x       ",
               peekw(symboladdr,i*SYMTAB_ENTRY_SIZE+SYMTAB_VALUE_OFS));
      PUTS(tempstr);
      if (++linecount == 3)
         {
         PUTS(nl_str);
         linecount = 0;
         if ((++numlines == SCREEN_ROWS-1)
                  && (i != numsymbols-1)
                  && (!cmdline[cmdptr]))
            {
            PUTS(press_any);
            ci();
            PUTS(nl_str);
            numlines = 0;
            }
         }
      }
   if (linecount)
      PUTS(nl_str);
   }

void cmd_i2c(whichcmd)
   WORD whichcmd;
   {
   WORD size, i, flag, linecount, bytecount, addr, ch;

   if (!i2c_seg)
      {
      PUTS("no memory for I2C storage\n");
      return;
      }
   if ((!cmdline[cmdptr])  /* show I2C configuration */
                 || (strcmpi(&cmdline[cmdptr],"dump") == 0))
      {
      if (!i2c_type)
         {
         PUTS("no I2C setup\n");
         return;
         }
      if (i2c_type == I2C_TYPE_128BIT)
         size = 0;
      else
         size = 1;
      for (i = 2; i < i2c_type; i++)
         size <<= 1;
#ifdef PINS_8
      sprintf(tempstr,"24xx%02d SCL:GP%d SDA:GP%d\n",
              size,scl_pin,sda_pin);
#else
      sprintf(tempstr,"24xx%02d SCL:%c%d SDA:%c%d\n",
              size,scl_port+'A',scl_pin,sda_port+'A',sda_pin);
#endif  /* PINS_8 */
      PUTS(tempstr);
      if (!cmdline[cmdptr])  /* if not DUMP */
         return;
      fromhexstr[0] =
      fromhexstr[1] = ' ';
      fromhexstr[18] = '\n';
      fromhexstr[19] = '\0';  /* non-changing string elements */
      for (linecount = 0, size = 0; size < i2c_addr_mask; size += 16)
         {
         sprintf(tempstr,"%04x  ",size);
         PUTS(tempstr);
         for (i = 0; i < 16; i++)
            {
            sprintf(tempstr,"%02x ",ch = peekb(i2c_seg,size+i));
            PUTS(tempstr);
            if ((ch >= ' ') && (ch <= '~'))
               fromhexstr[i+2] = ch;
            else
               fromhexstr[i+2] = ' ';
            }
         PUTS(fromhexstr);
         if ((!outputfile) && (++linecount == SCREEN_ROWS-2))
            {
            PUTS(press_any_esc);
            flag = ci();
            PUTS(nl_str);
            if (flag == ESC)
               return;
            linecount = 0;
            }
         else
            if (csts())
               if (ci() == ESC)
                  return;
         }
      return;
      }
   i2c_type = 0;  /* no I2C */
   if (strcmpi(&cmdline[cmdptr],off_str) == 0)  /* if we're turning it off */
      return;
   flag = FALSE;
   if ((cmdline[cmdptr++] != '2') || (cmdline[cmdptr++] != '4')
                  || (!parse(tempstr)))
      flag = TRUE;  /* flag bad size */
   sscanf(tempstr,"%d",&size);
   if ((flag) || (size > 256) || (size & (size-1)))
      {
      cmdline_error(syntax_str);
      return;
      }
   if (!valid_pin(&scl_port,&scl_pin,FALSE))
      return;
   if (!valid_pin(&sda_port,&sda_pin,FALSE))
      return;
   if ((scl_port == sda_port) && (scl_pin == sda_pin))
      {
      cmdline_error(syntax_str);
      return;
      }
   i2c_type = I2C_TYPE_128BIT;
   if (size)  /* if not 24xx00 */
      {
      for (i2c_type++, i = 1; !(size & i); i2c_type++, i <<= 1)
         ;
      }
   i2c_hdr_size = i2c_params[i2c_type].hdr_size;
   i2c_page_mask = i2c_params[i2c_type].page_mask;
   i2c_addr_mask = i2c_params[i2c_type].addr_mask;
   i2c_page_max = i2c_hdr_size + 1;
   if (size)  /* if not 24xx00 */
      i2c_page_max += i2c_page_mask;
   i2c_address = 0;  /* important:  if changing I2C size, make sure this is valid! */
   sda_pinmask = bittable[sda_pin];
   scl_pinmask = bittable[scl_pin];
   last_sda = regs[PORTA + sda_port] & sda_pinmask;
   last_sda_tris = regs[TRISA + sda_port] & sda_pinmask;
   last_scl = regs[PORTA + scl_port] & scl_pinmask;
   for (size = 0; size <= i2c_addr_mask; size++)
      pokeb(i2c_seg,size,0xff);
   if (!parse(tempstr))  /* if no hex file given */
      return;
   if ((filein = open(tempstr,0)) == -1)
      {
      PUTS(tempstr);
      PUTS(" not found\n");
      return;
      }
   linecount = 0;
   while (fgets(tempstr,126,filein))
         /*
          *  WARNING: I'm taking advantage of a DeSmet C "quirk" here.  I've
          *           used open() instead of fopen() on the file, but I'm
          *           calling fgets().  DeSmet does not distinguish between
          *           the types of file handles, and so this works.  This
          *           makes porting harder, however.
          */
      {
      if (!valid_hexline(++linecount,tempstr))
         break;
      bytecount = hexbytevalue(&tempstr[1]);
      addr = hexwordvalue(&tempstr[3]);
      for (i = 9; i < bytecount+bytecount+9; i += 2, addr++)
         if (addr <= i2c_addr_mask)
            pokeb(i2c_seg,addr,hexbytevalue(&tempstr[i]));
      }
   close(filein);
   }

#ifdef USE_ADDRLIST
cmd_addrlist(which)
   WORD which;
   {
   WORD i, has_space;
   WORD progaddr, dataaddr;

   if (!addrlist_seg)
      {
      PUTS("no memory for valid address list storage\n");
      return;
      }
   if (!cmdline[cmdptr])
      {
      cmdline_error(syntax_str);
      return;
      }
   if (!strcmpi(&cmdline[cmdptr],off_str))  /* if we're turning it off */
      {
      have_addrlist = FALSE;
      return;
      }
   if ((filein = open(&cmdline[cmdptr],0)) == -1)
      {
      PUTS("file not found\n");
      return;
      }
   have_addrlist = FALSE;
   for (i = 0; i < MEMORY_SIZE*2; i += 2)
      pokew(addrlist_seg,i,0xffff);
   while (fgets(tempstr,126,filein))
         /*
          *  WARNING: I'm taking advantage of a DeSmet C "quirk" here.  I've
          *           used open() instead of fopen() on the file, but I'm
          *           calling fgets().  DeSmet does not distinguish between
          *           the types of file handles, and so this works.  This
          *           makes porting harder, however.
          */
      {
      has_space = FALSE;
      for (i = 0; tempstr[i]; i++)
         {
         if (tempstr[i] == ',')
            tempstr[i] = ' ';  /* standard separator */
         if (tempstr[i] == ' ')
            has_space = TRUE;
         }
      if (!has_space)
         {
         PUTS("Invalid address line\n");
         close(filein);
         return;
         }
      sscanf(tempstr,"%x %x",&progaddr,&dataaddr);
      if (progaddr >= MEMORY_SIZE)
         {
         PUTS("Program address outside of memory\n");
         close(filein);
         return;
         }
      if (peekw(addrlist_seg,progaddr+progaddr) != 0xffff)
         {
         PUTS("Duplicate program address in list\n");
         close(filein);
         return;
         }
      if (dataaddr >= NUM_REGS)
         {
         PUTS("Data address outside of memory\n");
         close(filein);
         return;
         }
      dataaddr = xlate_regs[dataaddr];  /* normalize this address */
      pokew(addrlist_seg,progaddr+progaddr,dataaddr);  /* set valid address */
      }  /* while (fgets(tempstr,126,filein)) */
   close(filein);
   have_addrlist = TRUE;
   }
#endif  /* USE_ADDRLIST */

#ifdef PSHELL_DATAALIGN_1
   static BYTE pshell_dataalign_1 = 0;
#endif  /* PSHELL_DATAALIGN_1 */
#ifdef PSHELL_DATAALIGN_2
   static BYTE pshell_dataalign_2 = 0;
#endif  /* PSHELL_DATAALIGN_2 */
