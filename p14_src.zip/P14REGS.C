#ifdef NEVERDEF
/****************************************************************************
 ****************************************************************************
 *                                                                          *
 *   WARNING!                                                               *
 *                                                                          *
 *   I've discovered a bug in the code optimizer.  A definition like:       *
 *      #define TESTBITS (BIT1|BIT2)                                        *
 *   can produce incorrect code output from the optimizer when TESTBITS     *
 *   is used.                                                               *
 *                                                                          *
 *   Instead, use a definition like:                                        *
 *      #define TESTBITS 0x05  /* (BIT1|BIT2) */                            *
 *   Yes, that's not as "ideal", but it will save a WORLD of problems!      *
 *                                                                          *
 ****************************************************************************
 ****************************************************************************/
#endif

/*
 *  PIC emulator.  16F877 version.
 *  Register access functions
 *
 *
 *  Copyright (c) 2001-2004
 *
 *  Released under the GNU GPL.  See http://www.gnu.org/licenses/gpl.txt
 *
 *  This program is part of PICEMU
 *
 *  PICEMU is free software; you can redistribute it and/or modify it under
 *  the terms of the GNU General Public License as published by the Free
 *  Software Foundatation; either version 2 of the License, or any later
 *  version.
 *
 *  PICEMU is distributed in the hope that it will be useful, but WITHOUT
 *  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 *  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 *  for more details.
 *
 *
 *  Revision history
 *
 *  Date      Comments
 *  --------  ---------------------------------------------
 *  9/xx/01   Original code
 *  11/14/01  Code cleanup for 1st BETA release
 *  11/6/03   All sorts of changes to bring code up to P675 level
 *            (analog inputs, etc).
 *  2/20/04   New commands, add analog inputs
 *  3/15/04   Source code unification for 14-bit core programs.
 */

#include <picemu.h>

extern WORD filenum_temp;
extern WORD filenum_temp2;
#ifdef SELF_FLASH
   extern WORD memory[MEMORY_SIZE];
#endif  /* SELF_FLASH */
extern BYTE regs[NUM_REGS];

#ifdef EEPROM_SIZE
   extern BYTE eeprom[EEPROM_SIZE];
#endif  /* EEPROM_SIZE */

extern BYTE input_ports[NUM_BYTE_PORTS_ALLOCATE];
extern WORD analog_ports[NUM_BYTE_PORTS][8];
extern BYTE regval;
extern WORD ip;  /* for write to PCL reg */
extern WORD do_mclr_reset;   /* do a MCLR reset */
extern WORD last_t0cki;    /* for T0CKI edge detection */
extern WORD tmr0_inhibit;  /* if write to TMR0, inhibit TIMER0 update for
                              2 instruction cycles */
extern WORD tmr0_prescale;
extern WORD tmr0_prescale_counter;  /* TMR0 / watchdog prescale counter */
#ifdef HAS_TMR1
   extern WORD tmr1_prescale;          /* prescale compare value */
   extern WORD tmr1_prescale_counter;  /* reset on write to TMR1L / TMR1H */
   extern WORD tmr1_inhibit;           /* inhibit update of TMR1 */
#endif  /* HAS_TMR1 */
#ifdef HAS_TMR2
   extern WORD tmr2_prescale_counter;  /* reset on write to TMR2 / T2CON */
   extern WORD tmr2_postscale_counter; /* reset on write to TMR2 / T2CON */
   extern WORD tmr2_inhibit;           /* inhibit update of TIMER2 */
   extern WORD tmr2_prescale;
   extern WORD tmr2_prescale_pwm_bitshift;
   extern WORD tmr2_prescale_table[4];
   extern WORD tmr2_prescale_pwm_table[4];
#endif  /* HAS_TMR2 */
#ifdef HAS_CMCON
   extern BYTE last_cout;  /* for comparitor interrupt */
#endif  /* HAS_CMCON */
extern BYTE last_porta_in; /* for IOC (12F675) */
extern BYTE last_intpin;   /* for interrupt on rising/falling signal on INT pin */
#ifdef HAS_PORTB
   extern BYTE last_portb;    /* for port change interrupt */
   extern BYTE last_portb_in; /* for INT pin detect */
#endif  /* HAS_PORTB */
extern WORD sleepmode;     /* for TIMER 0 in counter mode */

extern WORD configuration; /* see if EEPROM write allowed, etc */

#ifdef HAS_ADC
   extern WORD adc_delay;     /* if set, we're doing an "ADC conversion" */
   extern WORD adc_result;
   extern WORD adc_table[ADC_TABLE_MAXSIZE];
   extern WORD adc_table_size;
   extern WORD adc_table_index;
   #ifdef PICTYPE_16F877
      BYTE adc_porta_masks[ADC_CONFIG_MASK+1] =  /* bits 4, 6, and 7 are always set */
         {                                       /* 7 6 5 4  3 2 1 0 */
         0xd0,  /* 0000: A0 .. A3, A5 are analog    1 1 0 1  0 0 0 0 = 0xd0 */
         0xd0,  /* 0001: A0 .. A3, A5 are analog    1 1 0 1  0 0 0 0 = 0xd0 */
         0xd0,  /* 0010: A0 .. A3, A5 are analog    1 1 0 1  0 0 0 0 = 0xd0 */
         0xd0,  /* 0011: A0 .. A3, A5 are analog    1 1 0 1  0 0 0 0 = 0xd0 */

         0xf4,  /* 0100: A0, A1, and A3 are analog  1 1 1 1  0 1 0 0 = 0xf4 */
         0xf4,  /* 0101: A0, A1, and A3 are analog  1 1 1 1  0 1 0 0 = 0xf4 */
         0xff,  /* 0110: all inputs are digital     1 1 1 1  1 1 1 1 = 0xff */
         0xff,  /* 0111: all inputs are digital     1 1 1 1  1 1 1 1 = 0xff */

         0xd0,  /* 1000: A0 .. A3, A5 are analog    1 1 0 1  0 0 0 0 = 0xd0 */
         0xd0,  /* 1001: A0 .. A3, A5 are analog    1 1 0 1  0 0 0 0 = 0xd0 */
         0xd0,  /* 1010: A0 .. A3, A5 are analog    1 1 0 1  0 0 0 0 = 0xd0 */
         0xd0,  /* 1011: A0 .. A3, A5 are analog    1 1 0 1  0 0 0 0 = 0xd0 */

         0xd0,  /* 1100: A0 .. A3, A5 are analog    1 1 0 1  0 0 0 0 = 0xd0 */
         0xf0,  /* 1101: A0 .. A3 are analog        1 1 1 1  0 0 0 0 = 0xf0 */
         0xfe,  /* 1110: A0 is analog               1 1 1 1  1 1 1 0 = 0xfe */
         0xf2   /* 1111: A0, A2, and A3 are analog  1 1 1 1  0 0 1 0 = 0xf2 */
         };
      BYTE adc_porte_masks[ADC_CONFIG_MASK+1] =  /* bits 3 .. 7 are always set */
         {                                       /* 7 6 5 4  3 2 1 0 */
         0xf8,  /* 0000: E0 .. E2 are analog     1 1 1 1  1 0 0 0 = 0xf8 */
         0xf8,  /* 0001: E0 .. E2 are analog     1 1 1 1  1 0 0 0 = 0xf8 */
         0xff,  /* 0010: port E is all digital   1 1 1 1  1 1 1 1 = 0xff */
         0xff,  /* 0011: port E is all digital   1 1 1 1  1 1 1 1 = 0xff */

         0xff,  /* 0100: port E is all digital   1 1 1 1  1 1 1 1 = 0xff */
         0xff,  /* 0101: port E is all digital   1 1 1 1  1 1 1 1 = 0xff */
         0xff,  /* 0110: all inputs are digital  1 1 1 1  1 1 1 1 = 0xff */
         0xff,  /* 0111: all inputs are digital  1 1 1 1  1 1 1 1 = 0xff */

         0xf8,  /* 1000: E0 .. E2 are analog     1 1 1 1  1 0 0 0 = 0xf8 */
         0xfe,  /* 1001: E0 is analog            1 1 1 1  1 1 1 0 = 0xfe */
         0xfe,  /* 1010: E0 is analog            1 1 1 1  1 1 1 0 = 0xfe */
         0xfe,  /* 1011: E0 is analog            1 1 1 1  1 1 1 0 = 0xfe */

         0xff,  /* 1100: port E is all digital   1 1 1 1  1 1 1 1 = 0xff */
         0xff,  /* 1101: port E is all digital   1 1 1 1  1 1 1 1 = 0xff */
         0xff,  /* 1110: port E is all digital   1 1 1 1  1 1 1 1 = 0xff */
         0xff   /* 1111: port E is all digital   1 1 1 1  1 1 1 1 = 0xff */
         };
      BYTE adc_ports[8] =
         {
         0,  /* Channel 0, RA0 / AN0 */
         0,  /* Channel 1, RA1 / AN1 */
         0,  /* Channel 2, RA2 / AN2 */
         0,  /* Channel 3, RA3 / AN3 */
         0,  /* Channel 4, RA5 / AN4 */
         4,  /* Channel 5, RE0 / AN5 */
         4,  /* Channel 6, RE1 / AN6 */
         4   /* Channel 7, RE2 / AN7 */
         };
      BYTE adc_pins[8] =
         {
         0,  /* RA0 */
         1,  /* RA1 */
         2,  /* RA2 */
         3,  /* RA3 */
         5,  /* RA5 */
         0,  /* RE0 */
         1,  /* RE1 */
         2   /* RE2 */
         };
      BYTE vref_high[ADC_CONFIG_MASK+1] =  /* do we need a VREF_PLUS other than Vdd? */
         {       /* PCFG in ADCON1 */
         FALSE,  /* 0000 */
         TRUE,   /* 0001 */
         FALSE,  /* 0010 */
         TRUE,   /* 0011 */
         FALSE,  /* 0100 */
         TRUE,   /* 0101 */
         FALSE,  /* 0110 */
         FALSE,  /* 0111 */
         TRUE,   /* 1000 */
         FALSE,  /* 1001 */
         TRUE,   /* 1010 */
         TRUE,   /* 1011 */
         TRUE,   /* 1100 */
         TRUE,   /* 1101 */
         FALSE,  /* 1110 */
         TRUE    /* 1111 */
         };
      BYTE vref_low[ADC_CONFIG_MASK+1] =  /* do we need a VREF_MINUS other than Gnd? */
         {       /* PCFG in ADCON1 */
         FALSE,  /* 0000 */
         FALSE,  /* 0001 */
         FALSE,  /* 0010 */
         FALSE,  /* 0011 */
         FALSE,  /* 0100 */
         FALSE,  /* 0101 */
         FALSE,  /* 0110 */
         FALSE,  /* 0111 */
         TRUE,   /* 1000 */
         FALSE,  /* 1001 */
         FALSE   /* 1010 */
         TRUE,   /* 1011 */
         TRUE,   /* 1100 */
         TRUE,   /* 1101 */
         FALSE,  /* 1110 */
         TRUE    /* 1111 */
         };
   #endif  /* PICTYPE_16F877 */
   #ifdef PICTYPE_12F675
      BYTE adc_porta_masks[ADC_CONFIG_MASK+1] =  /* indexed by ANSEL & ADC_CONFIG_MASK */
         {                                       /* 7 6 5 4  3 2 1 0 */
         0x3f,  /* 0000: A0 .. A2, A4 are digital   . . 1 1  1 1 1 1 = 0x3f */
         0x3e,  /* 0001: A0 analog                  . . 1 1  1 1 1 0 = 0x3e */
         0x3d,  /* 0010: A1 analog                  . . 1 1  1 1 0 1 = 0x3d */
         0x3c,  /* 0011: A0, A1 analog              . . 1 1  1 1 0 0 = 0x3c */

         0x3b,  /* 0100: A2 analog                  . . 1 1  1 0 1 1 = 0x3b */
         0x3a,  /* 0101: A0, A2 analog              . . 1 1  1 0 1 0 = 0x3a */
         0x39,  /* 0110: A1, A2 analog              . . 1 1  1 0 0 1 = 0x39 */
         0x38,  /* 0111: A0 .. A2 analog            . . 1 1  1 0 0 0 = 0x38 */

         0x2f,  /* 1000: A4 analog                  . . 1 0  1 1 1 1 = 0x2f */
         0x2e,  /* 1001: A0, A4 analog              . . 1 0  1 1 1 0 = 0x2e */
         0x2d,  /* 1010: A1, A4 analog              . . 1 0  1 1 0 1 = 0x2d */
         0x2c,  /* 1011: A0, A1, A4 analog          . . 1 0  1 1 0 0 = 0x2c */

         0x2b,  /* 1100: A2, A4 analog              . . 1 0  1 0 1 1 = 0x2b */
         0x2a,  /* 1101: A0, A2, A4 analog          . . 1 0  1 0 1 0 = 0x2a */
         0x29,  /* 1110: A1, A2, A4 analog          . . 1 0  1 0 0 1 = 0x29 */
         0x28   /* 1111: A0 .. A2, A4 analog        . . 1 0  1 0 0 0 = 0x28 */
         };
      WORD adc_delay_table[8] =
         {
           6,  /* Tinstr/2 * 11 = 5.5 * Tinstr, round up to 6 */
          22,  /* Tinstr * 2 * 11 */
          88,  /* Tinstr * 8 * 11 */
          88,  /* internal RC, never used */
          88,  /* internal RC, never used */
          11,  /* Tinstr * 1 * 11 */
          44,  /* Tinstr * 4 * 11 */
         176   /* Tinstr * 16* 11 */
         };
      BYTE adc_pins[4] =
         {
         0,
         1,
         2,
         4
         };
   #endif  /* PICTYPE_12F675 */
#endif  /* HAS_ADC */

#ifdef HAS_CMCON
   #ifdef PICTYPE_16F648
      BYTE cmcon_porta_masks[CMCON_CONFIG_MASK+1] =
         {
         0xf0,  /* 000: reset          A0 .. A3 are analog  1 1 1 1  0 0 0 0 = 0xf0 */
         0xf0,  /* 001: 3in -> 2cmps   A0 .. A3 are analog  1 1 1 1  0 0 0 0 = 0xf0 */
         0xf0,  /* 010: 4in -> 2cmps   A0 .. A3 are analog  1 1 1 1  0 0 0 0 = 0xf0 */
         0xf8,  /* 011: 2 com ref cmps A0 .. A2 are analog  1 1 1 1  1 0 0 0 = 0xf8 */
         0xf0,  /* 100: 2 indep cmps   A0 .. A3 are analog  1 1 1 1  0 0 0 0 = 0xf0 */
         0xf9,  /* 101: 1 indep cmp    A1 .. A2 are analog  1 1 1 1  1 0 0 1 = 0xf9 */
         0xf8,  /* 110: 2 com ref cmps A0 .. A2 are analog  1 1 1 1  1 0 0 0 = 0xf8 */
         0xff   /* 111: comps off      no analog pins       1 1 1 1  1 1 1 1 = 0xff */
         };
      BYTE cmcon_porta_outputs[CMCON_CONFIG_MASK+1] =
         {
         0x00,  /* 000: reset          no outputs           0 0 0 0  0 0 0 0 = 0x00 */
         0x00,  /* 001: 3in -> 2cmps   no outputs           0 0 0 0  0 0 0 0 = 0x00 */
         0x00,  /* 010: 4in -> 2cmps   no outputs           0 0 0 0  0 0 0 0 = 0x00 */
         0x00,  /* 011: 2 com ref cmps no outputs           0 0 0 0  0 0 0 0 = 0x00 */
         0x00,  /* 100: 2 indep cmps   no outputs           0 0 0 0  0 0 0 0 = 0x00 */
         0x00,  /* 101: 1 indep cmp    no outputs           0 0 0 0  0 0 0 0 = 0x00 */
         0x18,  /* 110: 2 com ref cmps RA3, RA4 are outputs 0 0 0 1  1 0 0 0 = 0x0c */
         0x00   /* 111: comps off      no outputs           0 0 0 0  0 0 0 0 = 0x00 */
         };
      BYTE cmcon_porta_whichcout[8] =  /* indexed by bitnum in io_processing() */
         {
         0,     /* RA0 */
         0,     /* RA1 */
         0,     /* RA2 */
         C1OUT, /* RA3 */
         C2OUT, /* RA4 */
         0,     /* RA5 */
         0,     /* RA6 */
         0      /* RA7 */
         };
   #endif  /* PICTYPE_16F648 */
   #ifdef PICTYPE_12F675
      BYTE cmcon_porta_masks[CMCON_CONFIG_MASK+1] =
         {
         0x3c,  /* 000: reset          A0 .. A1 are analog  . . 1 1  1 1 0 0 = 0x3c */
         0x3c,  /* 001: cmp w/ output  A0 .. A1 are analog  . . 1 1  1 1 0 0 = 0x3c */
         0x3c,  /* 010: cmp w/o output A0 .. A1 are analog  . . 1 1  1 1 0 0 = 0x3c */
         0x3e,  /* 011: cmp w/int ref  A0 analog            . . 1 1  1 1 1 0 = 0x3e */
         0x3e,  /* 100: cmp w/int ref  A0 analog            . . 1 1  1 1 1 0 = 0x3e */
         0x3c,  /* 101: cmp w/mplx inp A0 .. A1 are analog  . . 1 1  1 1 0 0 = 0x3c */
         0x3c,  /* 110: cmp w/mplx inp A0 .. A1 are analog  . . 1 1  1 1 0 0 = 0x3c */
         0x3f   /* 111: cmp off        no analog pins       . . 1 1  1 1 1 1 = 0x3f */
         };
      BYTE cmcon_porta_outputs[CMCON_CONFIG_MASK+1] =
         {
         0x00,  /* 000: reset          no outputs           . . 0 0  0 0 0 0 = 0x00 */
         0x04,  /* 001: cmp w/ output  GP2 is output        . . 0 0  0 1 0 0 = 0x04 */
         0x00,  /* 010: cmp w/o output no outputs           . . 0 0  0 0 0 0 = 0x00 */
         0x04,  /* 011: cmp w/int ref  GP2 is output        . . 0 0  0 1 0 0 = 0x04 */
         0x00,  /* 100: cmp w/int ref  no outputs           . . 0 0  0 0 0 0 = 0x00 */
         0x04,  /* 101: cmp w/mplx inp GP2 is output        . . 0 0  0 1 0 0 = 0x04 */
         0x00,  /* 110: cmp w/mplx inp no outputs           . . 0 0  0 0 0 0 = 0x00 */
         0x00   /* 111: cmp off        no outputs           . . 0 0  0 0 0 0 = 0x00 */
         };
      BYTE cmcon_porta_whichcout[8] =  /* indexed by bitnum in io_processing() */
         {
         0,     /* GP0 */
         C1OUT, /* GP1 */
         0,     /* GP2 */
         0,     /* GP3 */
         0,     /* GP4 */
         0,     /* GP5 */
         0,     /* placeholder */
         0      /* placeholder */
         };
   #endif  /* PICTYPE_12F675 */
#endif  /* HAS_CMCON */

#ifdef HAS_CCP
   extern BYTE last_ccp1;     /* for CCP1 edge detection */
   extern BYTE ccp1_count;    /* for CCP1 4th rising edge / 16th rising edge detection */
   #ifdef HAS_CCP2
      extern BYTE last_ccp2;     /* for CCP2 edge detection */
      extern BYTE ccp2_count;    /* for CCP2 4th rising edge / 16th rising edge detection */
   #endif  /* HAS_CCP2 */
#endif  /* HAS_CCP */

#ifdef HAS_TMR1
   extern BYTE last_t1cki;    /* for T1CKI edge detection */
   extern BYTE t1cki_edge;    /* flag: need a falling edge befor counting rising edge */
   extern BYTE last_t1osi;    /* for T1OSI edge detection */
   extern BYTE t1osi_edge;    /* flag: need a falling edge before counting rising edge */
#endif  /* HAS_TMR1 */

#ifdef HAS_CCP
   extern WORD ccp1_mode;
   extern WORD ccp1_fn;
   extern WORD ccp1_dutycycle;
   #ifdef HAS_CCP2
      extern WORD ccp2_mode;
      extern WORD ccp2_fn;
      extern WORD ccp2_dutycycle;
   #endif  /* HAS_CCP2 */
   BYTE ccp_prescale_table[8] =
      {
       1,   /* 0:  invalid index */
       1,   /* 1:  invalid index */
       1,   /* 2:  invalid index */
       1,   /* 3:  invalid index */
       1,   /* 4:  on falling edge */
       1,   /* 5:  on rising edge */
       4,   /* 6:  every 4th rising edge */
      16    /* 7:  every 16th rising edge */
      };
#endif  /* HAS_CCP */

#ifdef HAS_VRCON
   extern WORD cvref;  /* Compare Voltage Reference */
#endif  /* HAS_VRCON */

#ifdef HAS_CP_BITS
   WORD cp_minaddr[4] =
      {
      CP00_MIN,
      CP01_MIN,
      CP10_MIN,
      CP11_MIN
      };

   WORD cp_maxaddr[4] =
      {
      CP00_MAX,
      CP01_MAX,
      CP10_MAX,
      CP11_MAX
      };
#endif  /* HAS_CP_BITS */

#ifdef EEPROM_SIZE
   /*
    *  Note:  The timing represented by eecon2_state/eecon2_ready is:
    *       <...set BANK bits...>
    *       MOVLW 55   ;need this instr
    *       MOVWF 0D   ;set EECON2, eecon2_state = 3
    *                  ;interpreter loop post-processing, eecon2_state = 2
    *       MOVLW AA   ;need this instr
    *                  ;interpreter loop post-processing, eecon2_state = 1
    *       MOVWF 0D   ;set EECON2, eecon2_ready = 2
    *                  ;interpreter loop post-processing, eecon2_ready = 1
    *       BSF   0C,1 ;start write
    *
    *  Also note, however, that any equivalent sequence of instructions will
    *  also work.  i.e.
    *       <...set BANK bits...>
    *       MOVLW 8D   ;pointer to EECON2
    *       MOVWF 4    ;set FSR
    *       BSF   3,7  ;set IRP so that IRP:FSR --> EECON2
    *       MOVLW 55   ;or any instruction(s) that gives you a 55 in W
    *       MOVWF 0    ;move 55 to EECON2 via INDF
    *                  ;set EECON2, eecon2_state = 3
    *                  ;interpreter loop post-processing, eecon2_state = 2
    *       XORLW FF   ;get an AA
    *                  ;interpreter loop post-processing, eecon2_state = 1
    *       MOVWF 0    ;move AA to EECON2 via INDF
    *                  ;set EECON2, eecon2_ready = 2
    *                  ;interpreter loop post-processing, eecon2_ready = 1
    *       BSF   0C,1 ;start write
    *
    */
   extern WORD eecon2_state;  /* state of write(s) to EECON2 reg */
   extern WORD eecon2_ready;
   extern WORD eeprom_delay;  /* wait of 4ms before EEPROM write is done */
#endif  /* EEPROM_SIZE */

extern WORD bittable[8];   /* bit mask, indexed by bit number */

extern WORD timingcount;
extern DWORD frequency;  /* CPU frequency (use for USART and ADC and EEPROM write) */

#ifdef HAS_UART
   extern WORD commbase;  /* I/O portbase of COMM port */
   extern WORD commport;  /* 0 = SCREEN/KEYBOARD, else COMM port */
   extern DWORD baudrate;

   extern WORD tsr_hold;          /* buffer TX output */
   extern WORD tsr_hold_available; /* data is available in tsr_hold */
   extern WORD trmt_hold_delay_count;  /* instruction cycles need to TX a byte */
   extern WORD trmt_hold_delay;   /* delay counter for TX output */
   extern WORD tsr_hold_delay;    /* instruction cycles before sending TRMT to send_byte() */

   extern WORD tx_data_available;  /* TXREG has fresh data */
   extern WORD tx_port_available;  /* TXREG ready to receive data */
   extern WORD rc_data_available;  /* RCREG has fresh data */
   extern WORD tx_int_delay;
   extern WORD tx_int_delay_counter;

   extern BYTE uart_in_queue[UART_QUEUE_SIZE+8];
   extern WORD uart_in_queue_head;
   extern WORD uart_in_queue_tail;
#endif  /* HAS_UART */

extern WORD readusestris;

extern WORD breakpoint;
extern WORD noexecute;
extern WORD num_reg_breakpoints;
extern struct regbreaks reg_breaks[MAX_REG_BREAKS];

extern WORD show_ports;

extern WORD doing_portwrite;
extern WORD doing_portread;

#ifdef USE_ADDRLIST
   extern WORD addrlist_seg;
   extern WORD addrlist;
   extern WORD wherequeue[WHERE_SIZE+1];  /* queue of addresses for where? */
   extern WORD whereptr;  /* pointer into "where was I?" queue */
#endif  /* USE_ADDRLIST */

#ifdef HAS_UART
   #define BAUDTABLE_SIZE 10     /* local for set_baudrate(), can be here */
                                 /* instead of picemu.h */
   DWORD baudtable[BAUDTABLE_SIZE] =
      {
         110,
         300,
        1200,
        2400,
        4800,
        9600,
       19200,
       38400,
       57600,
      115200
      };
#endif  /* HAS_UART */

void code_alignment_2()
   {
#ifdef R_1B
#asm
   nop        ;code alignment
#endasm
#endif  /* R_1B */

#ifdef R_2B
#asm
   nop        ;code alignment
   nop        ;code alignment
#endasm
#endif  /* R_2B */

#ifdef R_4B
#asm
   nop        ;code alignment
   nop        ;code alignment
   nop        ;code alignment
   nop        ;code alignment
#endasm
#endif  /* R_4B */

#ifdef R_8B
#asm
   nop        ;code alignment  1
   nop        ;code alignment  2
   nop        ;code alignment  3
   nop        ;code alignment  4
   nop        ;code alignment  5
   nop        ;code alignment  6
   nop        ;code alignment  7
   nop        ;code alignment  8
#endasm
#endif  /* R_8B */

#ifdef R_16B
#asm
   nop        ;code alignment  1
   nop        ;code alignment  2
   nop        ;code alignment  3
   nop        ;code alignment  4
   nop        ;code alignment  5
   nop        ;code alignment  6
   nop        ;code alignment  7
   nop        ;code alignment  8
   nop        ;code alignment  9
   nop        ;code alignment  10
   nop        ;code alignment  11
   nop        ;code alignment  12
   nop        ;code alignment  13
   nop        ;code alignment  14
   nop        ;code alignment  15
   nop        ;code alignment  16
#endasm
#endif  /* R_16B */

#ifdef R_32B
#asm
   nop        ;code alignment  1
   nop        ;code alignment  2
   nop        ;code alignment  3
   nop        ;code alignment  4
   nop        ;code alignment  5
   nop        ;code alignment  6
   nop        ;code alignment  7
   nop        ;code alignment  8
   nop        ;code alignment  9
   nop        ;code alignment  10
   nop        ;code alignment  11
   nop        ;code alignment  12
   nop        ;code alignment  13
   nop        ;code alignment  14
   nop        ;code alignment  15
   nop        ;code alignment  16
   nop        ;code alignment  17
   nop        ;code alignment  18
   nop        ;code alignment  19
   nop        ;code alignment  20
   nop        ;code alignment  21
   nop        ;code alignment  22
   nop        ;code alignment  23
   nop        ;code alignment  24
   nop        ;code alignment  25
   nop        ;code alignment  26
   nop        ;code alignment  27
   nop        ;code alignment  28
   nop        ;code alignment  29
   nop        ;code alignment  30
   nop        ;code alignment  31
   nop        ;code alignment  32
#endasm
#endif  /* R_32B */
   }

BYTE r_reg()
   {
   return(regs[filenum_temp2]);
   }

BYTE r_none()
   {
   return(0);
   }

#ifdef HAS_ADC
   #ifdef HAS_CMCON
      BYTE r_porta()  /* has_cmcon && has_adc */
         {
         BYTE portval, mask;

#ifdef PICTYPE_12F675
         last_porta_in = input_ports[0];
#endif  /* PICTYPE_12F675 */
         doing_portread = TRUE;  /* mostly for BSF / BCF */
      #ifdef HAS_ANSEL
         portval = input_ports[0]
                       & adc_porta_masks[regs[ANSEL]&ADC_CONFIG_MASK]
                       & cmcon_porta_masks[regs[CMCON]&CMCON_CONFIG_MASK];
      #else
         portval = input_ports[0]
                       & adc_porta_masks[regs[ADCON1]&ADC_CONFIG_MASK]
                       & cmcon_porta_masks[regs[CMCON]&CMCON_CONFIG_MASK];
      #endif  /* HAS_ANSEL .. ELSE */
/*      #ifdef READ_USES_TRIS */
         if (readusestris)
            portval = (portval & regs[TRISA]) | (regs[PORTA] & ~regs[TRISA]);
/*      #endif */  /* READ_USES_TRIS */
         if (mask = cmcon_porta_outputs[regs[CMCON]&CMCON_CONFIG_MASK])
            {
            portval &= ~mask;
            if (regs[CMCON] & C1OUT)
               portval |= mask;
            }
         regs[PORTA] = portval;
         return(portval);
         }  /* has_cmcon && has_adc */
   #else  /* HAS_CMCON */
      BYTE r_porta()  /* has_adc */
         {
#ifdef PICTYPE_12F675
         last_porta_in = input_ports[0];
#endif  /* PICTYPE_12F675 */
         doing_portread = TRUE;  /* mostly for BSF / BCF */
/*      #ifdef READ_USES_TRIS */
         if (readusestris)
            return(regs[PORTA] = ((regs[PORTA] & ~regs[TRISA])
      #ifdef HAS_ANSEL
               | ((input_ports[0] & regs[TRISA]) & adc_porta_masks[regs[ANSEL]&ADC_CONFIG_MASK])));
      #else
               | ((input_ports[0] & regs[TRISA]) & adc_porta_masks[regs[ADCON1]&ADC_CONFIG_MASK])));
      #endif  /* HAS_ANSEL */
/*      #else */  /* READ_USES_TRIS */
         return(regs[PORTA] = (input_ports[0] & adc_porta_masks[regs[ADCON1]&ADC_CONFIG_MASK]));
/*      #endif */  /* READ_USES_TRIS */
         }  /* has_adc */
   #endif  /* HAS_CMCON ... ELSE */
#else  /* HAS_ADC */
   #ifdef HAS_CMCON
      BYTE r_porta()  /* has_cmcon */
         {
         BYTE portval, mask;

#ifdef PICTYPE_12F675
         last_porta_in = input_ports[0];
#endif  /* PICTYPE_12F675 */
         doing_portread = TRUE;  /* mostly for BSF / BCF */
         portval = input_ports[0] & cmcon_porta_masks[regs[CMCON]&CMCON_CONFIG_MASK];
/*      #ifdef READ_USES_TRIS */
         if (readusestris)
            portval = (portval & regs[TRISA]) | (regs[PORTA] & ~regs[TRISA]);
/*      #endif */  /* READ_USES_TRIS */
         if (mask = cmcon_porta_outputs[regs[CMCON]&CMCON_CONFIG_MASK])
            {
            portval &= ~mask;
            if (regs[CMCON] & C1OUT)
               portval |= mask;
            }
         regs[PORTA] = portval;
         return(portval);
         }  /* has_cmcon */
   #else  /* HAS_CMCON */
      BYTE r_porta()  /* neither adc nor cmcon */
         {
#ifdef PICTYPE_12F675
         last_porta_in = input_ports[0];
#endif  /* PICTYPE_12F675 */
         doing_portread = TRUE;  /* mostly for BSF / BCF */
/*      #ifdef READ_USES_TRIS */
         if (readusestris)
            return(regs[PORTA] = ((regs[PORTA] & ~regs[TRISA]) | (input_ports[0] & regs[TRISA])));
/*      #else */  /* READ_USES_TRIS */
         return(regs[PORTA] = input_ports[0]);
/*      #endif */  /* READ_USES_TRIS */
         }  /* neither adc nor cmcon */
   #endif  /* HAS_CMCON ... ELSE */
#endif  /* HAS_ADC ... ELSE */

#ifdef HAS_PORTB
   BYTE r_portb()
      {
      last_portb = input_ports[1];
      doing_portread = TRUE;  /* mostly for BSF / BCF */
/*    #ifdef READ_USES_TRIS */
      if (readusestris)
         return(regs[PORTB] = ((regs[PORTB] & ~regs[TRISB]) | (input_ports[1] & regs[TRISB])));
/*    #else */
      return(regs[PORTB] = input_ports[1]);
/*    #endif */  /* READ_USES_TRIS */
      }
#endif  /* HAS_PORTB */

#ifdef HAS_PORTC
   BYTE r_portc()
      {
      doing_portread = TRUE;  /* mostly for BSF / BCF */
/*    #ifdef READ_USES_TRIS */
      if (readusestris)
         {
         if (regs[T1CON] & T1OSCEN)
             /* ignore bits 0:1 of TRISC, PORTC 0:1 are inputs and read as 0 */
             /* 30292C.PDF, page 51 section 6.0 */
            return(regs[PORTC] = (((regs[PORTC] & ~regs[TRISC]) | (input_ports[2] & regs[TRISC])) & 0xfc));
         return(regs[PORTC] = ((regs[PORTC] & ~regs[TRISC]) | (input_ports[2] & regs[TRISC])));
         }
/*    #else */
      if (regs[T1CON] & T1OSCEN)
          /* ignore bits 0:1 of TRISC, PORTC 0:1 are inputs and read as 0 */
          /* 30292C.PDF, page 51 section 6.0 */
         return(regs[PORTC] = (input_ports[2] & 0xfc));
      return(regs[PORTC] = input_ports[2]);
/*    #endif */  /* READ_USES_TRIS */
      }
#endif  /* HAS_PORTC */

#ifdef HAS_PORTD
   BYTE r_portd()
      {
      doing_portread = TRUE;  /* mostly for BSF / BCF */
/*    #ifdef READ_USES_TRIS */
      if (readusestris)
         return(regs[PORTD] = ((regs[PORTD] & ~regs[TRISD]) | (input_ports[3] & regs[TRISD])));
/*    #else */
      return(regs[PORTD] = input_ports[3]);
/*    #endif */  /* READ_USES_TRIS */
      }
#endif  /* HAS_PORTD */

#ifdef HAS_PORTE
   #ifdef HAS_ADC
      BYTE r_porte()
         {
         doing_portread = TRUE;  /* mostly for BSF / BCF */
/*      #ifdef READ_USES_TRIS */
         if (readusestris)
            return(regs[PORTE] = ((regs[PORTE] & ~regs[TRISE])
               | ((input_ports[4] & regs[TRISE]) & adc_porte_masks[regs[ADCON1]&ADC_CONFIG_MASK])));
/*      #else */
         return(regs[PORTE] = (input_ports[4] & adc_porte_masks[regs[ADCON1]&ADC_CONFIG_MASK]));
/*      #endif */  /* READ_USES_TRIS */
         }
   #else  /* HAS_ADC */
      BYTE r_porte()
         {
         doing_portread = TRUE;  /* mostly for BSF / BCF */
/*      #ifdef READ_USES_TRIS */
         if (readusestris)
            return(regs[PORTE] = ((regs[PORTE] & ~regs[TRISE]) | (input_ports[4] & regs[TRISE])));
/*      #else */
         return(regs[PORTE] = input_ports[4]);
/*      #endif */  /* READ_USES_TRIS */
         }
   #endif  /* HAS_ADC */
#endif  /* HAS_PORTE */

BYTE r_trisa()
   {
#ifdef PICTYPE_16F648
   return(regs[TRISA] & NOT_BIT5);  /* bit 5 always returns a 0 */
#else
   #ifdef PICTYPE_12F675
      return(regs[TRISA] | BIT3);  /* bit 3 is always a 1 */
   #else
      return(regs[TRISA]);
   #endif  /* PICTYPE_12F675 */
#endif  /* PICTYPE_16F648 */
   }

#ifdef HAS_PORTB
   BYTE r_trisb()
      {
      return(regs[TRISB]);
      }
#endif  /* HAS_PORTB */

#ifdef HAS_PORTC
   BYTE r_trisc()
      {
      return(regs[TRISC]);
      }
#endif  /* HAS_PORTC */

#ifdef HAS_PORTD
   BYTE r_trisd()
      {
      return(regs[TRISD]);
      }
#endif  /* HAS_PORTD */

#ifdef HAS_PORTE
   BYTE r_trise()
      {
      return(regs[TRISE]);
      }
#endif  /* HAS_PORTE */

#ifdef HAS_UART
   BYTE r_rcreg()
      {
      BYTE retval, rval2;  /* rval2 to keep alignment */

      if ((regs[RCSTA] & CREN)
           && (uart_in_queue_head != uart_in_queue_tail)
           && (!rc_data_available))
         {
         regs[RCREG] = uart_in_queue[uart_in_queue_tail++];
         uart_in_queue_tail &= UART_QUEUE_MASK;
         }
      retval = regs[RCREG];
      rc_data_available = FALSE;
      regs[PIR1] &= ~RCIF;  /* turn off RCIF */
      if ((regs[RCSTA] & CREN)
           && (uart_in_queue_head != uart_in_queue_tail))
         {
         regs[RCREG] = uart_in_queue[uart_in_queue_tail++];
         uart_in_queue_tail &= UART_QUEUE_MASK;
         rc_data_available = TRUE;
         regs[PIR1] |= RCIF;  /* set RCIF */
         }
      return(retval);
      }
#endif  /* HAS_UART */

#ifdef EEPROM_SIZE
   BYTE r_eecon2()  /* not a physical register */
      {
      return(0);
      }
#endif  /* EEPROM_SIZE */

#ifdef HAS_CMCON
   BYTE r_cmcon()
      {
      last_cout = regs[CMCON] & C1OUT;
      return(regs[CMCON]);
      }
#endif  /* HAS_CMCON */

void w_reg()
   {
   regs[filenum_temp2] = regval;
   }

void w_tmr0()
   {
   regs[TMR0] = regval;
   tmr0_inhibit = 3;  /* inhibit TMR0 update for 2 instruction cycles */
                      /* Yup, I mean 3! */
   if (!(regs[OPTION] & PSA))  /* if prescalar assigned to TMR0 */
      tmr0_prescale_counter = 0;
   }

void w_status()
   {
   regs[STATUS] = (regs[STATUS] & 0x18) | (regval & 0xe7);
      /* cannot set !TO, !PD bits */
   }

#ifdef HAS_TMR1
   void w_t1con()
      {
      if ((!(regs[T1CON] & TMR1CS)) && (regval & TMR1CS))  /* if setting TMR1CS */
         {
   #ifdef PICTYPE_16F877
         last_t1cki = input_ports[2] & BIT0;  /* setup for next edge detect */
         t1cki_edge = BIT0;  /* want high to low before starting count */
         last_t1osi = input_ports[2] & BIT1;  /* setup for next edge detect */
         t1osi_edge = BIT1;  /* want high to low before starting count */
   #endif  /* PICTYPE_16F877 */
   #ifdef PICTYPE_16F648
         last_t1cki = input_ports[1] & BIT6;  /* setup for next edge detect */
         t1cki_edge = BIT6;  /* want high to low before starting count */
         last_t1osi = input_ports[1] & BIT7;  /* setup for next edge detect */
         t1osi_edge = BIT7;  /* want high to low before starting count */
   #endif  /* PICTYPE_16F648 */
   #ifdef PICTYPE_12F675
         last_t1cki = input_ports[0] & BIT5;  /* setup for next edge detect */
         t1cki_edge = BIT5;  /* want high to low before starting count */
         last_t1osi = 0;  /* does not have T1OSI */
         t1osi_edge = 0;  /* does not have T1OSI */
   #endif  /* PICTYPE_12f675 */
         }
      if ((!(regs[T1CON] & TMR1ON)) && (regval & TMR1ON))  /* if setting TMR1ON */
         tmr1_inhibit = 2;  /* do not update timer 1 for one instruction cycle */
                            /* yes, I mean 2 */
   #ifdef HAS_TMR1GE
      regs[T1CON] = regval & 0x7f;
   #else
      regs[T1CON] = regval & 0x3f;
   #endif  /* HAS_TMR1GE */
      tmr1_prescale = bittable[(regval & T1CON_PRESCALE_BITS) >> T1CON_PRESCALE_SHIFT];
      }

   void w_tmr1()
      {
      regs[filenum_temp2] = regval;
      tmr1_prescale_counter = 0;
      tmr1_inhibit = 2;  /* do not update timer 1 for one instruction cycle */
                         /* yes, I mean 2 */
      }
#endif  /* HAS_TMR1 */

#ifdef HAS_TMR2
   void w_t2con()
      {
      regs[T2CON] = regval & 0x7f;
      tmr2_prescale_counter = 0;
      tmr2_postscale_counter = 0;
      tmr2_inhibit = 2;  /* do not update timer 2 for one instruction cycle */
                         /* yes, I mean 2 */
      tmr2_prescale = tmr2_prescale_table[regs[T2CON] & T2CON_PS_BITS];
      tmr2_prescale_pwm_bitshift = tmr2_prescale_pwm_table[regs[T2CON] & T2CON_PS_BITS];
      }

   void w_tmr2()
      {
      regs[TMR2] = regval;
      tmr2_prescale_counter = 0;
      tmr2_postscale_counter = 0;
      tmr2_inhibit = 2;  /* do not update timer 2 for one instruction cycle */
                         /* yes, I mean 2 */
      }
#endif  /* HAS_TMR2 */

void w_pcl()
   {
   regs[PCL] = regval;
   ip = (regs[PCLATH] << 8) + regs[PCL];
   timingcount++;  /* NOPs now in prefetch queue */
   }

void w_porta()
   {
#ifdef PICTYPE_16F877
   regs[PORTA] = regval & 0x3f;
#endif  /* PICTYPE_16F877 */
#ifdef PICTYPE_12F675
   regs[PORTA] = regval & 0x3f;
   last_porta_in = input_ports[0];
#endif  /* PICTYPE_12F675 */
#ifdef PICTYPE_16F648
   regs[PORTA] = regval;
#endif  /* PICTYPE_16F648 */
#ifdef PICTYPE_16F84A
   regs[PORTA] = regval & 0x1f;
#endif  /* PICTYPE_16F84A */
   doing_portwrite = TRUE;
   io_processing();  /* always call this to check for SoftUart */
   doing_portwrite = FALSE;
   }

#ifdef HAS_PORTB
   void w_portb()
      {
      regs[PORTB] = regval;
      last_portb = input_ports[1];
      doing_portwrite = TRUE;
      io_processing();  /* always call this to check for SoftUart */
      doing_portwrite = FALSE;
      }
#endif  /* HAS_PORTB */

#ifdef HAS_PORTC
   void w_portc()
      {
      regs[PORTC] = regval;
      doing_portwrite = TRUE;
      io_processing();  /* always call this to check for SoftUart */
      doing_portwrite = FALSE;
      }
#endif  /* HAS_PORTC */

#ifdef HAS_PORTD
   void w_portd()
      {
      regs[PORTD] = regval;
      doing_portwrite = TRUE;
      io_processing();  /* always call this to check for SoftUart */
      doing_portwrite = FALSE;
      }
#endif  /* HAS_PORTD */

#ifdef HAS_PORTE
   void w_porte()
      {
      regs[PORTE] = regval & 0x07;
      doing_portwrite = TRUE;
      io_processing();  /* always call this to check for SoftUart */
      doing_portwrite = FALSE;
      }
#endif  /* HAS_PORTE */

void w_none()
   {
   }

void w_pclath()
   {
   regs[PCLATH] = regval & 0x01f;
   }

#ifdef HAS_PIR1
   #ifdef PICTYPE_12F675
      void w_pie1()
         {
         regs[PIE1] = regval & 0xc9;
         }
   #endif  /* PICTYPE_12F675 */

   #ifdef PICTYPE_16F648
      void w_pie1()
         {
         regs[PIE1] = regval & 0xf7;
         }
   #endif  /* PICTYPE_16F648 */

   void w_pir1()
      {
   #ifdef PICTYPE_16F877
      #ifdef HAS_UART
         regs[PIR1] = (regval & 0xcf) | (regs[PIR1] & 0x30);  /* can't reset RCIF, TXIF in software */
      #else
         regs[PIR1] = regval;
      #endif  /* HAS_UART */
   #endif  /* PICTYPE_16F877 */
   #ifdef PICTYPE_12F675
      regs[PIR1] = regval & 0xc9;
      io_processing();  /* if still comparitor mismatch, keep CMIF set */
   #endif  /* PICTYPE_12F675 */
   #ifdef PICTYPE_16F648
      regs[PIR1] = regval & 0xf7;
   #endif  /* PICTYPE_16F648 */
      }
#endif  /* HAS_PIR1 */

#ifdef HAS_PIR2
   void w_pir2()
      {
      regs[PIR2] = regval & 0x19;
      }
#endif  /* HAS_PIR2 */

#ifdef HAS_CCP
   void w_ccp1con()
      {
      regs[CCP1CON] = regval & 0x3f;
      ccp1_mode = (regval >> CCP_MODE_SHIFT) & 0x03;
      ccp1_fn = regval & CCP_MODEMASK;
      if ((ccp1_fn & CCPFN_PWMMODE) == CCPFN_PWMMODE)  /* if in PWM mode */
         ccp1_fn &= CCPFN_PWMMODE;  /* low 2 bits are a "don't care" */
      if (ccp1_mode == CCPMODE_DISABLE)
         ccp1_count = 0;
      if (ccp1_mode == CCPMODE_PWM)
         ccp1_dutycycle = ((WORD)regs[CCPR1L] << 2) | (((WORD)regs[CCP1CON] >> 4) & 0x03);
      }

   void w_ccpr1l()
      {
      regs[CCPR1L] = regval;
      if (ccp1_mode == CCPMODE_PWM)
         ccp1_dutycycle = ((WORD)regval << 2) | (((WORD)regs[CCP1CON] >> 4) & 0x03);
      }

   void w_ccpr1h()
      {
      if (ccp1_mode != CCPMODE_PWM)  /* is read-only in PWM mode */
         regs[CCPR1H] = regval;
      }

   #ifdef HAS_CCP2
      void w_ccp2con()
         {
         regs[CCP2CON] = regval & 0x3f;
         ccp2_mode = (regval >> CCP_MODE_SHIFT) & 0x03;
         ccp2_fn = regval & CCP_MODEMASK;
         if ((ccp2_fn & CCPFN_PWMMODE) == CCPFN_PWMMODE)  /* if in PWM mode */
            ccp2_fn &= CCPFN_PWMMODE;  /* low 2 bits are a "don't care" */
         if (ccp2_mode == CCPMODE_DISABLE)
            ccp2_count = 0;
         if (ccp2_mode == CCPMODE_PWM)
            ccp2_dutycycle = ((WORD)regs[CCPR2L] << 2) | (((WORD)regs[CCP2CON] >> 4) & 0x03);
         }

      void w_ccpr2l()
         {
         regs[CCPR2L] = regval;
         if (ccp2_mode == CCPMODE_PWM)
            ccp2_dutycycle = ((WORD)regval << 2) | (((WORD)regs[CCP2CON] >> 4) & 0x03);
         }

      void w_ccpr2h()
         {
         if (ccp2_mode != CCPMODE_PWM)  /* is read-only in PWM mode */
            regs[CCPR2H] = regval;
         }
   #endif  /* HAS_CCP2 */
#endif  /* HAS_CCP */

#ifdef HAS_ADC
   void w_adcon0()
      {
      WORD port, tris;
      WORD pin, portbit;
      WORD adc_chan;
      WORD vref_plus, vref_minus;

   #ifdef PICTYPE_16F877
      regs[ADCON0] = regval & 0xfd;  /* 1111 1101 */
   #endif  /* PICTYPE_16F877 */
   #ifdef PICTYPE_12F675
      regs[ADCON0] = regval & 0xcf;  /* 1100 1111 */
   #endif  /* PICTYPE_12F675 */
      if ((regval & ADON_GODONE) == ADON_GODONE)  /* if ADON and GO/DONE */
         {
   #ifdef PICTYPE_16F877
         if ((regval &= 0xc0) == 0)  /* if Tad == 2 * Tosc == Tinstr / 2 */
            adc_delay = 6;  /* Tinstr/2 * 11 = 5.5 * Tinstr, round up to 6 */
         else
            if (regval == 0x40)  /* if Tad == 8 * Tosc == 2 * Tinstr */
               adc_delay = 22;  /* Tinstr * 2 * 11 */
            else
               if (regval == 0x80)  /* if Tad == 32 * Tosc == 8 * Tinstr */
                  adc_delay = 88;  /* Tinstr * 8 * 11 */
               else
                  adc_delay = frequency / 90909L + 1;  /* Tad == internal RC == 4us */
             /* f/4e6==instrs/us -> f/1e6==instrs/4us -> 11*(f/1e6) = 11Tad */
             /* +1 instruction delay for SLEEP */
         adc_result = 0;
         adc_chan = (regs[ADCON0] >> 3) & 7;  /* index into tables */
         port = adc_ports[adc_chan];  /* get port (PORTA or PORTE) */
         tris = port + 0x80 + PORTA;
         portbit = 1 << (pin = adc_pins[adc_chan]);
         if (vref_high[regs[ADCON1] & ADC_CONFIG_MASK])
            vref_plus = analog_ports[0][3];
         else
            vref_plus = 0xffff;
         if (vref_low[regs[ADCON1] & ADC_CONFIG_MASK])
            vref_minus = analog_ports[0][2];
         else
            vref_minus = 0;
         if (vref_minus >= vref_plus)
            return;  /* that's about all we can do... */
         if (!(regs[tris] & (1 << pin)))  /* if an output, can't read applied voltage */
            {
            if (regs[port+PORTA] & (1 << pin))  /* if output is driven high */
               adc_result = 0x03ff;
            }
         else
            {
            if (((port == 0) && ((adc_porta_masks[adc_chan] & portbit) == 0))
                || ((port == (PORTE-PORTA)) && ((adc_porte_masks[adc_chan] & portbit) == 0)))
                       /* if analog pin */
               {
               if (adc_table_size)
                  {
                  adc_result = adc_table[adc_table_index] & 0x03ff;
                  if (++adc_table_index == adc_table_size)
                     adc_table_index = 0;
                  analog_ports[port][pin] = (((DWORD)adc_result * (DWORD)(vref_plus-vref_minus)) >> 10) + vref_minus;
                  io_processing();  /* show ADC value */
                  }
               else
                  {
                  adc_result = (vref_plus <= analog_ports[port][pin]) ?
                            0x03ff : (WORD)(((DWORD)(analog_ports[port][pin]-vref_minus) << 10) / (DWORD)(vref_plus-vref_minus));
                  }  /* if (adc_table_size) ... else */
               }  /* if analog pin ... else */
            }  /* if output pin ... else */
   #endif  /* PICTYPE_16F877 */
   #ifdef PICTYPE_12F675
         if (((regval = (regs[ANSEL] >> 4)) & 0x03) == 0x03)
            {
            adc_delay = frequency / 90909L + 1;  /* Tad == internal RC == 4us */
             /* f/4e6==instrs/us -> f/1e6==instrs/4us -> 11*(f/1e6) = 11Tad */
             /* +1 instruction delay for SLEEP */
            }
         else
            adc_delay = adc_delay_table[regval];
         adc_result = 0;
         portbit = 1 << (pin = (regs[ADCON0] >> 2) & 3);  /* acutally, pin is port number right now */
         pin = adc_pins[pin];  /* NOW, pin is really pin number */
         if (!(regs[TRISA] & (1 << pin)))  /* if an output, can't read applied voltage */
            {
            if (regs[PORTA] & (1 << pin))  /* if output is driven high */
               adc_result = 0x03ff;
            }
         else
            {
            if (regs[ANSEL] & portbit)  /* if analog pin */
                                /* pin is actually ADC channel number */
               {
               if (adc_table_size)
                  {
                  adc_result = adc_table[adc_table_index] & 0x03ff;
                  if (++adc_table_index == adc_table_size)
                     adc_table_index = 0;
                  if ((regs[ADCON0] & VCFG)  /* use GP1 == Vref */
                             && (regs[ANSEL] & BIT1))  /* if Vref is analog */
                     analog_ports[0][pin] = ((DWORD)adc_result * (DWORD)analog_ports[0][1]) >> 10;
                  else
                     analog_ports[0][pin] = adc_result << 6;
                  io_processing();  /* show ADC value */
                  }
               else
                  {
                  if ((regs[ADCON0] & VCFG)  /* use GP1 == Vref */
                             && (regs[ANSEL] & BIT1))  /* if Vref is analog */
                     {
                     adc_result = (analog_ports[0][1] <= analog_ports[0][pin]) ? 
                            0x03ff : (WORD)(((DWORD)analog_ports[0][pin] << 10) / (DWORD)analog_ports[0][1]);
                     }
                  else
                     adc_result = analog_ports[0][pin] >> 6;
                  }  /* if (adc_table_size) ... else */
               }  /* if (regs[ANSEL] & ...  */
            }  /* if (!(regs[TRISA] & pin)) ... else */
   #endif  /* PICTYPE_12F675 */
         if (!(regs[ADFM_REG] & ADFM))  /* left justified */
            adc_result <<= 6;
         }  /* if ((regval & ADON_GODONE) == ADON_GODONE) */
      else
         adc_delay = 0;  /* conversion aborted */
      }

   #ifndef PICTYPE_12F675
      void w_adcon1()
         {
         regs[ADCON1] = regval & 0x8f;  /* 1000 1111 */
         }
   #endif  /* PICTYPE_12F675 */
#endif  /* HAS_ADC */

#ifdef HAS_ANSEL
   void w_ansel()
      {
      regs[ANSEL] = regval & 0x7f;
      }
#endif  /* HAS_ANSEL */

#ifdef HAS_CMCON
   void w_cmcon()
      {
#ifdef PICTYPE_12F675
      regs[CMCON] = (regval & 0x1f) | (regs[CMCON] & 0xe0);  /* upper 3 bits are Read-Only */
#endif  /* PICTYPE_12F675 */
#ifdef PICTYPE_16F648
      regs[CMCON] = (regval & 0x3f) | (regs[CMCON] & 0xc0);  /* upper 2 bits are Read-Only */
#endif  /* PICTYPE_16F648 */
      last_cout = regs[CMCON] & C1OUT;
      io_processing();  /* CMCON change can change I/O values */
      }
#endif  /* HAS_CMCON */

void w_trisa()
   {
#ifdef PICTYPE_16F877
   regs[TRISA] = regval & 0x3f;
#endif  /* PICTYPE_16F877 */
#ifdef PICTYPE_12F675
   regs[TRISA] = regval | BIT3;  /* BIT3 (GPIO3) is always an input */
#endif  /* PICTYPE_12F675 */
#ifdef PICTYPE_16F648
   regs[TRISA] = (regval & NOT_BIT5) | BIT5;
      /* although reading TRISA always returns a 0 for BIT5 (not implemented),
       * logically A5 is always an input.
       */
#endif  /* PICTYPE_16F648 */
#ifdef PICTYPE_16F84A
   regs[TRISA] = regval & 0x1f;
#endif  /* PICTYPE_16F84A */
   io_processing();
   }

#ifdef HAS_PORTB
   void w_trisb()
      {
      regs[TRISB] = regval;
      io_processing();
      }
#endif  /* HAS_PORTB */

#ifdef HAS_PORTC
   void w_trisc()
      {
      regs[TRISC] = regval;
      io_processing();
      }
#endif  /* HAS_PORTC */

#ifdef HAS_PORTD
   void w_trisd()
      {
      regs[TRISD] = regval;
      io_processing();
      }
#endif  /* HAS_PORTD */

#ifdef HAS_PORTE
   void w_trise()
      {
      regs[TRISE] = regval & 0x37;
      io_processing();
      }
#endif  /* HAS_PORTE */

#ifdef HAS_PIR2
   void w_pie2()
      {
      regs[PIE2] = regval & 0x19;
      }
#endif  /* HAS_PIR2 */

#ifdef HAS_PCON
   void w_pcon()
      {
   #ifdef HAS_OSCF
      regs[PCON] = regval & 0x0b;  /* 0000 1011 */
      /* if (regval & PCON_OSCF) ... */
   #else
      regs[PCON] = regval & 0x03;
   #endif  /* HAS_OSCF */
      }
#endif  /* HAS_PCON */

#ifdef HAS_WPU
   void w_wpu()
      {
      regs[WPU] = regval & 0x37;
      }
#endif  /* HAS_WPU */

#ifdef HAS_IOC
   void w_ioc()
      {
      regs[IOC] = regval & 0x3f;
      }
#endif  /* HAS_IOC */

#ifdef HAS_UART
   void set_baudrate()
      {
      WORD toler, i;

      if (regs[TXSTA] & BRGH)  /* if BRGH */
         {
         baudrate = frequency / (16 * ((WORD)regs[SPBRG] + 1));
/*         tsr_hold_delay_count = 20 * ((WORD)regs[SPBRG] + 1); */
         trmt_hold_delay_count = 40 * ((WORD)regs[SPBRG] + 1);
         }
      else
         {
         baudrate = frequency / (64 * ((WORD)regs[SPBRG] + 1));
/*         tsr_hold_delay_count = 80 * ((WORD)regs[SPBRG] + 1); */
         trmt_hold_delay_count = 160 * ((WORD)regs[SPBRG] + 1);
         }
   /*
    *  NOTE: bits/second = frequency / ((BRGH ? 16 : 64) * (SPBRG+1))
    *        => bits/second = instrs/second*4 / ((BRGH ? 16 : 64) * (SPBRG+1))
    *        => (instrs/second)*(seconds/bit) = ((BRGH ? 16 : 64) * (SPBRG+1))/4
    *        => instructions/bit = ((BRGH ? 4 : 16)*(SPBRG+1)
    *        and, with 10 bits == TXBYTE (1 start, 8 data, 1 stop), 1/2 char is
    *        => (instructions/bit) * (bits/TXBYTE) = 10*((BRGH ? 4 : 16)*(SPBRG+1)
    *        => instructions/TXBYTE = ((BRGH ? 40 : 160)*(SPBRG+1)
    */
      toler = baudrate / 20;  /* 5% tolerance */
      for (i = 0; i < BAUDTABLE_SIZE; i++)
         if (((baudrate-toler) < baudtable[i])
                             && ((baudrate+toler) > baudtable[i]))
            {
            baudrate = baudtable[i];
            break;
            }
      }

   void w_rcsta()
      {
      regs[RCSTA] = regval;
      if (commport)  /* if not SCREEN/KEYBOARD */
         {
         if (!(regs[TXSTA] & SYNC) && (regval & SPEN))
            /* if ASYNC && Serial Port Enabled */
            init_comm_port();
         else
            disable_comm_port();
         }
      if (regval & SPEN)  /* if SPEN */
         {
         regs[TX_TRIS] &= TX_PIN;  /* set TRIS bit to OFF (TX is an OUTPUT) */
         tx_port_available = TRUE;
         }
      else
         {
         tsr_hold_available = FALSE;  /* clear out tsr_hold */
         }
      }

   void w_txsta()
      {
      if (!(regs[TXSTA] & TXEN) && (regval & TXEN))  /* if turning TXEN on */
         tx_int_delay_counter = tx_int_delay;
      regs[TXSTA] = (regval & 0xf5) | (regs[TXSTA] & TRMT);  /* can't reset TRMT in software */
      if (!(regs[TXSTA] & SYNC) && (regs[RCSTA] & SPEN))
         /* if ASYNC && Serial Port Enabled */
         {
         set_baudrate();
         if (commport)  /* if not SCREEN/KEYBOARD */
            init_comm_port();
         }
      else
         if (commport)  /* if not SCREEN/KEYBOARD */
            disable_comm_port();
      if (!(regs[TXSTA] & TXEN))
         {
         tsr_hold_available = FALSE;  /* clear out anything waiting */
         }
      }

   void w_txreg()
      {
      regs[TXREG] = regval;
      regs[PIR1] &= ~TXIF;  /* turn off TXIF */
      if ((regs[TXSTA] & TXEN)  /* if TXEN && SPEN */
                 && (regs[RCSTA] & SPEN))
         {
         tx_data_available = TRUE;
         if ((tx_port_available) && (!tsr_hold_available))
            {
            tx_port_available = FALSE;  /* port in use */
            tx_data_available = FALSE;  /* data already sent */
            regs[PIR1] |= TXIF;  /* set TXIF */
            tsr_hold = regval;  /* put data in "TSR" */
            tsr_hold_available = TRUE;
            trmt_hold_delay = trmt_hold_delay_count;
            tsr_hold_delay = trmt_hold_delay_count >> 1;
            regs[TXSTA] &= ~TRMT;  /* clear TRMT */
            }
         }  /* if ((TXEN) && (SPEN)) */
      }

   void w_spbrg()
      {
      regs[SPBRG] = regval;
      set_baudrate();
      }
#endif  /* HAS_UART */

void w_option()
   {
   BYTE last_option, filler;  /* filler for alignment */

   last_option = regs[OPTION];
   regs[OPTION] = regval;
   if ((last_option & T0CS) && (!(regval & T0CS)))
      tmr0_inhibit = 3;  /* inhibit TMR0 update for 2 instruction cycles */
                         /* Yup, I mean 3! */
   tmr0_prescale = bittable[regs[OPTION] & OPTION_PRESCALE_BITS];  /* get new prescale */
   if (!(regs[OPTION] & PSA))  /* if prescale assigned to TMR0 */
      tmr0_prescale <<= 1;  /* prescale is 2 .. 256 */
   }

#ifdef EEPROM_SIZE
   void w_eecon1()
      {
      WORD temp, index;

      if (!(regs[EECON1] & WREN))  /* if WREN is not set */
         regval &= ~WR;            /* then WR can't be set! */
      regs[EECON1] = (regs[EECON1] & 0x03) | (regval & 0x8f);
         /* WR (bit 1) and RD (bit 0) can only be set, not cleared */
         /* bits 4, 5, 6 are not implemented */
      if (eeprom_delay)  /* if we're busy with a write */
         return;   /* don't do anything */
      if (regval & RD)  /* RD takes precedence over WR -- I hope! */
         {
   #ifdef SELF_FLASH
         if (regval & EEPGD)  /* if reading program memory */
            {
            if ((!memory[ip]) && (!memory[(ip+1)&MEMORY_MASK])  /* if followed by 2 NOPs */
                   && ((temp = ((WORD)regs[EEADR] + ((WORD)regs[EEADRH] << 8))) < MEMORY_SIZE))
                                /* and memory address in range */
               {
               regs[EEDATA] = (BYTE)memory[temp];
               regs[EEDATH] = (BYTE)(memory[temp] >> 8);
#ifdef EEIF_IN_EECON1
               regs[EECON1] |= EEIF;
#else
               regs[PIR2] |= EEIF;
#endif  /* EEIF_IN_EECON1 */
               regs[EECON1] &= ~RD;
               }
            }
         else  /* this must be EEPROM data */
            {
   #endif  /* SELF_FLASH */
            if (regs[EEADR] < EEPROM_SIZE)  /* if in valid range */
               regs[EEDATA] = eeprom[regs[EEADR]];
            regs[EECON1] &= ~RD;
   #ifdef SELF_FLASH
            }
   #endif  /* SELF_FLASH */
         }
      else
         if ((regval & WREN)                 /* if write enabled */
                    && (regval & WR)         /* if doing a WRITE */
                    && (eecon2_ready == 1))  /* and EECON2 went though proper hoops */
            {
   #ifdef SELF_FLASH
            if (regval & EEPGD)  /* if programming program memory */
               {
               if ((!memory[ip]) && (!memory[(ip+1)&MEMORY_MASK])  /* if followed by 2 NOPs */
                      && ((temp = ((WORD)regs[EEADR] + ((WORD)regs[EEADRH] << 8))) < MEMORY_SIZE))
                                   /* and memory address in range */
                  {
                     /* NOTE: I'm not sure from the documentation, but I'm think
                      *       that if we have code protection, then we don't
                      *       write to the FLASH, but do set EEIF.  Clues?
                      */
                  if (((index=((configuration & CONFIG_CPLOW) >> CPLOW_BITS_SHIFT))
                               == ((configuration & CONFIG_CPHIGH) >> CPHIGH_BITS_SHIFT))
                         && ((temp < cp_minaddr[index])
                              || (temp > cp_maxaddr[index]))
                         && (configuration & CONFIG_WRT))
                     {
                     memory[temp] = (WORD)regs[EEDATA] + ((WORD)regs[EEDATH] << 8);
                     timingcount += frequency / 1000;  /* this will take ~4ms */
                     }
#ifdef EEIF_IN_EECON1
                  regs[EECON1] |= EEIF;
#else
                  regs[PIR2] |= EEIF;
#endif  /* EEIF_IN_EECON1 */
                  regs[EECON1] &= ~WR;  /* clear WR bit */
                  }
               }
            else  /* this must be EEPROM data */
               {
   #endif  /* SELF_FLASH */
               if (regs[EEADR] < EEPROM_SIZE)  /* if in valid range */
                  eeprom[regs[EEADR]] = regs[EEDATA];
               eeprom_delay = frequency / 1000;  /* this will take ~4ms */
   #ifdef SELF_FLASH
               }
   #endif  /* SELF_FLASH */
            }
      }

   /*
    *  Note:  The timing represented by eecon2_state/eecon2_ready is:
    *       <...set BANK bits...>
    *       MOVLW 55   ;need this instr
    *       MOVWF 0D   ;set EECON2, eecon2_state = 3
    *                  ;interpreter loop post-processing, eecon2_state = 2
    *       MOVLW AA   ;need this instr
    *                  ;interpreter loop post-processing, eecon2_state = 1
    *       MOVWF 0D   ;set EECON2, eecon2_ready = 2
    *                  ;interpreter loop post-processing, eecon2_ready = 1
    *       BSF   0C,1 ;start write
    *
    *  Also note, however, that any equivalent sequence of instructions will
    *  also work.  i.e.
    *       <...set BANK bits...>
    *       MOVLW 8D   ;pointer to EECON2
    *       MOVWF 4    ;set FSR
    *       BSF   3,7  ;set IRP so that IRP:FSR --> EECON2
    *       MOVLW 55   ;or any instruction(s) that gives you a 55 in W
    *       MOVWF 0    ;move 55 to EECON2 via INDF
    *                  ;set EECON2, eecon2_state = 3
    *                  ;interpreter loop post-processing, eecon2_state = 2
    *       XORLW FF   ;get an AA
    *                  ;interpreter loop post-processing, eecon2_state = 1
    *       MOVWF 0    ;move AA to EECON2 via INDF
    *                  ;set EECON2, eecon2_ready = 2
    *                  ;interpreter loop post-processing, eecon2_ready = 1
    *       BSF   0C,1 ;start write
    *
    */
   void w_eecon2()
      {
      if (regval == 0x55)
         {
         eecon2_state = 3;  /* ready for next sequence */
         }
      else
         if ((regval == 0xaa) && (eecon2_state == 1))
            {
            eecon2_ready = 2;  /* ready for set of WR bit */
            }
      }

   #ifdef PICTYPE_12F675
      void w_eedat()
         {
         if (!eeprom_delay)  /* if we're not busy */
            regs[EEDATA] = regval;
         }

      void w_eeadr()
         {
         if (!eeprom_delay)  /* if we're not busy */
            regs[EEADR] = regval & 0x7f;
         }
   #else
      void w_eereg()
         {
         if (!eeprom_delay)  /* if we're not busy */
            regs[filenum_temp2] = regval;
         }
   #endif  /* PICTYPE_12F675 */

   #ifdef SELF_FLASH
      void w_eedath()
         {
         if (!eeprom_delay)  /* if we're not busy */
            regs[filenum_temp2] = regval & 0x3f;
         }

      void w_eeadrh()
         {
         if (!eeprom_delay)  /* if we're not busy */
            regs[filenum_temp2] = regval & 0x1f;
         }
   #endif  /* SELF_FLASH */
#endif  /* EEPROM_SIZE */

#ifdef HAS_VRCON
   void w_vrcon()
      {
   #ifdef PICTYPE_12F675
      regs[VRCON] = regval & 0xaf;  /* bits 6 & 4 unimplemented */
   #endif  /* PICTYPE_12F675 */
   #ifdef PICTYPE_16F648
      regs[VRCON] = regval & 0xef;  /* bit 4 unimplemented */
   #endif  /* PICTYPE_16F648 */
      if (regval & VREN)  /* if compare voltage reference enabled */
         {
         if (regval & VRR)  /* if low range */
            cvref = (WORD)(0xffffL * (DWORD)(regval & 0x0f) / 24L);
                              /* VR3:VR0/24 * Vdd */
         else
            cvref = (WORD)(0x3fffL + 0x07ffL * (DWORD)(regval & 0x0f));
                              /* Vdd/4 + (VR3:VR0/32) * Vdd */
         }
      else
        cvref = 0;
      io_processing();  /* update comparitor, if needed */
      }
#endif  /* HAS_VRCON */

#ifdef HAS_OSCCAL
   void w_osccal()
      {
      regs[OSCCAL] = regval & 0xfc;
      }
#endif

#ifdef PICTYPE_16F877
   #include "p877regs.h"
#endif  /* PICTYPE_16F877 */

#ifdef PICTYPE_16F648
   #include "p648regs.h"
#endif  /* PICTYPE_16F648 */

#ifdef PICTYPE_16F84A
   #include "p84regs.h"
#endif  /* PICTYPE_16F84A */

#ifdef PICTYPE_12F675
   #include "p675regs.h"
#endif  /* PICTYPE_12F675 */

/*
 *  Note:  there is no special code to make sure that an indirect read
 *         of register 0 returns 0.  Since register 0 cannot be set,
 *         it will always contain 0.
 */
BYTE read_regs()
   {
   WORD loopcounter;
   WORD checkval;
   BYTE tempval, maskedval;

   checkval = 0;  /* default:  do not need to check value filenum_tempx */
#ifdef SLOW_REGBREAK_CHECKS
   if (num_reg_breakpoints)
      for (loopcounter = 0; loopcounter < num_reg_breakpoints; loopcounter++)
         {
         if ((reg_breaks[loopcounter].type & REGBREAK_READ)
                  && (reg_breaks[loopcounter].low <= filenum_temp)
                  && (reg_breaks[loopcounter].high >= filenum_temp))
            {
            if (reg_breaks[loopcounter].have_value)
               {
               checkval |= 1;
               continue;  /* at this level, can't detect a value/masked breakpoint */
               }
            breakpoint = BRK_REGISTER;
            noexecute = TRUE;
            break;
            }
         }
#endif  /* SLOW_REGBREAK_CHECKS */
   filenum_temp2 = xlate_regs[filenum_temp];  /* lookup actual reg index */
#ifdef USE_ADDRLIST
   if ((addrlist)
        && ((loopcounter = peekw(addrlist_seg,wherequeue[whereptr]<<1)) != 0xffff)
        && (loopcounter != filenum_temp2))
            /* use loopcounter as a temp value */
      {
      breakpoint = BRK_ADDRLIST;
      noexecute = TRUE;
      }
#endif  /* USE_ADDRLIST */
   if (filenum_temp2 == INDF)  /* if indirect */
      {
      if (num_reg_breakpoints)
         for (loopcounter = 0; loopcounter < num_reg_breakpoints; loopcounter++)
            {
            if ((reg_breaks[loopcounter].type & REGBREAK_READ)
                     && (reg_breaks[loopcounter].low <= INDF)
                     && (reg_breaks[loopcounter].high >= INDF))
               {
               if (reg_breaks[loopcounter].have_value)
                  {
                  checkval |= 4;
                  continue;  /* at this level, can't detect a value/masked breakpoint */
                  }
               breakpoint = BRK_REGISTER;
               noexecute = TRUE;
               break;
               }
            }
#ifdef HAS_IRP
      filenum_temp2 = xlate_regs[(WORD)regs[FSR] + (((WORD)regs[STATUS] & STATUS_IRP) << 1)];
#else
      filenum_temp2 = xlate_regs[(WORD)regs[FSR]];
#endif  /* HAS_IRP */
      }
   if (num_reg_breakpoints)
#ifdef SLOW_REGBREAK_CHECKS
      if (filenum_temp2 != filenum_temp)  /* if we haven't checked this already */
#endif  /* SLOW_REGBREAK_CHECKS */
         for (loopcounter = 0; loopcounter < num_reg_breakpoints; loopcounter++)
            {
            if ((reg_breaks[loopcounter].type & REGBREAK_READ)
                     && (reg_breaks[loopcounter].low <= filenum_temp2)
                     && (reg_breaks[loopcounter].high >= filenum_temp2))
               {
               if (reg_breaks[loopcounter].have_value)
                  {
                  checkval |= 2;
                  continue;  /* at this level, can't detect a value/masked breakpoint */
                  }
               breakpoint = BRK_REGISTER;
               noexecute = TRUE;
               break;
               }
            }
   if (noexecute)  /* do not use variable breakpoint, do not confuse with user hotkey */
      return(0);  /* note:  if a breakpoint, don't read reg because we could
                   *        do something irreversable
                   */
   tempval = (*readregs[filenum_temp2])();
   if (checkval)
      {
      for (loopcounter = 0; loopcounter < num_reg_breakpoints; loopcounter++)
         {
         if ((reg_breaks[loopcounter].type & REGBREAK_READ)
               && (
                      ((checkval & 1)
                        && (reg_breaks[loopcounter].low <= filenum_temp)
                        && (reg_breaks[loopcounter].high >= filenum_temp))
                 ||
                      ((checkval & 2)
                        && (reg_breaks[loopcounter].low <= filenum_temp2)
                        && (reg_breaks[loopcounter].high >= filenum_temp2))
                 ||
                      ((checkval & 4)
                        && (reg_breaks[loopcounter].low <= INDF)
                        && (reg_breaks[loopcounter].high >= INDF))
                 )
            )
            {
            if (reg_breaks[loopcounter].have_value)
               {
               maskedval = tempval & reg_breaks[loopcounter].mask;
               if (maskedval == reg_breaks[loopcounter].value)
                  {
                  breakpoint = BRK_REGREADVAL;
                  return(tempval);
                  }
               }  /* if (reg_breaks[loopcounter].have_value) */
            }  /* if ((reg_breaks[loopcounter].type...) */
         }  /* for (loopcounter...) */
      }
   return(tempval);
   }

void write_regs()
   {
   WORD loopcounter;

#ifdef SLOW_REGBREAK_CHECKS
   if (num_reg_breakpoints)
      for (loopcounter = 0; loopcounter < num_reg_breakpoints; loopcounter++)
         {
         if ((reg_breaks[loopcounter].type & REGBREAK_WRITE)
                  && (reg_breaks[loopcounter].low <= filenum_temp)
                  && (reg_breaks[loopcounter].high >= filenum_temp))
            {
            if (reg_breaks[loopcounter].have_value)
               {
               if ((regval & reg_breaks[loopcounter].mask) != reg_breaks[loopcounter].value)
                  continue;  /* nope, this break does not apply */
               breakpoint = BRK_REGWRITEVAL;
               }
            else
               breakpoint = BRK_REGISTER;
            noexecute = TRUE;
            break;
            }
         }
#endif  /* SLOW_REGBREAK_CHECKS */
   filenum_temp2 = xlate_regs[filenum_temp];  /* lookup actual reg index */
#ifdef USE_ADDRLIST
   if ((addrlist)
        && ((loopcounter = peekw(addrlist_seg,wherequeue[whereptr]<<1)) != 0xffff)
        && (loopcounter != filenum_temp2))
            /* use loopcounter as a temp value */
      {
      breakpoint = BRK_ADDRLIST;
      noexecute = TRUE;
      }
#endif  /* USE_ADDRLIST */
   if (filenum_temp2 == INDF)  /* if indirect */
      {
      if (num_reg_breakpoints)
         for (loopcounter = 0; loopcounter < num_reg_breakpoints; loopcounter++)
            {
            if ((reg_breaks[loopcounter].type & REGBREAK_WRITE)
                     && (reg_breaks[loopcounter].low <= INDF)
                     && (reg_breaks[loopcounter].high >= INDF))
               {
               if (reg_breaks[loopcounter].have_value)
                  {
                  if ((regval & reg_breaks[loopcounter].mask) != reg_breaks[loopcounter].value)
                     continue;
                  breakpoint = BRK_REGWRITEVAL;
                  }
               else
                  breakpoint = BRK_REGISTER;
               noexecute = TRUE;
               break;
               }
            }
#ifdef HAS_IRP
      filenum_temp2 = xlate_regs[(WORD)regs[FSR] + (((WORD)regs[STATUS] & STATUS_IRP) << 1)];
#else
      filenum_temp2 = xlate_regs[(WORD)regs[FSR]];
#endif  /* HAS_IRP */
      }
   if (num_reg_breakpoints)
#ifdef SLOW_REGBREAK_CHECKS
      if (filenum_temp2 != filenum_temp)  /* if we haven't checked this already */
#endif  /* SLOW_REGBREAK_CHECKS */
         for (loopcounter = 0; loopcounter < num_reg_breakpoints; loopcounter++)
            {
            if ((reg_breaks[loopcounter].type & REGBREAK_WRITE)
                     && (reg_breaks[loopcounter].low <= filenum_temp2)
                     && (reg_breaks[loopcounter].high >= filenum_temp2))
               {
               if (reg_breaks[loopcounter].have_value)
                  {
                  if ((regval & reg_breaks[loopcounter].mask) != reg_breaks[loopcounter].value)
                     continue;
                  breakpoint = BRK_REGWRITEVAL;
                  }
               else
                  breakpoint = BRK_REGISTER;
               noexecute = TRUE;
               break;
               }
            }
   if (!noexecute)  /* do not use variable breakpoint, do not confuse with user hotkey */
      (*writeregs[filenum_temp2])();
   }

/*
 *  Note: the functions below this point are designed to be called from
 *        inside the interrupt 9 keyboard handler take_int9().  Thus, they
 *        make minimal use of the stack.
 */

void update_analog_value(val,mode,port,bit)
   WORD *val;
   WORD mode;   /* 4=decrease, 3=increase, 2=toggle, 1=set, 0=reset, OTHERWISE IGNORE */
   WORD port;   /* 0 = A, 1 = B, ... */
   WORD bit;    /* bit number 0 .. 7 */
   {
   if (mode == 2)
      *val ^= 0xffff;
   else
      if (mode == 1)
         *val = 0xffff;
      else
         if (mode == 3)
            {
            if (*val < 0xff00)
               *val += 0x0100;
            else
               *val = 0xffff;
            }
         else
            if (mode == 4)
               {
               if (*val > 0x0100)
                  *val -= 0x0100;
               else
                  *val = 0;
               }
            else
               if (mode == 0)
                  *val = 0x0000;
   if (input_ports[port] & bittable[bit])  /* if ON */
      {
      if (analog_ports[port][bit] < SCHMITT_FALSE_LEVEL)
         input_ports[port] &= ~bittable[bit];
      }
   else
      {
      if (analog_ports[port][bit] > SCHMITT_TRUE_LEVEL)
         input_ports[port] |= bittable[bit];
      }
   }

#ifdef HAS_IOC
   #ifdef PICTYPE_12F675
      void check_ioc()
         {
         if ((last_porta_in ^ input_ports[0])  /* if port status has changed */
                    & regs[IOC]                /* and IOC is set */
                    & regs[TRISA]              /* and pin is an input */
                    & adc_porta_masks[regs[ANSEL]&ADC_CONFIG_MASK]  /* and not assigned to ADC */
                    & cmcon_porta_masks[regs[CMCON]&CMCON_CONFIG_MASK])  /* and not assigned to comparitor */
            regs[INTCON] |= GPIF;  /* set interrupt-on-change */
         }
   #endif  /* PICTYPE_12F675 */
#endif  /* HAS_IOC */

void porta_bit0(mode)
      /* 12F675: GP0 / AN0 / CIN+ */
      /* 16F648: RA0 / AN0 */
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[0][0],mode,0,0);
#ifdef HAS_IOC
   #ifdef PICTYPE_12F675
   check_ioc();
   #endif  /* PICTYPE_12F675 */
#endif  /* HAS_IOC */
   }

void porta_bit1(mode)
      /* 12F675: GP1 / AN1 / CIN- / Vref */
      /* 16F648: RA1 / AN1 */
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[0][1],mode,0,1);
#ifdef HAS_IOC
   #ifdef PICTYPE_12F675
   check_ioc();
   #endif  /* PICTYPE_12F675 */
#endif  /* HAS_IOC */
   }

/*
 *  NOTE:  Does T0CS force the T0CKI pin to be an input pin despite
 *         the TRIS register?
 */
void porta_bit2(mode)
      /* 12F675: GP2 / AN2 / T0CKI / INT / COUT */
      /* 16F648: RA2 / AN2 / Vref */
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[0][2],mode,0,2);
#ifdef PICTYPE_12F675
   /*
    *  Note:  T0SE == 1 --> increment TMR0 on high-to-low transition
    *         T0SE == 0 --> increment TMR0 on low-to-high transition
    */
   if ((!sleepmode)                   /* TIMER0 does not operate in sleep mode */
           && (!tmr0_inhibit)         /* and not inhibited */
           && (regs[OPTION] & T0CS))  /* if Timer 0 based on T0CKI transition */
      {
      if (((regs[OPTION] & T0SE) == ((last_t0cki & BIT2) << 2))  /* if last was correct high/low state */
               && ((input_ports[0] & BIT2) != (last_t0cki & BIT2)))  /* and this is a transition */
         {
         if (regs[OPTION] & PSA)  /* if prescale assigned to WDT */
            {
            if (!(++regs[TMR0]))
               regs[INTCON] |= T0IF;
            }
         else
            {
            if (++tmr0_prescale_counter >= tmr0_prescale)
               {
               if (!(++regs[TMR0]))
                  regs[INTCON] |= T0IF;
               tmr0_prescale_counter = 0;
               }
            }
         }
      }
   last_t0cki = input_ports[0];  /* setup for next edge detect */
#endif  /* PICTYPE_12F675 */
#ifdef PICTYPE_12F675
   if (regs[OPTION] & INTEDG)
      {
      if ((!(last_intpin & BIT2)) && (input_ports[0] & BIT2))  /* rising edge */
         regs[INTCON] |= INTF;
      }
   else
      {
      if ((last_intpin & BIT2) && (!(input_ports[0] & BIT2)))  /* falling edge */
         regs[INTCON] |= INTF;
      }
   last_intpin = input_ports[0];  /* setup for next edge detect */
#endif  /* PICTYPE_12F675 */
#ifdef HAS_IOC
   #ifdef PICTYPE_12F675
   check_ioc();
   #endif  /* PICTYPE_12F675 */
#endif  /* HAS_IOC */
   }

void porta_bit3(mode)
      /* 12F675: GP3 / !MCLR */
      /* 16F648: RA3 / AN3 / CMP1 */
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[0][3],mode,0,3);
#ifdef PICTYPE_12F675
   if ((configuration & CONFIG_MCLRE)  /* if GP3 is MCLR */
            && (!(input_ports[0] & BIT3)))  /* and MCLR low */
      do_mclr_reset = TRUE;
#endif  /* PICTYPE_12F675 */
#ifdef HAS_IOC
   #ifdef PICTYPE_12F675
   check_ioc();
   #endif  /* PICTYPE_12F675 */
#endif  /* HAS_IOC */
   }

void porta_bit4(mode)
      /* 12F675: GP4 / AN3 / !T1G / OSC2 / CLKOUT */
      /* 16F648: RA4 / T0CKI / CMP2 */
      /* 16F84A: RA4 / T0CKI */
          /*
           *  NOTE:  Does T0CS force the T0CKI pin to be an input pin despite
           *         the TRIS register?
           */
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[0][4],mode,0,4);
   /*
    *  Note:  The following code is based on the fact that T0SE is in
    *         bit position 4, like the A4 bit.
    */
#ifdef PICTYPE_16F877
   if ((!sleepmode)                   /* TIMER0 does not operate in sleep mode */
           && (!tmr0_inhibit)         /* and not inhibited */
           && (regs[OPTION] & T0CS))  /* if Timer 0 based on T0CKI transition */
      {
      if (((regs[OPTION] & T0SE) == (last_t0cki & T0SE))  /* if last was correct high/low state */
               && ((input_ports[0] & T0SE) != (last_t0cki & T0SE)))  /* and this is a transition */
         {
         if (regs[OPTION] & PSA)  /* if prescale assigned to WDT */
            {
            if (!(++regs[TMR0]))
               regs[INTCON] |= T0IF;
            }
         else
            {
            if (++tmr0_prescale_counter >= tmr0_prescale)
               {
               if (!(++regs[TMR0]))
                  regs[INTCON] |= T0IF;
               tmr0_prescale_counter = 0;
               }
            }
         }
      }
   last_t0cki = input_ports[0];  /* setup for next edge detect */
#endif  /* PICTYPE_16F877 */
  /* NOTE: I'd love to have an OR... */
#ifdef PICTYPE_16F648
   if ((!sleepmode)                   /* TIMER0 does not operate in sleep mode */
           && (!tmr0_inhibit)         /* and not inhibited */
           && (regs[OPTION] & T0CS))  /* if Timer 0 based on T0CKI transition */
      {
      if (((regs[OPTION] & T0SE) == (last_t0cki & T0SE))  /* if last was correct high/low state */
               && ((input_ports[0] & T0SE) != (last_t0cki & T0SE)))  /* and this is a transition */
         {
         if (regs[OPTION] & PSA)  /* if prescale assigned to WDT */
            {
            if (!(++regs[TMR0]))
               regs[INTCON] |= T0IF;
            }
         else
            {
            if (++tmr0_prescale_counter >= tmr0_prescale)
               {
               if (!(++regs[TMR0]))
                  regs[INTCON] |= T0IF;
               tmr0_prescale_counter = 0;
               }
            }
         }
      }
   last_t0cki = input_ports[0];  /* setup for next edge detect */
#endif  /* PICTYPE_16F648 */
  /* NOTE: I'd love to have an OR... */
#ifdef PICTYPE_16F84A
   if ((!sleepmode)                   /* TIMER0 does not operate in sleep mode */
           && (!tmr0_inhibit)         /* and not inhibited */
           && (regs[OPTION] & T0CS))  /* if Timer 0 based on T0CKI transition */
      {
      if (((regs[OPTION] & T0SE) == (last_t0cki & T0SE))  /* if last was correct high/low state */
               && ((input_ports[0] & T0SE) != (last_t0cki & T0SE)))  /* and this is a transition */
         {
         if (regs[OPTION] & PSA)  /* if prescale assigned to WDT */
            {
            if (!(++regs[TMR0]))
               regs[INTCON] |= T0IF;
            }
         else
            {
            if (++tmr0_prescale_counter >= tmr0_prescale)
               {
               if (!(++regs[TMR0]))
                  regs[INTCON] |= T0IF;
               tmr0_prescale_counter = 0;
               }
            }
         }
      }
   last_t0cki = input_ports[0];  /* setup for next edge detect */
#endif  /* PICTYPE_16F84A */
#ifdef HAS_IOC
   #ifdef PICTYPE_12F675
   check_ioc();
   #endif  /* PICTYPE_12F675 */
#endif  /* HAS_IOC */
   }

#ifndef PICTYPE_16F84A
void porta_bit5(mode)
      /* 12F675: GP5 / T1CKI / OSC1 / CLKIN */
      /* 16F648: RA5 / MCLR / Vpp */
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[0][5],mode,0,5);
#ifdef PICTYPE_16F648
   if ((configuration & CONFIG_MCLRE)  /* if A5 is MCLR */
            && (!(input_ports[0] & BIT5)))  /* and MCLR low */
      do_mclr_reset = TRUE;
#endif  /* PICTYPE_16F648 */
#ifdef HAS_IOC
   #ifdef PICTYPE_12F675
   check_ioc();
   #endif  /* PICTYPE_12F675 */
#endif  /* HAS_IOC */
   }
#endif  /* PICTYPE_16F84A */

#ifdef PICTYPE_16F648
void porta_bit6(mode)
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[0][6],mode,0,6);
   }

void porta_bit7(mode)
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[0][7],mode,0,7);
   }
#endif  /* PICTYPE_16F648 */

#ifdef PICTYPE_16F877
void porta_bit7(mode)  /* use this for MCLR */
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[0][7],mode,0,7);
   if (!(input_ports[0] & BIT7))  /* if MCLR low */
      do_mclr_reset = TRUE;
   }
#endif  /* PICTYPE_16F877 */

/* I'd love to have an OR... */
#ifdef PICTYPE_16F84A
void porta_bit7(mode)  /* use this for MCLR */
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[0][7],mode,0,7);
   if (!(input_ports[0] & BIT7))  /* if MCLR low */
      do_mclr_reset = TRUE;
   }
#endif  /* PICTYPE_16F84A */

#ifdef HAS_PORTB
/*
 *  NOTE:  It's not obvious from the documentation, but it seems that
 *         the INT function of RB0 is independent of the TRIS value.
 *         Therefore, this function is somewhat different from the rest
 *         of the port bit functions.
 */
void portb_bit0(mode)  /* also INT pin */
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[1][0],mode,1,0);
   if (regs[OPTION] & INTEDG)
      {
      if ((!(last_portb_in & BIT0)) && (input_ports[1] & BIT0))  /* rising edge */
         regs[INTCON] |= INTF;
      }
   else
      {
      if ((last_portb_in & BIT0) && (!(input_ports[1] & BIT0)))  /* falling edge */
         regs[INTCON] |= INTF;
      }
   last_portb_in = input_ports[1];  /* setup for next edge detect */
   }

void portb_bit1(mode)
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[1][1],mode,1,1);
   }

void portb_bit2(mode)
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[1][2],mode,1,2);
   }

void portb_bit3(mode)
      /* 16F648: CCP1 */
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[1][3],mode,1,3);
#ifdef PICTYPE_16F648
   if ((ccp1_mode == CCPMODE_CAPTURE) && (last_ccp1 != (input_ports[1] & BIT3)))
            /* if doing capture, and we have a transition */
      {
      if (((last_ccp1) && (ccp1_fn == CCPFN_FALLING))  /* if high to low and looking for falling */
              || ((!last_ccp1) && (ccp1_fn != CCPFN_FALLING)))  /* or low to high and looking for rising */
         {
         if (++ccp1_count >= ccp_prescale_table[ccp1_fn]) /* if time to capture */
            {
            ccp1_count = 0;  /* reset prescalar */
            *(WORD *)&regs[CCPR1L] = *(WORD *)&regs[TMR1L];
            regs[PIR1] |= CCP1IF;
            }
         }  /* if correct transition */
      last_ccp1 = input_ports[1] & BIT3;
      }  /* if doing capture and have a transition */
#endif  /* PICTYPE_16F648 */
   }

void portb_bit4(mode)
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[1][4],mode,1,4);
   }

void portb_bit5(mode)
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[1][5],mode,1,5);
   }

void portb_bit6(mode)
      /* 16F648: T1CKI */
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[1][6],mode,1,6);
#ifdef PICTYPE_16F648
   if ((regs[T1CON] & T1OSCEN_TMR1CS) == T1OSCEN_OFF_TMR1CS_ON)  /* if incrementing TMR1 from T1CKI */
      {
      if ((last_t1cki ^ t1cki_edge) != (input_ports[1] & BIT6))  /* if edge detect */
         {
         if (last_t1cki ^ t1cki_edge)  /* if this was a "high" to "low" transition */
            {
            if (t1cki_edge)  /* if this is the low-to-high we need before starting to inc TMR1 */
               t1cki_edge = 0;  /* clear flag, next transition will be an INC */
            else
               {
               if (++tmr1_prescale_counter >= tmr1_prescale)
                                   /* prescale keeps running in sleepmode */
                  {
                  tmr1_prescale_counter = 0;  /* reset prescale counter */
                  if (((regs[T1CON] & T1SYNC) || (!sleepmode)) && (regs[T1CON] & TMR1ON))
                     if (++(*(WORD *)&regs[TMR1L]) == 0)
                        regs[PIR1] |= TMR1IF;
                  }
               }  /* if t1cki_edge ... else */
            }  /* if (last_t1cki ^ t1cki_edge) */
         last_t1cki = input_ports[1] & BIT6;  /* setup for next edge detect */
         }
      }
#endif  /* PICTYPE_16F648 */
   }

void portb_bit7(mode)
      /* 16F648: T1OSI */
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[1][7],mode,1,7);
#ifdef PICTYPE_16F648
   if ((regs[T1CON] & T1OSCEN_TMR1CS) == T1OSCEN_ON_TMR1CS_ON)  /* if incrementing TMR1 from T1OSI */
      {
      if ((last_t1osi ^ t1osi_edge) != (input_ports[1] & BIT7))  /* if edge detect */
         {
         if (last_t1osi ^ t1osi_edge)  /* if this was a "high" to "low" transition */
            {
            if (t1osi_edge)  /* if this is the low-to-high we need before starting to inc TMR1 */
               t1osi_edge = 0;  /* clear flag, next transition will be an INC */
            else
               {
               if (++tmr1_prescale_counter >= tmr1_prescale)
                                   /* prescale keeps running in sleepmode */
                  {
                  tmr1_prescale_counter = 0;  /* reset prescale counter */
                  if (((regs[T1CON] & T1SYNC) || (!sleepmode)) && (regs[T1CON] & TMR1ON))
                     if (++(*(WORD *)&regs[TMR1L]) == 0)
                        regs[PIR1] |= TMR1IF;
                  }
               }  /* if t1osi_edge ... else */
            }  /* if (last_t1osi ^ t1osi_edge) */
         last_t1osi = input_ports[1] & BIT7;  /* setup for next edge detect */
         }
      }
#endif  /* PICTYPE_16F648 */
   }
#endif  /* HAS_PORTB */

#ifdef HAS_PORTC
void portc_bit0(mode)
     /* 16F877 : RC0 / T1CKI */
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[2][0],mode,2,0);
#ifdef PICTYPE_16F877
   if ((regs[T1CON] & T1OSCEN_TMR1CS) == T1OSCEN_OFF_TMR1CS_ON)  /* if incrementing TMR1 from T1CKI */
      {
      if ((last_t1cki ^ t1cki_edge) != (input_ports[2] & BIT0))  /* if edge detect */
         {
         if (last_t1cki ^ t1cki_edge)  /* if this was a "high" to "low" transition */
            {
            if (t1cki_edge)  /* if this is the low-to-high we need before starting to inc TMR1 */
               t1cki_edge = 0;  /* clear flag, next transition will be an INC */
            else
               {
               if (++tmr1_prescale_counter >= tmr1_prescale)
                                   /* prescale keeps running in sleepmode */
                  {
                  tmr1_prescale_counter = 0;  /* reset prescale counter */
                  if (((regs[T1CON] & T1SYNC) || (!sleepmode)) && (regs[T1CON] & TMR1ON))
                     if (++(*(WORD *)&regs[TMR1L]) == 0)
                        regs[PIR1] |= TMR1IF;
                  }
               }  /* if t1cki_edge ... else */
            }  /* if (last_t1cki ^ t1cki_edge) */
         last_t1cki = input_ports[2] & BIT0;  /* setup for next edge detect */
         }
      }
#endif  /* PICTYPE_16F877 */
   }

void portc_bit1(mode)
     /* 16F877: RC1 / T1OSI / CCP2 */
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[2][1],mode,2,1);
#ifdef PICTYPE_16F877
   if ((regs[T1CON] & T1OSCEN_TMR1CS) == T1OSCEN_ON_TMR1CS_ON)  /* if incrementing TMR1 from T1OSI */
      {
      if ((last_t1osi ^ t1osi_edge) != (input_ports[2] & BIT1))  /* if edge detect */
         {
         if (last_t1osi ^ t1osi_edge)  /* if this was a "high" to "low" transition */
            {
            if (t1osi_edge)  /* if this is the low-to-high we need before starting to inc TMR1 */
               t1osi_edge = 0;  /* clear flag, next transition will be an INC */
            else
               {
               if (++tmr1_prescale_counter >= tmr1_prescale)
                                   /* prescale keeps running in sleepmode */
                  {
                  tmr1_prescale_counter = 0;  /* reset prescale counter */
                  if (((regs[T1CON] & T1SYNC) || (!sleepmode)) && (regs[T1CON] & TMR1ON))
                     if (++(*(WORD *)&regs[TMR1L]) == 0)
                        regs[PIR1] |= TMR1IF;
                  }
               }  /* if t1osi_edge ... else */
            }  /* if (last_t1osi ^ t1osi_edge) */
         last_t1osi = input_ports[2] & BIT1;  /* setup for next edge detect */
         }
      }
#endif  /* PICTYPE_16F877 */
   /*
    *  NOTE: I'm not sure if both T1OSI and CCP2 both run at the same time
    *        from PortC bit 1.  Clues?
    */
#ifdef PICTYPE_16F877
   if ((ccp2_mode == CCPMODE_CAPTURE) && (last_ccp2 != (input_ports[2] & BIT1)))
            /* if doing capture, and we have a transition */
      {
      if (((last_ccp2) && (ccp2_fn == CCPFN_FALLING))  /* if high to low and looking for falling */
              || ((!last_ccp2) && (ccp2_fn != CCPFN_FALLING)))  /* or low to high and looking for rising */
         {
         if (++ccp2_count >= ccp_prescale_table[ccp2_fn]) /* if time to capture */
            {
            ccp2_count = 0;  /* reset prescalar */
            *(WORD *)&regs[CCPR2L] = *(WORD *)&regs[TMR1L];
            regs[PIR2] |= CCP2IF;
            }
         }  /* if correct transition */
      last_ccp2 = input_ports[2] & BIT1;
      }  /* if doing capture and have a transition */
#endif  /* PICTYPE_16F877 */
   }

void portc_bit2(mode)
   /* 16F877: RC2 / CCP1 */
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[2][2],mode,2,2);
#ifdef PICTYPE_16F877
   if ((ccp1_mode == CCPMODE_CAPTURE) && (last_ccp1 != (input_ports[2] & BIT2)))
            /* if doing capture, and we have a transition */
      {
      if (((last_ccp1) && (ccp1_fn == CCPFN_FALLING))  /* if high to low and looking for falling */
              || ((!last_ccp1) && (ccp1_fn != CCPFN_FALLING)))  /* or low to high and looking for rising */
         {
         if (++ccp1_count >= ccp_prescale_table[ccp1_fn]) /* if time to capture */
            {
            ccp1_count = 0;  /* reset prescalar */
            *(WORD *)&regs[CCPR1L] = *(WORD *)&regs[TMR1L];
            regs[PIR1] |= CCP1IF;
            }
         }  /* if correct transition */
      last_ccp1 = input_ports[2] & BIT2;
      }  /* if doing capture and have a transition */
#endif  /* PICTYPE_16F877 */
   }

void portc_bit3(mode)
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[2][3],mode,2,3);
   }

void portc_bit4(mode)
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[2][4],mode,2,4);
   }

void portc_bit5(mode)
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[2][5],mode,2,5);
   }

void portc_bit6(mode)
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[2][6],mode,2,6);
   }

void portc_bit7(mode)
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[2][7],mode,2,6);
   }
#endif  /* HAS_PORTC */

#ifdef HAS_PORTD
void portd_bit0(mode)
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[3][0],mode,3,0);
   }

void portd_bit1(mode)
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[3][1],mode,3,1);
   }

void portd_bit2(mode)
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[3][2],mode,3,2);
   }

void portd_bit3(mode)
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[3][3],mode,3,3);
   }

void portd_bit4(mode)
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[3][4],mode,3,4);
   }

void portd_bit5(mode)
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[3][5],mode,3,5);
   }

void portd_bit6(mode)
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[3][6],mode,3,6);
   }

void portd_bit7(mode)
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[3][7],mode,3,7);
   }
#endif  /* HAS_PORTD */

#ifdef HAS_PORTE
void porte_bit0(mode)
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[4][0],mode,4,0);
   }

void porte_bit1(mode)
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[4][1],mode,4,1);
   }

void porte_bit2(mode)
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[4][2],mode,4,2);
   }
#endif  /* HAS_PORTE */

void empty_port(){}   /* something to put a pointer to */

void (*portbitfns[NUM_BYTE_PORTS*8])() =
   {
   porta_bit0,
   porta_bit1,
   porta_bit2,
   porta_bit3,
   porta_bit4,
#ifdef PICTYPE_16F84A
   empty_port,   /* bit 5 */
#else
   porta_bit5,
#endif  /* PICTYPE_16F84A */
#ifdef PICTYPE_16F648
   porta_bit6,
#else
   empty_port,   /* bit 6 */
#endif  /* PICTYPE_16F648 */
#ifdef PICTYPE_12F675
   empty_port    /* bit 7 */
#else
   porta_bit7    /* MCLR for 16F877, 16F84A, regular I/O port for 16F648 */
#endif  /* PICTYPE_12F675 */
#ifdef HAS_PORTB
   ,
   portb_bit0,
   portb_bit1,
   portb_bit2,
   portb_bit3,
   portb_bit4,
   portb_bit5,
   portb_bit6,
   portb_bit7
#endif  /* HAS_PORTB */
#ifdef HAS_PORTC
   ,
   portc_bit0,
   portc_bit1,
   portc_bit2,
   portc_bit3,
   portc_bit4,
   portc_bit5,
   portc_bit6,
   portc_bit7
#endif  /* HAS_PORTC */
#ifdef HAS_PORTD
   ,
   portd_bit0,
   portd_bit1,
   portd_bit2,
   portd_bit3,
   portd_bit4,
   portd_bit5,
   portd_bit6,
   portd_bit7
#endif  /* HAS_PORTD */
#ifdef HAS_PORTE
   ,
   porte_bit0,
   porte_bit1,
   porte_bit2,
   empty_port,   /* bit 3 */
   empty_port,   /* bit 4 */
   empty_port,   /* bit 5 */
   empty_port,   /* bit 6 */
   empty_port    /* bit 7 */
#endif  /* HAS_PORTE */
   };
