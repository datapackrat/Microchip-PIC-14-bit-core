/*
 *  Hi Tech PIC C LITE compiler, V8.02
 */
#include <pic.h>

unsigned char i, j, k, l;

main()
   {
   l = 0;
   while (l < 255)
      {
      k = 0;
      while (k < 255)
         {
         j = 0;
         while (j < 255)
            {
            i = 0;
            while (i < 255)
               i++;
            j++;
            }
         k++;
         }
      l++;
      }
   for ( ; ; )
      ;
   }

