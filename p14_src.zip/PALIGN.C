#ifdef NEVERDEF
/****************************************************************************
 ****************************************************************************
 *                                                                          *
 *   WARNING!                                                               *
 *                                                                          *
 *   I've discovered a bug in the code optimizer.  A definition like:       *
 *      #define TESTBITS (BIT1|BIT2)                                        *
 *   can produce incorrect code output from the optimizer when TESTBITS     *
 *   is used.                                                               *
 *                                                                          *
 *   Instead, use a definition like:                                        *
 *      #define TESTBITS 0x05  /* (BIT1|BIT2) */                            *
 *   Yes, that's not as "ideal", but it will save a WORLD of problems!      *
 *                                                                          *
 ****************************************************************************
 ****************************************************************************/
#endif

/*
 *  PIC emulator.  General utility program.
 *  Check alignment of important variables, and re-compile/re-link as needed
 *  to optimize DWORD alignment (runs much faster on modern 32-bit chips).
 *
 *  Copyright (c) 2001-2004
 *
 *  Released under the GNU GPL.  See http://www.gnu.org/licenses/gpl.txt
 *
 *  This program is part of PICEMU
 *
 *  PICEMU is free software; you can redistribute it and/or modify it under
 *  the terms of the GNU General Public License as published by the Free
 *  Software Foundatation; either version 2 of the License, or any later
 *  version.
 *
 *  PICEMU is distributed in the hope that it will be useful, but WITHOUT
 *  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 *  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 *  for more details.
 *
 *
 *  Revision history
 *
 *  Date      Comments
 *  --------  ---------------------------------------------
 *  11/16/01  Original code
 *  3/xx/02   Add code alignment via /t switch
 *  4/18/02   Split (PSHELL, PSHELL2) for compiler limits
 *  1/14/04   Change from 16F628 to it's big brother 16F648A
 *  3/15/04   Source code unification for 14-bit core programs.
 */

/*
 *  NOTE:
 *
 *  Using a 32-bit chip, memory access is on DWORD boundaries, with smaller
 *  entries parsed out of the DWORD as necessary.
 *
 *  Thus, if our major data structures and variables (i.e the ones used
 *  millions of times a second in the interpreter loop) are aligned so that
 *  all bytes of the data element are in the same DWORD, the program will run
 *  much faster.  By 40% or so!
 *
 *  So, this program will "automagically" look at the PCCL link map and, if
 *  necessary, use the built-in #ifdef's to align the major data elements
 *  on DWORD boundaries.
 *
 *  The downside is that if you move stuff around too much or add too many
 *  new variables, this program won't be bright enough to do it's job.
 *
 *  I don't want to discourage you from changing things, however.  So, feel
 *  free to modify this program to accomidate any changes, or to "hand
 *  optimize" variable placement yourself -- that's what I did in the early
 *  development stages.
 *
 *  The variables you want aligned are:
 *     PICOPS -- the pointers to the emulation functions
 *     XLATE_REGS
 *     READREGS
 *     WRITEREGS
 *     MEMORY
 *     REGS
 *     EEPROM (if any)
 *     REGVAL
 *     STACK
 *     OPCODE
 *     IP
 *     W
 *     FILENUM
 *     DEST
 *     FILENUM_TEMP
 *     FILENUM_TEMP2
 *     TEMP1
 *     TEMP2
 *     BREAKPOINT
 *     SLEEPMODE
 *     INTERRUPT_PENDING
 *     NOTICED_INTERRUPT
 *     LAST_*
 *     CCP*
 *     *_EDGE
 *     TMR0_*
 *     TMR1_*
 *     TMR2_*
 *     ADC_*
 *     EECON*
 *     INSTRUCTIONCOUNT
 *     BREAKCOUNT
 *     WHERE*
 *     TSR_*
 *     TX_*
 *     RC_*
 *     NUM_REG_BREAKPOINTS
 *     REG_BREAKS
 *     NUM_MEM_BREAKPOINTS
 *     MEM_BREAKS
 *     SHOW_PORTS
 *     REG_BREAKPOINTS_ON
 *     NUM_REG_BREAKS
 *
 *  Yup, that's a *LOT* of variables.  Fortunately, it's easier than it
 *  seems, because almost all "important" variables are grouped together, and
 *  each variable has an associated "align" variable (or two...) that makes
 *  the "package" take up 4 bytes, so that things tend to stay aligned.
 *
 *  Try to keep that in mind when programming, and things should be pretty
 *  easy.
 *
 *  It helps to know how the linker (PCCL) lays variables out in memory.
 *  For a statement like:
 *     PCCL P14 P14_2 P14REGS PSHELL PSHELL2 P14ASM
 *  the resulting data memory map is:
 *      <P14 initalized variables, including strings,
 *            in "top to bottom" order that they appear in P14>
 *      <P14_2 initalized variables, including strings,
 *            in "top to bottom" order that they appear in P14_2>
 *      <P14REGS initalized variables, including strings>
 *            in "top to bottom" order that they appear in P14REGS>
 *      <PSHELL initalized variables, including strings>
 *            in "top to bottom" order that they appear in PSHELL>
 *      <PSHELL2 initalized variables, including strings>
 *            in "top to bottom" order that they appear in PSHELL2>
 *      <P14ASM initalized variables, including strings>
 *            in "top to bottom" order that they appear in P14ASM>
 *      <library initalized variables, including strings>
 *      <P14 uninitalized variables
 *            in "top to bottom" order that they appear in P14>
 *      <P14_2 uninitalized variables
 *            in "top to bottom" order that they appear in P14_2>
 *      <P14REGS uninitalized variables
 *            in "top to bottom" order that they appear in P14REGS>
 *      <PSHELL uninitalized variables
 *            in "top to bottom" order that they appear in PSHELL>
 *      <PSHELL2 uninitalized variables
 *            in "top to bottom" order that they appear in PSHELL2>
 *      <P14ASM uninitalized variables
 *            in "top to bottom" order that they appear in P14ASM>
 *
 *  Thus, when trying to align initalized variables, you must add initalized
 *  variables in the correct location(s).  And when trying to align
 *  uninitalized variables, you must add uninitalized variables.
 *
 *  Also, aligning a variable will also move all "downstream" variables, and
 *  so even if they were aligned before, they might need to be "realigned"
 *  due to alignment of variables upstream.
 *
 *  This program only does data alignment.  There can also be efficiencies,
 *  not as dramatic as data efficiencies, by code alignment (i.e. as few
 *  instructions as possible cross DWORD boundaries).  This sort of alignment
 *  is beyond the scope of this program, or really any program I can think of.
 *  You can "tweak" the last bit of performance out of adding/removing the
 *  comment designation (the ';' at the start of the line) on the NOP's
 *  in main() in P12 / P14 and in code_alignment_2() in P12REGS / P14REGS.
 *  The alignment in main() will have the biggest effect, with final tweaks
 *  being done in code_alignment_2().
 *
 *  How do you tell if you've got a good "tweak"?  Run a test program and
 *  note the IPS.  "Tweak" and test until you're satisfied.
 */

#include <picemu.h>  /* just want TYPEDEF's and such from this */

/*	a 'FILE' is simply an integer is this implimentation	*/
typedef int  FILE;   /* borrow this from STDIO.H, so I don't duplicate TRUE, etc */


WORD pspaddr;  /* our PSP, used for DOS shell */

BYTE null_fcb[16] =
   {
   0x00,       /* normal FCB */
   0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20,  /* blank filename */
   0x20, 0x20, 0x20,  /* blank extension */
   0x00, 0x00, 0x00, 0x00  /* blank data */
   };

BYTE cmdline_len;
BYTE cmdline[STRING_SIZE];  /* build the commandline here */
BYTE pic_cmdline[STRING_SIZE];  /* saved cmdline to compile main PIC file */
BYTE regs_cmdline[STRING_SIZE];  /* saved cmdline to compile PxxREGS file */
BYTE shell_cmdline[STRING_SIZE];  /* saved cmdline to compile PSHELL file */
BYTE asm_cmdline[STRING_SIZE];  /* saved cmdline to compile PxxASM file */
BYTE link_cmdline[STRING_SIZE];  /* save cmdline to link Pxx file */
BYTE tempstr[STRING_SIZE];

struct execstruct
   {
   WORD env_seg;
   BYTE *cmdline;
   WORD cmdline_seg;
   BYTE *fcb1;
   WORD fcb1_seg;
   BYTE *fcb2;
   WORD fcb2_seg;
   } dos4b_block =
   {
   0,            /* environment seg */
   cmdline,      /* command line */
   0,            /* cmdline seg, fill in later with our data segment */
   null_fcb,     /* blank FCB */
   0,            /* FCB1 seg, fill in later with our data segment */
   null_fcb,     /* blank FCB */
   0             /* FCB2 seg, fill in later with our data segment */
   };

FILE *filein;
BYTE linein[STRING_SIZE];
BYTE mapfile[STRING_SIZE];

#define NUM_PICS 5
#define P509 0
#define P877 1
#define P84 2
#define P648 3
#define P675 4
WORD pic_index;  /* 0=P509, 1=P877, 2=P84, 3=P648, 4=P675, ... */
struct picfiles
   {
   BYTE *pic_name;
   BYTE *main_name;
   BYTE *main2_name;
   BYTE *regs_name;
   BYTE *shell_name;
   BYTE *shell2_name;
   BYTE *asm_name;
   BYTE *cod_name;
   BYTE *config_str;
   BYTE *run_name;
   BYTE *tim_name;
   } pic_files[NUM_PICS] =
{
   { "p509","p12", "p12_2", "p12regs", "pshell", "pshell2", "p12asm", "p509.cod","1b",   "p509.exe","p509.tim"},
   { "p877","p14", "p14_2", "p14regs", "pshell", "pshell2", "p14asm", "p877.cod","3ffa", "p877.exe","p877.tim"},
   { "p84", "p14", "p14_2", "p14regs", "pshell", "pshell2", "p14asm", "p84.cod", "3ffa", "p84.exe", "p84.tim" },
   { "p648","p14", "p14_2", "p14regs", "pshell", "pshell2", "p14asm", "p648.cod","3fea", "p648.exe","p648.tim"},
   { "p675","p14", "p14_2", "p14regs", "pshell", "pshell2", "p14asm", "p675.cod","31f2", "p675.exe","p675.tim"}
};

/*
 *  The following values are the linkmap offsets of the variables to be
 *  aligned.
 */
WORD picops_alignment;      /* align the PICOPS pointer array */
WORD regs_alignment;     /* align initzlied data AFTER P12.C / P14.C */
                         /* (XLATE_REGS[], READREGS[], WRITEREGS[]) */
/* WORD shell_data_alignment; */ /* align initzlied data after PSHELL.C */
WORD pasm_data_alignment;  /* align uninitalized data after PxxASM.C */
   /* NOTE: This is initalized aligment data, but it's at the end of the
    *       initalized data, and thus will align the uninitalized data that
    *       follows.
    */
WORD stack_alignment;    /* align the stack (uninitalized data) */

WORD picops_align_value;  /* how many bytes to move the PICOPS pointer array */
WORD regs_align_value;  /* how many bytes to move the init'ed data after Pxx.C */
/* WORD shell_dataalign_value; */  /* how many bytes to move the init'ed data after PSHELL.C */
WORD pasm_dataalign_value;  /* how many bytes to move the uninit'ed data after PxxASM.C */
WORD stack_align_value;  /* how many bytes to the move the stack (&etc) */
WORD total_align_value;  /* total "current" alignment as we pass through the */
                         /* data segment, added to current linkmap values to */
                         /* figure out new alignment */

#define MAX_ALIGN_NOPS 63
BYTE output_name_1[] = "palign01.out";
BYTE output_name_2[] = "palign02.out";
BYTE cmd_name_1[] = "palign01.cmd";
BYTE cmd_name_2[] = "palign02.cmd";
DWORD main_times[MAX_ALIGN_NOPS+1];
DWORD regs_times[MAX_ALIGN_NOPS+1];
DWORD throttle_times[MAX_ALIGN_NOPS+1];
DWORD tmain_times[MAX_ALIGN_NOPS+1];
WORD best_main;
WORD best_regs;
WORD best_throttle;
DWORD maxthrottle, maxmain, mainthrottle;
WORD i, j;
DWORD ltemp1;
FILE *fileout;
DWORD get_first_time();
DWORD get_second_time();


BYTE *strlwr();
WORD strcmpi();
WORD findstring(), get_dosver(), adjust_memory_allocation();

WORD print_offsets = FALSE;
WORD do_timing = FALSE;
WORD timing_size = 15;

BYTE version[] = "Palign Version 1.19\n";
BYTE copyright[] =
"Copyright (c) 2001-2004.\nThis program is licensed under the GNU GPL.  www.gnu.org/licenses/gpl.txt\n\n";



main(argc,argv)
   WORD argc;
   BYTE *argv[];
   {
   puts(version);
   puts(copyright);
   if (get_dosver() < 3)  /* you can tell I'm completely insane -- */
                          /* I'm checking for DOS verison 1.x or 2.x! */
      {
      puts("Gaaa... why aren't you running at least DOS 3.0?\n");
      exit(1);
      }
   if (argc < 2)
      help();  /* this never returns */
   if ((argc > 2) && (argv[2][0] == '-'))
      {
      if (toupper(argv[2][1]) == 'P')
         print_offsets = TRUE;
      else
         if (toupper(argv[2][1]) == 'T')
            {
            do_timing = TRUE;
            if (argv[2][2])  /* if a number associated! */
               {
               sscanf(&argv[2][2],"%d",&timing_size);
               if ((timing_size & (timing_size - 1))  /* if not a power of 2! */
                      || (timing_size < 4)
                      || (timing_size > MAX_ALIGN_NOPS+1))
                  help();
               else
                  timing_size--;  /* want one less than #bytes to use */
               }
            }
         else
            help();
      }
   if ((argc > 3) && (argv[3][0] == '-'))
      {
      if (toupper(argv[3][1]) == 'P')
         print_offsets = TRUE;
      else
         if (toupper(argv[3][1]) == 'T')
            do_timing = TRUE;
         else
            help();
      }
   for (pic_index = P509; pic_index < NUM_PICS; pic_index++)
      if (strcmpi(argv[1],pic_files[pic_index].pic_name) == 0)
         break;
   if (pic_index == NUM_PICS)  /* not found! */
      help();  /* this never returns */
   if (adjust_memory_allocation())
      {
      puts("Oops!  Memory allocation error!\n");
      exit(1);
      }
   strcpy(mapfile,pic_files[pic_index].pic_name);
   strcat(mapfile,".opt");
   if ((filein = fopen(mapfile,"r")) == NULL)
      {
      printf("Error:  linkmap file %s not found.\n",mapfile);
      exit(1);
      }
   while (TRUE)  /* use BREAK to get out */
      {
      if (fgets(linein,STRING_SIZE,filein) == NULL)
         {
         printf("Error: linkmap file %s invalid\n -- symbols by address not found.",
              mapfile);
         exit(1);
         }
      if (findstring("	Addresses",linein) != -1)
         break;
      }
   /*
    *  First, find PICOPS
    */
   while (TRUE)  /* use BREAK to get out */
      {
      if (fgets(linein,STRING_SIZE,filein) == NULL)
         {
         printf("Error: linkmap file %s invalid\n -- PICOPS not found.",
              mapfile);
         exit(1);
         }
      if (findstring(" PICOPS",linein) != -1)
         break;
      }
   sscanf(&linein[3],"%x",&picops_alignment);
   if (print_offsets)
      printf("PICOPS ofs = %04x + total_align_value(=%04x) = %04x ",
         picops_alignment,total_align_value,picops_alignment+total_align_value);
   picops_alignment += total_align_value;
   if (picops_alignment & 3)
      {
      picops_align_value = 4 - (picops_alignment & 3);
      if (print_offsets)
         printf(" align by %d bytes = %04x",picops_align_value,picops_alignment+picops_align_value);
      }
   if (print_offsets)
      printf("\n");
   total_align_value += picops_align_value;
   /*
    *  Next, find regs_alignment
    *  (align XLATE_REGS[], READREGS[], WRITEREGS[])
    */
   while (TRUE)  /* use BREAK to get out */
      {
      if (fgets(linein,STRING_SIZE,filein) == NULL)
         {
         printf("Error: linkmap file %s invalid\n -- XLATE_REGS not found.",
              mapfile);
         exit(1);
         }
      if (findstring(" XLATE_REGS",linein) != -1)
         break;
      }
   sscanf(&linein[3],"%x",&regs_alignment);
   if (print_offsets)
      printf("XLATE_REGS = %04x + total_align_value(=%04x) = %04x ",
         regs_alignment,total_align_value,regs_alignment+total_align_value);
   regs_alignment += total_align_value;
   if (regs_alignment & 3)
      {
      regs_align_value = 4 - (regs_alignment & 3);
      if (print_offsets)
         printf(" align by %d bytes = %04x",regs_align_value,regs_alignment+regs_align_value);
      }
   if (print_offsets)
      printf("\n");
   total_align_value += regs_align_value;
   /*
    *  Next, find pasm_data_alignment
    *  (align MEMORY[], etc)
    */
   while (TRUE)  /* use BREAK to get out */
      {
      if (fgets(linein,STRING_SIZE,filein) == NULL)
         {
         printf("Error: linkmap file %s invalid\n -- MEMORY not found.",
              mapfile);
         exit(1);
         }
      if (findstring(" MEMORY",linein) != -1)
         break;
      }
   sscanf(&linein[3],"%x",&pasm_data_alignment);
   if (print_offsets)
      printf("MEMORY = %04x + total_align_value(=%04x) = %04x ",
         pasm_data_alignment,total_align_value,pasm_data_alignment+total_align_value);
   pasm_data_alignment += total_align_value;
   if (pasm_data_alignment & 3)
      {
      pasm_dataalign_value = 4 - (pasm_data_alignment & 3);
      if (print_offsets)
         printf(" align by %d bytes = %04x",pasm_dataalign_value,pasm_data_alignment+pasm_dataalign_value);
      }
   if (print_offsets)
      printf("\n");
   total_align_value += pasm_dataalign_value;
   /*
    *  Next, find stack_alignment
    *  (align STACK[], etc)
    */
   while (TRUE)  /* use BREAK to get out */
      {
      if (fgets(linein,STRING_SIZE,filein) == NULL)
         {
         printf("Error: linkmap file %s invalid\n -- STACK not found.",
              mapfile);
         exit(1);
         }
      if (findstring(" STACK",linein) != -1)
         break;
      }
   fclose(filein);
   sscanf(&linein[3],"%x",&stack_alignment);
   if (print_offsets)
      printf("STACK = %04x + total_align_value(=%04x) = %04x ",
         stack_alignment,total_align_value,stack_alignment+total_align_value);
   stack_alignment += total_align_value;
   if (stack_alignment & 3)
      {
      stack_align_value = 4 - (stack_alignment & 3);
      if (print_offsets)
         printf(" align by %d bytes = %04x",stack_align_value,stack_alignment+stack_align_value);
      }
   if (print_offsets)
      printf("\n");
   total_align_value += stack_align_value;

   if (print_offsets)
      {
      printf("Press any key to continue....");
      ci();
      printf("\r                             \n");
      }

   sprintf(cmdline," %s",pic_files[pic_index].main_name);
   if (picops_align_value)  /* if need to align PICOPS */
      {
      if (picops_align_value & 1)
         strcat(cmdline," -nALIGN_PICOPS_1");
      if (picops_align_value & 2)
         strcat(cmdline," -nALIGN_PICOPS_2");
      }
   if (stack_align_value)  /* if need to align STACK */
      {
      if (stack_align_value & 1)
         strcat(cmdline," -nALIGN_STACK_1");
      if (stack_align_value & 2)
         strcat(cmdline," -nALIGN_STACK_2");
      }
   strcpy(pic_cmdline,cmdline);  /* save this for later */
   strcat(cmdline,"\r");
   if ((picops_align_value) || (stack_align_value))
      run_program("cc.exe");
   sprintf(cmdline," %s",pic_files[pic_index].regs_name);
   if (regs_align_value)  /* if need to align XLATE_REGS[], etc */
      {
      if (regs_align_value & 1)
         strcat(cmdline," -nALIGN_REGS_1");
      if (regs_align_value & 2)
         strcat(cmdline," -nALIGN_REGS_2");
      }
   strcpy(regs_cmdline,cmdline);  /* save this for later */
   strcat(cmdline,"\r");
   if (regs_align_value)  /* if need to align XLATE_REGS[], etc */
      run_program("cc.exe");
   sprintf(cmdline," %s",pic_files[pic_index].asm_name);
   if (pasm_dataalign_value)  /* if need to align MEMORY[], etc */
      {
      if (pasm_dataalign_value & 1)
         strcat(cmdline," -nALIGN_ASM_1");
      if (pasm_dataalign_value & 2)
         strcat(cmdline," -nALIGN_ASM_2");
      }
   strcpy(asm_cmdline,cmdline);
   strcat(cmdline,"\r");
   if (pasm_dataalign_value)  /* if need to align MEMORY[], etc */
      run_program("cc.exe");
   sprintf(cmdline," %s %s %s %s %s %s -o%s.exe -_ -p%s.map\r",
             pic_files[pic_index].main_name,
             pic_files[pic_index].main2_name,
             pic_files[pic_index].regs_name,
             pic_files[pic_index].shell_name,
             pic_files[pic_index].shell2_name,
             pic_files[pic_index].asm_name,
             pic_files[pic_index].pic_name,
             pic_files[pic_index].pic_name);
   strcpy(link_cmdline,cmdline);  /* save this for later */
   if (total_align_value)  /* if any alignment done */
      run_program("pccl.exe");
   else
      printf("Nothing to do -- %s already aligned.\n",pic_files[pic_index].pic_name);
   if (!do_timing)
      exit(0);  /* we're done */
/*
 *  Here, we're going for fastest executing code alignment
 *
 *  First, find best NOPs at start of MAIN
 */
   create_cmdfiles();  /* if error, does not return */
   for (best_main = 0; best_main <= timing_size; best_main++)
      {
      unlink(output_name_1);
      unlink(output_name_2);
      strcpy(cmdline,pic_cmdline);  /* get basic command line */
      if (best_main & 1)
         strcat(cmdline," -nM_1B");
      if (best_main & 2)
         strcat(cmdline," -nM_2B");
      if (best_main & 4)
         strcat(cmdline," -nM_4B");
      if (best_main & 8)
         strcat(cmdline," -nM_8B");
      if (best_main & 16)
         strcat(cmdline," -nM_16B");
      if (best_main & 32)
         strcat(cmdline," -nM_32B");
      strcat(cmdline,"\r");
      run_program("cc.exe");
      strcpy(cmdline,link_cmdline);
      run_program("pccl.exe");
      strcpy(cmdline," -palign01.cmd /none\r");
      run_program(pic_files[pic_index].run_name);
      main_times[best_main] = get_first_time();
      }
   fileout = creat(pic_files[pic_index].tim_name);
   strcpy(tempstr," main times\r\n");
   write_tempstr_timfile();
   best_main = 0;
   ltemp1 = 0;  /* too much to init in the FOR loop, do it here */
   for (i = 0; i <= timing_size; i++)
      {
      if (main_times[i] > ltemp1)
         {
         ltemp1 = main_times[i];
         best_main = i;
         }
      sprintf(tempstr,"%2d: %8ld\r\n",i,main_times[i]/2);
      write_tempstr_timfile();
      }
   strcpy(tempstr,"\r\n\r\n");
   write_tempstr_timfile();
   maxmain = main_times[best_main];
/*
 *  Now, set NOPs at start of execute() to get best throttle times
 */
   for (best_throttle = 0; best_throttle <= timing_size; best_throttle++)
      {
      unlink(output_name_1);
      unlink(output_name_2);
      strcpy(cmdline,pic_cmdline);  /* get basic command line */
      if (best_main & 1)
         strcat(cmdline," -nM_1B");
      if (best_main & 2)
         strcat(cmdline," -nM_2B");
      if (best_main & 4)
         strcat(cmdline," -nM_4B");
      if (best_main & 8)
         strcat(cmdline," -nM_8B");
      if (best_main & 16)
         strcat(cmdline," -nM_16B");
      if (best_main & 32)
         strcat(cmdline," -nM_32B");
      if (best_throttle & 1)
         strcat(cmdline," -nEX_1B");
      if (best_throttle & 2)
         strcat(cmdline," -nEX_2B");
      if (best_throttle & 4)
         strcat(cmdline," -nEX_4B");
      if (best_throttle & 8)
         strcat(cmdline," -nEX_8B");
      if (best_throttle & 16)
         strcat(cmdline," -nEX_16B");
      if (best_throttle & 32)
         strcat(cmdline," -nEX_32B");
      strcat(cmdline,"\r");
      run_program("cc.exe");
      strcpy(cmdline,link_cmdline);
      run_program("pccl.exe");
      strcpy(cmdline," -palign02.cmd /none\r");
      run_program(pic_files[pic_index].run_name);
      tmain_times[best_throttle] = get_first_time();
      throttle_times[best_throttle] = get_second_time();
      }
   strcpy(tempstr," tmain times   throttle times\r\n");
   write_tempstr_timfile();
   best_throttle = 0;
   ltemp1 = 0;
   for (i = 0; i <= timing_size; i++)
      {
      if (tmain_times[i] > mainthrottle)
         mainthrottle = tmain_times[i];
      if (tmain_times[i] > maxmain)
         maxmain = tmain_times[i];
      if (throttle_times[i] > ltemp1)
         {
         ltemp1 = throttle_times[i];
         best_throttle = i;
         }
      sprintf(tempstr,"%2d: %8ld    %8ld\r\n",i,tmain_times[i]/2,throttle_times[i]/2);
      write_tempstr_timfile();
      }
   strcpy(tempstr,"\r\n\r\n");
   write_tempstr_timfile();
/*
 *  Finally, do the regs alignment
 */
   strcpy(cmdline,pic_cmdline);  /* get basic command line */
   if (best_main & 1)
      strcat(cmdline," -nM_1B");
   if (best_main & 2)
      strcat(cmdline," -nM_2B");
   if (best_main & 4)
      strcat(cmdline," -nM_4B");
   if (best_main & 8)
      strcat(cmdline," -nM_8B");
   if (best_main & 16)
      strcat(cmdline," -nM_16B");
   if (best_main & 32)
      strcat(cmdline," -nM_32B");
   if (best_throttle & 1)
      strcat(cmdline," -nEX_1B");
   if (best_throttle & 2)
      strcat(cmdline," -nEX_2B");
   if (best_throttle & 4)
      strcat(cmdline," -nEX_4B");
   if (best_throttle & 8)
      strcat(cmdline," -nEX_8B");
   if (best_throttle & 16)
      strcat(cmdline," -nEX_16B");
   if (best_throttle & 32)
      strcat(cmdline," -nEX_32B");
   strcat(cmdline,"\r");
   run_program("cc.exe");  /* set main program to best speed */
   for (best_regs = 0; best_regs <= timing_size; best_regs++)
      {
      unlink(output_name_1);
      unlink(output_name_2);
      strcpy(cmdline,regs_cmdline);  /* get basic command line */
      if (best_regs & 1)
         strcat(cmdline," -nR_1B");
      if (best_regs & 2)
         strcat(cmdline," -nR_2B");
      if (best_regs & 4)
         strcat(cmdline," -nR_4B");
      if (best_regs & 8)
         strcat(cmdline," -nR_8B");
      if (best_regs & 16)
         strcat(cmdline," -nR_16B");
      if (best_regs & 32)
         strcat(cmdline," -nR_32B");
      strcat(cmdline,"\r");
      run_program("cc.exe");
      strcpy(cmdline,link_cmdline);
      run_program("pccl.exe");
      strcpy(cmdline," -palign01.cmd /none\r");
      run_program(pic_files[pic_index].run_name);
      regs_times[best_regs] = get_first_time();
      }
   strcpy(tempstr," regs times\r\n");
   write_tempstr_timfile();
   best_regs = 0;
   ltemp1 = 0;
   for (i = 0; i <= timing_size; i++)
      {
      if (regs_times[i] > ltemp1)
         {
         ltemp1 = regs_times[i];
         best_regs = i;
         }
      if (regs_times[i] > maxmain)
         maxmain = regs_times[i];
      sprintf(tempstr,"%2d: %8ld\r\n",i,regs_times[i]/2);
      write_tempstr_timfile();
      }
   strcpy(tempstr,"\r\n\r\n");
   write_tempstr_timfile();
   strcpy(cmdline,regs_cmdline);  /* get basic command line */
   if (best_regs & 1)
      strcat(cmdline," -nR_1B");
   if (best_regs & 2)
      strcat(cmdline," -nR_2B");
   if (best_regs & 4)
      strcat(cmdline," -nR_4B");
   if (best_regs & 8)
      strcat(cmdline," -nR_8B");
   if (best_regs & 16)
      strcat(cmdline," -nR_16B");
   if (best_regs & 32)
      strcat(cmdline," -nR_32B");
   strcat(cmdline,"\r");
   run_program("cc.exe");
   strcpy(cmdline,link_cmdline);
   run_program("pccl.exe");
   sprintf(tempstr,"\r\n\r\nBest times:  main() with %d nops (%ld IPS)\r\n",best_main,main_times[best_main]/2);
   puts(tempstr);
   write_tempstr_timfile();
   sprintf(tempstr,"           throttle with %d nops (%ld IPS)\r\n",best_throttle,throttle_times[best_throttle]/2);
   puts(tempstr);
   write_tempstr_timfile();
   sprintf(tempstr,"               regs with %d nops (%ld IPS)\r\n",best_regs,regs_times[best_regs]/2);
   puts(tempstr);
   write_tempstr_timfile();
   sprintf(tempstr,"best throttled main:  %ld IPS\r\n",mainthrottle/2);
   puts(tempstr);
   write_tempstr_timfile();
   sprintf(tempstr,"absolute best main: %ld IPS\r\n",maxmain/2);
   puts(tempstr);
   write_tempstr_timfile();
   strcpy(tempstr,"cc ");
   strcat(tempstr,pic_cmdline);  /* get basic command line */
   if (best_main & 1)
      strcat(tempstr," -nM_1B");
   if (best_main & 2)
      strcat(tempstr," -nM_2B");
   if (best_main & 4)
      strcat(tempstr," -nM_4B");
   if (best_main & 8)
      strcat(tempstr," -nM_8B");
   if (best_main & 16)
      strcat(tempstr," -nM_16B");
   if (best_main & 32)
      strcat(tempstr," -nM_32B");
   if (best_throttle & 1)
      strcat(tempstr," -nEX_1B");
   if (best_throttle & 2)
      strcat(tempstr," -nEX_2B");
   if (best_throttle & 4)
      strcat(tempstr," -nEX_4B");
   if (best_throttle & 8)
      strcat(tempstr," -nEX_8B");
   if (best_throttle & 16)
      strcat(tempstr," -nEX_16B");
   if (best_throttle & 32)
      strcat(tempstr," -nEX_32B");
   strcat(tempstr,"\r\n");
   write_tempstr_timfile();
   strcpy(tempstr,"cc ");
   strcat(tempstr,regs_cmdline);  /* get basic command line */
   if (best_regs & 1)
      strcat(tempstr," -nR_1B");
   if (best_regs & 2)
      strcat(tempstr," -nR_2B");
   if (best_regs & 4)
      strcat(tempstr," -nR_4B");
   if (best_regs & 8)
      strcat(tempstr," -nR_8B");
   if (best_regs & 16)
      strcat(tempstr," -nR_16B");
   if (best_regs & 32)
      strcat(tempstr," -nR_32B");
   strcat(tempstr,"\r\n");
   write_tempstr_timfile();
   strcpy(tempstr,"cc ");
   strcat(tempstr,asm_cmdline);  /* get basic command line */
   strcat(tempstr,"\r\n");
   write_tempstr_timfile();
   strcpy(tempstr,"pccl ");
   strcat(tempstr,link_cmdline);
   strcat(tempstr,"\r\n");
   write_tempstr_timfile();
   close(fileout);
   }  /* main() */

DWORD get_first_time()
   {
   WORD i;
   DWORD temp;

   if ((filein = fopen(output_name_1,"r")) == NULL)
      {
      printf("Error:  cannot open input file %s\n",output_name_1);
      exit(1);
      }
   for (i = 0; i < 3; i++)
      {
      if (fgets(linein,STRING_SIZE,filein) == NULL)
         {
         printf("Error: cannot read %s\n",output_name_1);
         exit(1);
         }
      }
   fclose(filein);
   linein[18] = '\0';  /* terminate string */
   sscanf(&linein[10],"%lx",&temp);
   return(temp);
   }

DWORD get_second_time()
   {
   WORD i;
   DWORD temp;

   if ((filein = fopen(output_name_2,"r")) == NULL)
      {
      printf("Error:  cannot open input file %s\n",output_name_2);
      exit(1);
      }
   for (i = 0; i < 3; i++)
      {
      if (fgets(linein,STRING_SIZE,filein) == NULL)
         {
         printf("Error: cannot read %s\n",output_name_2);
         exit(1);
         }
      }
   fclose(filein);
   linein[18] = '\0';  /* terminate string */
   sscanf(&linein[10],"%lx",&temp);
   return(temp);
   }

write_tempstr_timfile()
   {
   write_tempstr(pic_files[pic_index].tim_name);
   }

write_tempstr(name)
   BYTE *name;
   {
   if (fileout != -1)
      {
      if (write(fileout,tempstr,strlen(tempstr)) != strlen(tempstr))
         {
         close(fileout);
         printf("Error:  cannot write %s\n",name);
         exit(1);
         }
      }
   }

create_cmdfiles()
   {
   if ((fileout = creat(cmd_name_1)) == -1)
      {
      printf("Error:  cannot create file %s\n",cmd_name_1);
      exit(1);
      }
   sprintf(tempstr,"l %s\r\n",pic_files[pic_index].cod_name);
   write_tempstr(cmd_name_1);
   sprintf(tempstr,"config %s\r\n",pic_files[pic_index].config_str);
   write_tempstr(cmd_name_1);
   strcpy(tempstr,"scr off\r\n");
   write_tempstr(cmd_name_1);
   sprintf(tempstr,"output %s\r\n",output_name_1);
   write_tempstr(cmd_name_1);
   strcpy(tempstr,"g time=24\r\n");
   write_tempstr(cmd_name_1);
   strcpy(tempstr,"q\r\n");
   write_tempstr(cmd_name_1);
   close(fileout);
   if ((fileout = creat(cmd_name_2)) == -1)
      {
      printf("Error:  cannot create file %s\n",cmd_name_2);
      exit(1);
      }
   sprintf(tempstr,"l %s\r\n",pic_files[pic_index].cod_name);
   write_tempstr(cmd_name_2);
   sprintf(tempstr,"config %s\r\n",pic_files[pic_index].config_str);
   write_tempstr(cmd_name_2);
   strcpy(tempstr,"scr off\r\n");
   write_tempstr(cmd_name_2);
   sprintf(tempstr,"output %s\r\n",output_name_1);
   write_tempstr(cmd_name_2);
   strcpy(tempstr,"g time=24\r\n");
   write_tempstr(cmd_name_2);
   strcpy(tempstr,"output\r\n");
   write_tempstr(cmd_name_2);
   strcpy(tempstr,"reset\r\n");
   write_tempstr(cmd_name_2);
   strcpy(tempstr,"thr 80\r\n");
   write_tempstr(cmd_name_2);
   sprintf(tempstr,"output %s\r\n",output_name_2);
   write_tempstr(cmd_name_2);
   strcpy(tempstr,"ex time=24\r\n");
   write_tempstr(cmd_name_2);
   strcpy(tempstr,"q\r\n");
   write_tempstr(cmd_name_2);
   close(fileout);
   }

WORD adjust_memory_allocation()
   {
#asm
   mov  ah,62h                   ;fn = get PSP segment
   int  21h                      ;call DOS
   mov  es,bx                    ;PSP segemnt to ES
   mov  ax,ds                    ;get a copy of our data segment
   sub  ax,bx                    ;get used data
   add  ax,1010h                 ;plus 64K plus slop
   mov  bx,ax                    ;block size to BX for DOS
   mov  ah,4ah                   ;fn = resize memory block
   int  21h                      ;call DOS
   push ds                       ;our data segment
   pop  es                       ;to es
   mov  ax,0                     ;default to OK
   adc  ax,0                     ;set AX if error return
#endasm
   }

run_program(progname)
   BYTE *progname;
   {
   printf("\n\n%s %s\n",progname,cmdline);
   cmdline_len = strlen(cmdline);
   dos4b_block.cmdline = &cmdline_len;
#asm
   mov  ah,62h                   ;fn = get PSP segment
   int  21h                      ;call DOS
   mov  es,ax                    ;PSP segemnt to ES
   mov  ax,ds                    ;get data seg
   mov  word dos4b_block_[4],ax  ;save cmdline seg
   mov  word dos4b_block_[8],ax  ;save FCB1 seg
   mov  word dos4b_block_[12],ax ;save FCB2 seg
   mov  ax,word es:[2ch]         ;get environment seg
   mov  word dos4b_block_,ax     ;save ptr to env seg
   mov  word cs:ds_ss_save,ss    ;save stack/data segment
   mov  word cs:ds_sp_save,sp    ;save stack pointer
   push ds                       ;current data segment
   pop  es                       ;to seg of parameter block
   mov  bx,offset dos4b_block_   ;es:bx = ptr to parameter block
   mov  dx,word [bp+4]           ;ds:dx = ptr to name to execute
   mov  ax,4b00h                 ;load and execute program
   int  21h                      ;call DOS
   cli                           ;do not disturb!
   mov  ss,word cs:ds_ss_save    ;get saved stack segment
   mov  sp,word cs:ds_sp_save    ;and saved stack pointer
   sti                           ;interrupts are OK again
   push ss                       ;copy stack/data segment
   pop  ds                       ;to ds
   push ds                       ;and another copy
   pop  es                       ;to es
   mov  ah,4dh                   ;fn = get return code
   int  21h                      ;call DOS
   mov  ah,0                     ;make code in AL a WORD
   pop  bp                       ;restore bp
   ret                           ;and done
ds_ss_save: dw 0                 ;SS save area
ds_sp_save: dw 0                 ;SP save area
#endasm
   }

WORD findstring(to_find,in_this_string)  /* for BROWSE */
   BYTE *to_find;
   BYTE *in_this_string;
   {
   WORD i,j,k,l;

   j = -1;
   k = strlen(to_find);
   l = strlen(in_this_string);
   if (k <= l)
      for (i = 0; (i <= l-k) && (j == -1); i++)
         if (strncmp(&in_this_string[i],to_find,k) == 0)
            j = i;
   return(j);
   }

BYTE *strlwr(str)
   BYTE *str;
   {
   WORD i;

   i = -1;
   while (str[++i])
      str[i] = tolower(str[i]);
   return(str);
   }

WORD strcmpi(str1,str2)  /* write what should be a library function */
   BYTE *str1, *str2;
   {
   while ((*str1) && (*str2))
      {
      if (toupper(*str1) != toupper(*str2))
         return(1);
      str1++;
      str2++;
      }
   if (*str1 == *str2)  /* make sure both are at EOS */
      return(0);
   return(1);
   }

WORD get_dosver()
   {
#asm
   mov  ah,30h    ;fn = get DOS version
   int  21h       ;call DOS
   mov  ah,0      ;make major version (in AL) a WORD
#endasm
   }

help()
   {
   puts("PALIGN -- align PICEMUlator program P509 or P877 or P84 or P648 or P675.\n");
   puts("  Usage:\n");
   puts("         PALIGN P509\n");
   puts("  or\n");
   puts("         PALIGN P877\n");
   puts("  or\n");
   puts("         PALIGN P84\n");
   puts("  or\n");
   puts("         PALIGN P648\n");
   puts("  or\n");
   puts("         PALIGN P675\n\n");
   puts("Add \'-P\' after the Pxxx to display debugging info.\n\n");
   puts("Add \'-T\' after the Pxxx to adjust code for fastest execution.\n");
   puts("   use -T4 -T8 -T16 -T32 or -T64 for align nops to use, default is 16.\n\n");
   puts("If you don't know what this program does, you shouldn't be using it.\n");
   exit(1);
   }
