#ifdef NEVERDEF
/****************************************************************************
 ****************************************************************************
 *                                                                          *
 *   WARNING!                                                               *
 *                                                                          *
 *   I've discovered a bug in the code optimizer.  A definition like:       *
 *      #define TESTBITS (BIT1|BIT2)                                        *
 *   can produce incorrect code output from the optimizer when TESTBITS     *
 *   is used.                                                               *
 *                                                                          *
 *   Instead, use a definition like:                                        *
 *      #define TESTBITS 0x05  /* (BIT1|BIT2) */                            *
 *   Yes, that's not as "ideal", but it will save a WORLD of problems!      *
 *                                                                          *
 ****************************************************************************
 ****************************************************************************/
#endif

/*
 *  PIC emulator.  16F877 version.
 *  Assembler
 *
 *
 *  Copyright (c) 2001, 2002
 *
 *  Released under the GNU GPL.  See http://www.gnu.org/licenses/gpl.txt
 *
 *  This program is part of PICEMU
 *
 *  PICEMU is free software; you can redistribute it and/or modify it under
 *  the terms of the GNU General Public License as published by the Free
 *  Software Foundatation; either version 2 of the License, or any later
 *  version.
 *
 *  PICEMU is distributed in the hope that it will be useful, but WITHOUT
 *  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 *  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 *  for more details.
 *
 *
 *  Revision history
 *
 *  Date      Comments
 *  --------  ---------------------------------------------
 *  10/xx/01  Original code
 *  11/14/01  Code cleanup for 1st BETA release
 *  9/6/02    Found bug with #define's
 */


#include <picemu.h>

extern BYTE cmdline[STRING_SIZE];
extern WORD cmdptr;

extern BYTE tempstr[STRING_SIZE];
extern BYTE browse_screen[BROWSE_SCREEN_SIZE+16];
  /* re-use this to allow multiple values to be returned from the assembler */

extern BYTE number_str[];     /* re-use an error message */

struct asm_table
   {
   BYTE opname[8];
   WORD opcode_base;
   WORD flags;
   } asmtable[NUM_INSTRS] =
   {
      { "NOP",    0x0000, ASM_NONE },
      { "RETURN", 0x0008, ASM_NONE },
      { "RETFIE", 0x0009, ASM_NONE },
      { "OPTION", 0x0062, ASM_NONE },
      { "SLEEP",  0x0063, ASM_NONE },
      { "CLRWDT", 0x0064, ASM_NONE },
      { "TRIS",   0x0060, ASM_TRIS14 },
      { "MOVWF",  0x0080, ASM_FILENUM },
      { "CLRW",   0x0100, ASM_NONE },
      { "CLRF",   0x0180, ASM_FILENUM },
      { "SUBWF",  0x0200, ASM_FILENUM | ASM_W },
      { "DECF",   0x0300, ASM_FILENUM | ASM_W },
      { "IORWF",  0x0400, ASM_FILENUM | ASM_W },
      { "ANDWF",  0x0500, ASM_FILENUM | ASM_W },
      { "XORWF",  0x0600, ASM_FILENUM | ASM_W },
      { "ADDWF",  0x0700, ASM_FILENUM | ASM_W },
      { "MOVF",   0x0800, ASM_FILENUM | ASM_W },
      { "COMF",   0x0900, ASM_FILENUM | ASM_W },
      { "INCF",   0x0a00, ASM_FILENUM | ASM_W },
      { "DECFSZ", 0x0b00, ASM_FILENUM | ASM_W },
      { "RRF",    0x0c00, ASM_FILENUM | ASM_W },
      { "RLF",    0x0d00, ASM_FILENUM | ASM_W },
      { "SWAPF",  0x0e00, ASM_FILENUM | ASM_W },
      { "INCFSZ", 0x0f00, ASM_FILENUM | ASM_W },
      { "BCF",    0x1000, ASM_FILENUM | ASM_BITNUM },
      { "BSF",    0x1400, ASM_FILENUM | ASM_BITNUM },
      { "BTFSC",  0x1800, ASM_FILENUM | ASM_BITNUM },
      { "BTFSS",  0x1c00, ASM_FILENUM | ASM_BITNUM },
      { "CALL",   0x2000, ASM_11BITK },
      { "GOTO",   0x2800, ASM_11BITK },
      { "MOVLW",  0x3000, ASM_8BITK },
      { "RETLW",  0x3400, ASM_8BITK },
      { "IORLW",  0x3800, ASM_8BITK },
      { "ANDLW",  0x3900, ASM_8BITK },
      { "XORLW",  0x3a00, ASM_8BITK },
      { "SUBLW",  0x3c00, ASM_8BITK },
      { "ADDLW",  0x3e00, ASM_8BITK },
      { "ORG",    0x0000, ASM_ORIGIN },
      { "DB",     0x0000, ASM_STORAGE|ASM_DW|ASM_8BITK },
      { "DW",     0x0000, ASM_STORAGE|ASM_DW },
      { "DT",     0x0000, ASM_STORAGE|ASM_DT|ASM_8BITK }
   };

BYTE opcode_str[8] = "opcode?";
BYTE param_str[12] = "parameter?";
BYTE reg_str[16] = "file number?";

WORD at_eol_comment()
   {
   if ((!cmdline[cmdptr]) || (cmdline[cmdptr] == ';'))  /* if EOL or comment */
      return(TRUE);
   return(FALSE);
   }

WORD parse_data(ofs)
   WORD ofs;
   {
   WORD i, end_loc;
   DWORD val;

   if ((tempstr[0] == '\"') || (tempstr[0] == '\''))  /* if a quoted string */
      {
      i = 1;
      end_loc = strlen(tempstr) - 1;
      while (i < end_loc)  /* return vals of all chars in string, excluding quotes */
         {
         *(WORD *)&browse_screen[ofs+ofs+2] = tempstr[i++];
         ofs++;
         }
      return(ofs);
      }
   if ((!check_hex_string(tempstr))  /* reg names not allowed here */
                  || (!fromhex(tempstr,&val))  /* bad hex number */
                  || (val & 0xffff0000))
      {
      cmdline_error(number_str);
      return(ASM_INVALID);
      }
   *(WORD *)&browse_screen[ofs+ofs+2] = (WORD)val;
   return(++ofs);
   }

  /* Pass a line in cmdline[], return opcode or ASM_INVALID */
WORD assembler()
   {
   WORD i, j, opcode, flags;
   DWORD val;

   if (cmdline[cmdptr] == ';')
      return(ASM_INVALID);  /* comment, no opcode but no error message! */
   if (!parse(tempstr))
      {
      cmdline_error(opcode_str);
      return(ASM_INVALID);
      }
   for (i = 0; i < NUM_INSTRS; i++)
      if (strcmpi(asmtable[i].opname,tempstr) == 0)
         break;
   if (i == NUM_INSTRS)  /* if unrecognized opcode */
      {
      cmdline_error(opcode_str);
      return(ASM_INVALID);
      }
   opcode = asmtable[i].opcode_base;  /* get basic opcode */
   flags = asmtable[i].flags;  /* and a working copy of flags (i now availble) */
   skip_cmd_spaces();
   if (flags == ASM_NONE)  /* this opcode has no parameters */
      {
      if (at_eol_comment())  /* if EOL or comment */
         return(opcode);  /* that's OK */
      cmdline_error(param_str);  /* this opcode does not take parameters */
      return(ASM_INVALID);
      }
   if (flags & ASM_STORAGE)  /* if DB/DW/DT pseudo-op */
      {
      i = 0;  /* number of elements in DB/DW/DT */
      while ((!at_eol_comment()) && (parse(tempstr)))  /* until comment or EOL */
         {
         if ((j = parse_data(i)) == ASM_INVALID)
            return(ASM_INVALID);
         for ( ; i < j; i++)
            {
            if (flags & ASM_8BITK)
               {
               *(WORD *)&browse_screen[i+i+2] &= 0xff;
               if (flags & ASM_DT)
                  *(WORD *)&browse_screen[i+i+2] |= 0x3400;  /* set RETLW */
               }
            else
               *(WORD *)&browse_screen[i+i+2] &= INSTRUCTION_BITMASK;
            }
         }
      *(WORD *)browse_screen = i;
      return(ASM_DATA);
      }
   if ((at_eol_comment()) || (!parse(tempstr)))  /* if EOL or comment or bad parse */
      {
      cmdline_error(param_str);
      return(ASM_INVALID);
      }
   if ((!check_hex_string(tempstr))  /* reg names not allowed here */
        || (!fromhex(tempstr,&val)))  /* bad hex number */
      {
      cmdline_error(number_str);
      return(ASM_INVALID);
      }
   if (flags & ASM_ORIGIN)
      {
      if ((WORD)val > MEMORY_MASK)
         {
         cmdline_error(number_str);
         return(ASM_INVALID);
         }
      if (!at_eol_comment())
         {
         cmdline_error(param_str);  /* this should be EOL */
         return(ASM_INVALID);
         }
      *(WORD *)browse_screen = val;
      return(ASM_ORG);
      }
   if (flags & ASM_FILENUM)
      {
      if ((WORD)val > REGINDEX_MASK)  /* if out of range! */
         {
         cmdline_error(reg_str);
         return(ASM_INVALID);
         }
      opcode |= (WORD)val;  /* set file number */
      }
   if (flags & ASM_8BITK)
      {
      if (val > 0xff)  /* more more than 8 bits */
         {
         cmdline_error(number_str);
         return(ASM_INVALID);
         }
      opcode |= (WORD)val;  /* set constant */
      }
   if (flags & ASM_11BITK)
      {
      if (val > 0x7ff)  /* more more than 11 bits */
         {
         cmdline_error(number_str);
         return(ASM_INVALID);
         }
      opcode |= (WORD)val;  /* set constant */
      }
   if (flags & ASM_TRIS14)  /* TRIS wants values of 5, 6, 7 only */
      {
      if ((val < 5) || (val > 7))
         {
         cmdline_error(number_str);
         return(ASM_INVALID);
         }
      opcode |= (WORD)val;  /* set constant */
      }
   skip_cmd_spaces();  /* skip any whitespace */
   if (!(flags & (ASM_BITNUM | ASM_W)))  /* if end of opcode... */
      {
      if (at_eol_comment())  /* if EOL or comment */
         return(opcode);  /* thats OK */
      cmdline_error(param_str);  /* too many parameters */
      return(ASM_INVALID);
      }
   if (flags & ASM_W)  /* if looking for "w"/"f" and nothing, assume "f" */
      {
      if (at_eol_comment())  /* if EOL or comment */
         {
         opcode |= 1 << BITNUM_POSITION;  /* set "F" destination bit */
         return(opcode);  /* and we're done */
         }
      }
   if ((cmdline[cmdptr] != ',')  /* want a comma to separate stuff */
          || (!parse(tempstr)))  /* or bad parsing */
      {
      cmdline_error(param_str);  /* too many parameters */
      return(ASM_INVALID);
      }
   if (flags & ASM_W)  /* if looking for "w"/"f" */
      {
      if ((strcmpi(tempstr,"F") == 0) || (strcmp(tempstr,"1") == 0))
         opcode |= 1 << BITNUM_POSITION;  /* set "F" destination bit */
                              /* also works for "DEST" bit shift */
      else
         if ((strcmpi(tempstr,"W")) && (strcmp(tempstr,"0")))  /* if not "W" destination */
            {
            cmdline_error(param_str);  /* too many parameters */
            return(ASM_INVALID);
            }
      }
   else   /* this must be ASM_BITNUM */
      {
      if ((!check_hex_string(tempstr))  /* reg names not allowed here */
           || (!fromhex(tempstr,&val))  /* bad hex number */
           || (val > 7))                /* bad bit number */
         {
         cmdline_error(number_str);
         return(ASM_INVALID);
         }
      opcode |= (WORD)val << BITNUM_POSITION;
      }
   skip_cmd_spaces();
   if (at_eol_comment())
             /* if EOL or comment */
      return(opcode);  /* we're done! */
   cmdline_error(param_str);  /* this should be EOL */
   return(ASM_INVALID);
   }

#ifdef ALIGN_ASM_1
   static BYTE asmalign_1 = 0;
#endif
#ifdef ALIGN_ASM_2
   static WORD asmalign_2 = 0;
#endif
