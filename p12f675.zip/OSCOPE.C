/*
 *  Hi Tech PIC C LITE compiler, V8.02
 */
#include <pic.h>

__CONFIG(INTIO & WDTDIS & MCLRDIS);

/*
 *      Serial port driver for 16Cxx chips
 *      using software delays.
 *
 *      Copyright (C)1996 HI-TECH Software.
 *      Freely distributable.
 */
/*
 * Trivial changes made to INIT_PORT stuff.
 * Reformatted to make it look nice.
 * 3/20/02
 */

/*
 *      Tunable parameters
 */
/* Transmit and Receive port bits */
#define TxData GPIO4
#define RxData GPIO5
#define INIT_PORT() TxData = 1; TRIS4 = 0; TRIS5 = 1  /* set up I/O direction */

/* Xtal frequency */
#define XTAL  4000000L

/* Baud rate */
#define BRATE 9600

/* Don't change anything else */
#define DLY       3  /* cycles per null loop */
#define TX_OHEAD 13  /* overhead cycles per loop */
#define RX_OHEAD 12  /* receiver overhead per loop */

#define DELAY(ohead) (((XTAL/4/BRATE)-(ohead))/DLY)

void putch(char c)
   {
   unsigned char dly, bitno;

   bitno = 11;
   TxData = 0;         /* start bit */
   bitno = 12;
   do
      {
      dly = DELAY(TX_OHEAD);   /* wait one bit time */
      do
         /* nix */ ;
      while (--dly);
      if (c & 1)
         TxData = 1;
      if (!(c & 1))
         TxData = 0;
      c = (c >> 1) | 0x80;
      } while (--bitno);
   }

char getch(void)
   {
   unsigned char c, bitno, dly;

   for ( ; ; )
      {
      while (RxData)
         continue;   /* wait for start bit */
      dly = DELAY(3)/2;
      do
         /* nix */;
      while (--dly);
      if (RxData)
         continue;   /* twas just noise */
      bitno = 8;
      c = 0;
      do
         {
         dly = DELAY(RX_OHEAD);
         do
            /* nix */;
         while (--dly);
         c = (c >> 1) | (RxData << 7);
         } while(--bitno);
      return c;
      }
   }

#define ON  1
#define OFF 0

#define UPDATES_PER_SECOND 16L
#define TMR1H_RESET ((65542L-((XTAL/4L)/UPDATES_PER_SECOND)) >> 8)
#define TMR1L_RESET ((65542L-((XTAL/4L)/UPDATES_PER_SECOND)) & 0xff)
/* NOTE: 65542 instead of 65536 for 6 cycles it takes to recognize TMR0
 *       overflow and reload TMR1H/TMR1L:
 *          while (!TMR1IF)
 *            ;
 *          TMR1H = TMR1H_RESET;
 *          TMR1L = TMR1L_RESET;
 *       becomes
 *          Lxx:
 *             BTFSS 0x0C,0
 *             GOTO  Lxx
 *             MOVLW xxxx
 *             MOVWF TMR1H
 *             MOVLW yyyy
 *             MOVWF TMR1L
 */

unsigned int spacecount;

main()
   {
       /* Load Factory Calibration Value Into OSCCAL */
   OSCCAL = _READ_OSCCAL_DATA();
   ANSEL = 0b00010001;
          /* 0....... = unused */
          /* .001.... = ADC conversion clock = Fosc/8 */
          /* ....0... = AN3 (GP4) is digital */
          /* .....0.. = AN2 (GP2) is digital */
          /* ......0. = AN1 (GP1) is digital */
          /* .......1 = AN0 (GP0) is analog */
   TRIS0 = 1;  /* make AN0 (GP0) an INPUT to allow external control of voltage on pin */
   ADCON0 = 0b10000001;
           /* 1....... = right justified in ADRESH:ADRESL */
           /* .0...... = use VDD as voltage reference */
           /* ..00.... = unused */
           /* ....00.. = convert AN0 */
           /* ......0. = conversion not in progress */
           /* .......1 = ADC on */
   CMCON = 7;  /* comparitor off */
   INIT_PORT();  /* setup for SoftUart */
   TMR1H = TMR1H_RESET;
   TMR1L = TMR1L_RESET;
   TMR1IF = OFF;
   T1CON = 0b00000001;
          /* 0....... = unused */
          /* .0...... = Timer 1 Gate disabled */
          /* ..00.... = 1:1 prescalar */
          /* ....0... = LP oscillator is OFF */
          /* .....0.. = T1SYNC (ignored if TMR1CS is 0) */
          /* ......0. = TMR1CS = internal clock (Fosc/4) */
          /* .......1 = TMR1ON */
   for ( ; ; )
      {
      while (!TMR1IF)
         ;   /* wait for timer to expire */
      TMR1H = TMR1H_RESET;
      TMR1L = TMR1L_RESET;
      TMR1IF = OFF;
      GODONE = ON;
      while (GODONE)
         ;  /* wait for ADC conversion */
      spacecount = (((unsigned int)ADRESH << 8) | (unsigned int)ADRESL) >> 5;
      while (spacecount--)
         putch(' ');
      putch('*');
      putch('\n');
      }  /* for ( ; ; ) */
   }  /* main() */
