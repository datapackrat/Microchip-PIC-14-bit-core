/*
 *  Hi Tech PIC C LITE compiler, V8.02
 */
#include <pic.h>

__CONFIG(INTIO & WDTDIS & MCLRDIS);

/*
 *      Serial port driver for 16Cxx chips
 *      using software delays.
 *
 *      Copyright (C)1996 HI-TECH Software.
 *      Freely distributable.
 */
/*
 * Trivial changes made to INIT_PORT stuff.
 * Reformatted to make it look nice.
 * 3/20/02
 */

/*
 *      Tunable parameters
 */
/* Transmit and Receive port bits */
#define TxData GPIO4
#define RxData GPIO5
#define INIT_PORT() TxData = 1; TRIS4 = 0; TRIS5 = 1  /* set up I/O direction */

/* Xtal frequency */
#define XTAL  4000000L

/* Baud rate */
#define BRATE 9600

/* Don't change anything else */
#define DLY       3  /* cycles per null loop */
#define TX_OHEAD 13  /* overhead cycles per loop */
#define RX_OHEAD 12  /* receiver overhead per loop */

#define DELAY(ohead) (((XTAL/4/BRATE)-(ohead))/DLY)

void putch(char c)
   {
   unsigned char dly, bitno;

   bitno = 11;
   TxData = 0;         /* start bit */
   bitno = 12;
   do
      {
      dly = DELAY(TX_OHEAD);   /* wait one bit time */
      do
         /* nix */ ;
      while (--dly);
      if (c & 1)
         TxData = 1;
      if (!(c & 1))
         TxData = 0;
      c = (c >> 1) | 0x80;
      } while (--bitno);
   }

char getch(void)
   {
   unsigned char c, bitno, dly;

   for ( ; ; )
      {
      while (RxData)
         continue;   /* wait for start bit */
      dly = DELAY(3)/2;
      do
         /* nix */;
      while (--dly);
      if (RxData)
         continue;   /* twas just noise */
      bitno = 8;
      c = 0;
      do
         {
         dly = DELAY(RX_OHEAD);
         do
            /* nix */;
         while (--dly);
         c = (c >> 1) | (RxData << 7);
         } while(--bitno);
      return c;
      }
   }

#define ON  1
#define OFF 0

#define UPDATES_PER_SECOND 16L
#define TMR1H_RESET ((65542L-((XTAL/4L)/UPDATES_PER_SECOND)) >> 8)
#define TMR1L_RESET ((65542L-((XTAL/4L)/UPDATES_PER_SECOND)) & 0xff)
/* NOTE: 65542 instead of 65536 for 6 cycles it takes to recognize TMR0
 *       overflow and reload TMR1H/TMR1L:
 *          while (!TMR1IF)
 *            ;
 *          TMR1H = TMR1H_RESET;
 *          TMR1L = TMR1L_RESET;
 *       becomes
 *          Lxx:
 *             BTFSS 0x0C,0
 *             GOTO  Lxx
 *             MOVLW xxxx
 *             MOVWF TMR1H
 *             MOVLW yyyy
 *             MOVWF TMR1L
 */

char range;
char vrcon_base;
char adc_val;
char last_adc_val;
char adc_bit;
char delay;

char ascii_hex(char ch)
   {
   ch &= 0x0f;  /* isolate low nibble */
   if (ch > 9)
      return(ch + 0x37);
   return(ch + 0x30);
   }

void puthex(char c)
   {
   putch(ascii_hex(c >> 4));
   putch(ascii_hex(c));
   }

void puts(const char *s)
   {
   while (*s)
      putch(*(s++));
   }

main()
   {
       /* Load Factory Calibration Value Into OSCCAL */
   OSCCAL = _READ_OSCCAL_DATA();
   ANSEL = OFF;  /* AN0 .. AN4 are not associated with ADC */
   ADCON0 = OFF;  /* ADC is OFF */
   CMCON = 0b00001110;
          /* 0.0..... = unused bits */
          /* .0...... = COUT, read-only bit */
          /* ...0.... = CINV, not inverted */
          /* ....1... = CIS = 1, use GP0 as input */
          /* .....110 = CM2:CM0 inputs from GP0 (via CIS) and CVREF, output to COUT only */
   TRIS0 = 1;  /* allow external voltage to control pin CIN+ */
   INIT_PORT();  /* setup for SoftUart */
   do
      {
      puts("Do you want to convert a 'L'ow (0 .. 0.625 * Vdd)\n");
      puts("or 'H'igh (0.25 * Vdd .. 0.719 * Vdd) range? ");
      range = getch();
      putch(range);
      putch('\n');
      if ((range >= 'a') && (range <= 'z'))
         range -= 'a' - 'A';  /* toupper() */
      } while ((range != 'L') && (range != 'H'));
   if (range == 'L')
      vrcon_base = 0b10100000;
                  /* 1....... = VREN, enable CVref */
                  /* .0.0.... = unused bits */
                  /* ..1..... = low range */
                  /* ....0000 = CVref = 0V */
   else
      vrcon_base = 0b10000000;
                  /* 1....... = VREN, enable CVref */
                  /* .0.0.... = unused bits */
                  /* ..0..... = high range */
                  /* ....0000 = CVref = Vdd/4 */
   VRCON = vrcon_base;
   last_adc_val = 0xff;
      /* our ADC conversion will never equal this, so force first conversion
       * to be displayed.
       */
   TMR1H = TMR1H_RESET;
   TMR1L = TMR1L_RESET;
   TMR1IF = OFF;
   T1CON = 0b00000001;
          /* 0....... = unused */
          /* .0...... = Timer 1 Gate disabled */
          /* ..00.... = 1:1 prescalar */
          /* ....0... = LP oscillator is OFF */
          /* .....0.. = T1SYNC (ignored if TMR1CS is 0) */
          /* ......0. = TMR1CS = internal clock (Fosc/4) */
          /* .......1 = TMR1ON */
   for ( ; ; )
      {
      while (!TMR1IF)
         ;   /* wait for timer to expire */
      TMR1H = TMR1H_RESET;
      TMR1L = TMR1L_RESET;
      TMR1IF = OFF;
      for (adc_val = 0, adc_bit = 0x08; adc_bit; adc_bit >>= 1)
         {
         VRCON = vrcon_base | adc_val | adc_bit;
         for (delay = 6; delay; delay--)
            ;  /* wait for comparitor to settle */
         if (!COUT)
            adc_val |= adc_bit;
         }
      if (adc_val != last_adc_val)
         {
         puts("ADC reading: ");
         puthex(adc_val);
         putch('\n');
         last_adc_val = adc_val;
         }
      }  /* for ( ; ; ) */
   }  /* main() */
