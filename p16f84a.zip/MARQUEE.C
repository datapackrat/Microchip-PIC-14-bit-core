/*
 *  Hi Tech PIC C LITE compiler, V8.02
 */
#include <pic.h>

__CONFIG(WDTDIS);

/* Xtal frequency */
#define XTAL  19660800L

#define BAUDRATE 9600

#define ON  1
#define OFF 0
#define TRUE 1
#define FALSE 0

#define MAX_USER_MESSAGE 16
#define CR '\015'
#define LF '\012'

/* #define DISPLAY_VIA_LEVELS */  /* this doesn't look very good, but it's available... */
#define DISPLAY_RED_ON_GREEN

#define COLS_PER_CHAR 5

const char charset[128][COLS_PER_CHAR] =
#include "5x5.h"
   /* NOTE: This character set is designed to use bits 0, 1, 2, 4 and 5.  This
    *       is so it can be used with the 12F675 as well, in which bit 3
    *       (GPIO3) is input only.
    */

#define STD_MESSAGE_LEN 16
const char std_message[STD_MESSAGE_LEN+1] = "Hello, World!   ";
                                          /* 0123456789abcdef */
char message_byte;
char message_index;
char char_index;
char message_len;
bit user_msg;  /* TRUE or FALSE */
char user_index;
char user_message[MAX_USER_MESSAGE];
char rxbuf[MAX_USER_MESSAGE];
char echo_char;

#define T0IF_DIVISOR 128
char t0if_divide;

#define TX_PIN RA0
#define RX_PIN RA1

char rx_bitcount;
bit rx_waiting;  /* TRUE or FALSE */
char rx_char;
char tx_bitcount;
unsigned int tx_hold;

const char user_instr[] = "\n\rYour message (up to 15 chars) ? ";

interrupt void isr()
   {
   if (T0IF)
      {
      T0IF = OFF;
      if (++t0if_divide == T0IF_DIVISOR)
         {
         t0if_divide = 0;
#ifdef DISPLAY_VIA_LEVELS
         PORTB = ~charset[message_byte][char_index];
#else
   #ifdef DISPLAY_RED_ON_GREEN
         TRISB = ~charset[message_byte][char_index];
   #else
         TRSIB = charset[message_byte][char_index];
   #endif
#endif
         if (++char_index == COLS_PER_CHAR)
            {
            char_index = 0;
            if (++message_index == message_len)
               message_index = 0;
            if (user_msg)
               message_byte = user_message[message_index];
            else
               message_byte = std_message[message_index];
            }
         }  /* if (++t0if_divide == T0IF_DIVISOR) */
      if (tx_bitcount)  /* if sending a char */
         {
         if (tx_hold & 1)
            TX_PIN = ON;
         else
            TX_PIN = OFF;
         tx_hold >>= 1;
         tx_bitcount--;
         }  /* if (tx_bitcount) */
      if (rx_bitcount)  /* if receiveing a char */
         {
         if (--rx_bitcount == 0)  /* if time for the STOP bit */
            {
            rx_char &= 0x7f;  /* don't want the high bit */
            if (RX_PIN)  /* is the stop bit present? */
               rx_waiting = TRUE;
            }
         else
            {
            rx_char >>= 1;
            if (RX_PIN)
               rx_char |= 0x80;
            }
         }
      else
         {
         if (!RX_PIN)  /* if start bit */
            {
            rx_bitcount = 9;  /* start receiving char */
            rx_char = 0;
            }
         }  /* if (rx_bitcount) ... else */
      }  /* if (T0IF) */
   }

void putch(char c)
   {
   while (tx_bitcount)
      ;
   tx_hold = (c << 1) | 0x0200;
   tx_bitcount = 10;
   }

void puts(const char *s)
   {
   while (*s)
      putch(*(s++));
   }

main()
   {
   TRISA = 0b00000010;
          /* 000..... = unused */
          /* ...000.. = don't care */
          /* ......1. = RX_PIN is an INPUT */
          /* .......0 = TX_PIN is an OUTPUT */
   TX_PIN = ON;  /* default to HIGH */
   TMR0 = 0;
   OPTION = 0b11000000;
           /* 1....... = !RBPU, Port B pull-ups disabled */
           /* .1...... = interrupt edge, defalut value */
           /* ..0..... = T0CS, internal instruction cycle count (CLKOUT) */
           /* ...0.... = T0SE, don't care for T0CS=0 */
           /* ....0... = PSA, prescalar assiged to TMR0 */
           /* .....000 = Prescalar is 2:1 */
   T0IE = ON;
   GIE = ON;
   message_byte = std_message[0];
   message_len = STD_MESSAGE_LEN;
#ifdef DISPLAY_VIA_LEVELS
   TRISB = 0;  /* all bits are outputs */
#endif
   puts(user_instr);
   for ( ; ; )
      {
      if (rx_waiting)
         {
         rx_waiting = FALSE;
         if (rx_char == CR)
            {
            putch(LF);
            putch(CR);
            if (user_index)
               {
               for (message_len = 0; message_len < user_index; message_len++)
                  user_message[message_len] = rxbuf[message_len];
               message_index = 0;
               user_msg = TRUE;
               user_index = 0;
               }
            puts(user_instr);
            }
         else
            {
            if (user_index < MAX_USER_MESSAGE-1)
               {
               putch(rx_char);
               rxbuf[user_index++] = rx_char;
               }
            }
         }  /* if (rx_waiting) */
      }  /* for ( ; ; ) */
   }  /* main() */
