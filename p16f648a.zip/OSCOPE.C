/*
 *  Hi Tech PIC C LITE compiler, V8.02
 */
/*
 *  We're going to use the comparitor and VREF as a low-precision (4-bit)
 *  ADC, ala the FAKEADC example.
 */
#include <pic.h>

__CONFIG(INTIO & WDTDIS & MCLRDIS);

/* Xtal frequency */
#define XTAL  4000000L

#define BAUDRATE 9600


#define ON  1
#define OFF 0

#define UPDATES_PER_SECOND 16L
#define TMR1H_RESET ((65542L-((XTAL/4L)/UPDATES_PER_SECOND)) >> 8)
#define TMR1L_RESET ((65542L-((XTAL/4L)/UPDATES_PER_SECOND)) & 0xff)
/* NOTE: 65542 instead of 65536 for 6 cycles it takes to recognize TMR0
 *       overflow and reload TMR1H/TMR1L:
 *          while (!TMR1IF)
 *            ;
 *          TMR1H = TMR1H_RESET;
 *          TMR1L = TMR1L_RESET;
 *       becomes
 *          Lxx:
 *             BTFSS 0x0C,0
 *             GOTO  Lxx
 *             MOVLW xxxx
 *             MOVWF TMR1H
 *             MOVLW yyyy
 *             MOVWF TMR1L
 */

char vrcon_base;
char spacecount;

void putch(char c)
   {
   while (!TXIF)
      ;
   TXREG = c;
   }

char read_adc()
   {
   char adc_val, adc_bit, delay;

   for (adc_val = 0, adc_bit = 0x08; adc_bit; adc_bit >>= 1)
      {
      VRCON = vrcon_base | adc_val | adc_bit;
      for (delay = 6; delay; delay--)
         ;  /* wait for comparitor to settle */
      if (!C2OUT)
         adc_val |= adc_bit;
      }
   return(adc_val);
   }

main()
   {
   TXSTA = 0b00100100;
          /* 0....... = Async don't care */
          /* .0...... = 8-bit transmission */
          /* ..1..... = transmit enabled */
          /* ...0.... = asynchronous mode */
          /* ....0... = unused */
          /* .....1.. = High-speed baudrate */
          /* ......0. = read-only register bit */
          /* .......0 = 9th bit of TX data (not used in 8-bit mode) */
   RCSTA = 0b10000000;
          /* 1....... = SPEN, serial port is ON */
          /* .0...... = RX9, 8-bit reception */
          /* ..0..... = SREN (async don't care) */
          /* ...0.... = CREN, continuous receive OFF (we don't need to receive anything) */
          /* ....0... = ADDEN, disable address detection */
          /* .....0.. = FERR (read-only) */
          /* ......0. = OERR (read-only) */
          /* .......0 = RX9D (read-only) */
   SPBRG = (XTAL / (BAUDRATE * 16.0)) - 0.5;
               /* -1.0 + 0.5, the extra + 0.5 is to round up when needed */
               /* ignore the warning "implicit converion of float to integer"
                * on this line.
                */
   CMCON = 0b00000101;
          /* 0....... = C2OUT, read-only bit */
          /* .0...... = C1OUT, read-only bit */
          /* ..0..... = C2INV, not inverted */
          /* ...0.... = C1INV, not inverted (don't care for our problem) */
          /* ....0... = CIS = 0, don't care for our problem */
          /* .....101 = CM2:CM0 one comparitor, VIN- from A1, VIN+ from Vref,
                        output to C2OUT only */
   TRISA1 = 1;  /* allow external voltage to control pin VIN- for CMP2 */
   TRISA2 = 1;  /* allow Vref to control pin VIN+ for CMP2 */
   vrcon_base = 0b11100000;
               /* 1....... = VREN, enable CVref */
               /* .1...... = VROE, Vref connected to A2 */
               /* ..1..... = low range */
               /* ...0.... = unused bit */
               /* ....0000 = CVref = 0V */
   VRCON = vrcon_base;
   TMR1H = TMR1H_RESET;
   TMR1L = TMR1L_RESET;
   TMR1IF = OFF;
   T1CON = 0b00000001;
          /* 0....... = unused */
          /* .0...... = Timer 1 Gate disabled */
          /* ..00.... = 1:1 prescalar */
          /* ....0... = LP oscillator is OFF */
          /* .....0.. = T1SYNC (ignored if TMR1CS is 0) */
          /* ......0. = TMR1CS = internal clock (Fosc/4) */
          /* .......1 = TMR1ON */
   for ( ; ; )
      {
      while (!TMR1IF)
         ;   /* wait for timer to expire */
      TMR1H = TMR1H_RESET;
      TMR1L = TMR1L_RESET;
      TMR1IF = OFF;
      spacecount = read_adc();
      while (spacecount--)
         putch(' ');
      putch('*');
      putch('\n');
      }  /* for ( ; ; ) */
   }  /* main() */
