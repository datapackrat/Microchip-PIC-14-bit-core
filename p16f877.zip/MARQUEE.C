/*
 *  Hi Tech PIC C LITE compiler, V8.02
 */
#include <pic.h>

__CONFIG(HS & WDTDIS);

/* Xtal frequency */
#define XTAL  4000000L

#define BAUDRATE 9600

#define ON  1
#define OFF 0
#define TRUE 1
#define FALSE 0

/* #define DISPLAY_VIA_LEVELS */  /* this doesn't look very good, but it's available... */
#define DISPLAY_RED_ON_GREEN
#define MAX_USER_MESSAGE 64
#define CR '\015'

const char charset[128][8] =
#include "charset.h"

const char std_message[17] = "Hello, World!   ";
                           /* 0123456789abcdef */
char message_byte;
char message_index;
char char_index;
char message_len;
char user_msg;
char user_index;
char user_message[MAX_USER_MESSAGE];
bank1 char rxbuf[MAX_USER_MESSAGE];
char echo_char;

char bitbucket;

const char user_instr1[] = "\n\rEnter your own message, up to 63 characters long, followed by 'enter'\n\r";
const char user_instr2[] = "A few spaces at the end will improve readibility\r\n ? ";

interrupt void isr()
   {
   if (T0IF)
      {
      T0IF = OFF;
#ifdef DISPLAY_VIA_LEVELS
      PORTB = ~charset[message_byte][char_index];
#else
   #ifdef DISPLAY_RED_ON_GREEN
      TRISB = ~charset[message_byte][char_index];
   #else
      TRISB = charset[message_byte][char_index];
   #endif
#endif
      if (++char_index == 8)
         {
         char_index = 0;
         if (++message_index == message_len)
            message_index = 0;
         if (user_msg)
            message_byte = user_message[message_index];
         else
            message_byte = std_message[message_index];
         }
      }
   while (RCIF)  /* receive interrupt */
      {
      if (RCSTA & 0x06)  /* if overrun error or framing error */
         {
         CREN = 0;           /* turn off continuous receive */
         bitbucket = RCREG;  /* clear receive queue */
         bitbucket = RCREG;
         CREN = 1;           /* turn on continuous receive */
         }
      else
         {
         if (user_index != MAX_USER_MESSAGE)
            user_index++;
               /* if queue is full, "throw away" the incoming bytes. */
         echo_char =
         rxbuf[user_index-1] = RCREG & 0x7f;
         }
      }
   }

void putch(char c)
   {
   while (!TXIF)
      ;
   TXREG = c;
   }

void puts(const char *s)
   {
   while (*s)
      putch(*(s++));
   }

main()
   {
   TMR0 = 0;
   OPTION = 0b11000111;
           /* 1....... = !RBPU, Register B pull-ups disabled */
           /* .1...... = interrupt edge, defalut value */
           /* ..0..... = T0CS, internal instruction cycle count (CLKOUT) */
           /* ...0.... = T0SE, don't care for T0CS=0 */
           /* ....0... = PSA, prescalar assiged to TMR0 */
           /* .....111 = Prescalar is 256:1 */
   T0IE = ON;
   GIE = ON;
   message_byte = std_message[message_index];
   message_len = 16;
   TXSTA = 0b00100100;
          /* 0....... = Async don't care */
          /* .0...... = 8-bit transmission */
          /* ..1..... = transmit enabled */
          /* ...0.... = asynchronous mode */
          /* ....0... = unused */
          /* .....1.. = High-speed baudrate */
          /* ......0. = read-only register bit */
          /* .......0 = 9th bit of TX data (not used in 8-bit mode) */
   RCSTA = 0b10010000;
          /* 1....... = SPEN, serial port is ON */
          /* .0...... = RX9, 8-bit reception */
          /* ..0..... = SREN (async don't care) */
          /* ...1.... = CREN, continuous receive */
          /* ....0... = ADDEN, disable address detection */
          /* .....0.. = FERR (read-only) */
          /* ......0. = OERR (read-only) */
          /* .......0 = RX9D (read-only) */
   SPBRG = (int)(XTAL / (BAUDRATE * 16.0)) - 0.5;
               /* -1.0 + 0.5, the extra + 0.5 is to round up when needed */
   RCIE = ON;
   PEIE = ON;
#ifdef DISPLAY_VIA_LEVELS
   TRISB = 0;  /* all bits are outputs */
#endif
   puts(user_instr1);
   puts(user_instr2);
   for ( ; ; )
      {
      if (echo_char)
         {
         if ((echo_char != CR) && (user_index != MAX_USER_MESSAGE))
            putch(echo_char);
         echo_char = 0;
         }
      if ((user_index) && (rxbuf[user_index-1] == CR))
         {
         while ((char_index) || ((TMR0 & 0xf8) == 0xf8))
            ;
         /* make sure that
          *   1) we're about to start outputting a new character
          * and
          *   2) we won't be interrupted in the middle of a message change
          */
         if (user_index > 1)
            {
            for (message_len = 0; message_len < user_index-1; message_len++)
               user_message[message_len] = rxbuf[message_len];
            user_msg = TRUE;
            message_byte = user_message[0];
            message_index = 0;
            }
         user_index = 0;
         puts(user_instr1);
         puts(user_instr2);
         }
      }  /* for ( ; ; ) */
   }  /* main() */
