/*
 *  Hi Tech PIC C LITE compiler, V8.02
 */
#include <pic.h>

__CONFIG(HS & WDTDIS);

/* Xtal frequency */
#define XTAL  4000000L

#define BAUDRATE 9600

#define ON  1
#define OFF 0

#define UPDATES_PER_SECOND 16L
#define TMR1H_RESET ((65542L-((XTAL/4L)/UPDATES_PER_SECOND)) >> 8)
#define TMR1L_RESET ((65542L-((XTAL/4L)/UPDATES_PER_SECOND)) & 0xff)
/* NOTE: 65542 instead of 65536 for 6 cycles it takes to recognize TMR0
 *       overflow and reload TMR1H/TMR1L:
 *          while (!TMR1IF)
 *            ;
 *          TMR1H = TMR1H_RESET;
 *          TMR1L = TMR1L_RESET;
 *       becomes
 *          Lxx:
 *             BTFSS 0x0C,0
 *             GOTO  Lxx
 *             MOVLW xxxx
 *             MOVWF TMR1H
 *             MOVLW yyyy
 *             MOVWF TMR1L
 */

unsigned int spacecount;

/* NOTE: I want to keep this example code simple, and I don't care how much
 *       time I waste waiting for a character to transmit.
 */
void putch(char c)
   {
   while (!TXIF)
      ;
   TXREG = c;
   }  /* putch() */

main()
   {
   ADCON1 = 0b10001110;
           /* 1....... = right justified in ADRESH:ADRESL */
           /* .000.... = unused */
           /* ....1110 = only RA0 is analog, Vref+ = Vdd, Vref- = ground */
   ADCON0 = 0b10000001;
           /* 10...... = A/D conversion clock = Fosc / 8 */
           /* ..000... = channel 0 (AN0 on RA0) */
           /* .....0.. = conversion not in progress */
           /* ......0. = unused */
           /* .......1 = ADC on */
   TXSTA = 0b00100100;
          /* 0....... = Async don't care */
          /* .0...... = 8-bit transmission */
          /* ..1..... = transmit enabled */
          /* ...0.... = asynchronous mode */
          /* ....0... = unused */
          /* .....1.. = High-speed baudrate */
          /* ......0. = read-only register bit */
          /* .......0 = 9th bit of TX data (not used in 8-bit mode) */
   SPBRG = (XTAL / (BAUDRATE * 16.0)) - 0.5;
               /* the extra + 0.5 is to round up when needed */
   SPEN = ON;  /* turn on serial port */
   TMR1H = TMR1H_RESET;
   TMR1L = TMR1L_RESET;
   TMR1IF = OFF;
   T1CON = 0b00001001;
          /* 00...... = unused */
          /* ..00.... = 1:1 prescalar */
          /* ....1... = Oscillator is enabled */
          /* .....0.. = !T1SYNC (ignored if TMR1CS is 0) */
          /* ......0. = TMR1CS = internal clock (Fosc/4) */
          /* .......1 = TMR1ON (timer1 enabled) */
   for ( ; ; )
      {
      while (!TMR1IF)
         ;   /* wait for timer to expire */
      TMR1H = TMR1H_RESET;
      TMR1L = TMR1L_RESET;
      TMR1IF = OFF;
      ADGO = ON;
      while (ADGO)
         ;  /* wait for ADC conversion */
      spacecount = (((unsigned int)ADRESH << 8) | (unsigned int)ADRESL) >> 5;
      while (spacecount--)
         putch(' ');
      putch('*');
      putch('\n');
      }  /* for ( ; ; ) */
   }  /* main() */
